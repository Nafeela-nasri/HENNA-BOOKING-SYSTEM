<?php
// BookingReschedule_template.php

function getRescheduleCustomerEmailContent($customerName, $bookingDetails) {
    $serviceName = $bookingDetails['select_type'] === 'service' ? $bookingDetails['service_type'] : $bookingDetails['offer'];
    
    return "
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #8B4513, #A0522D); color: white; padding: 30px 20px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px 20px; border-radius: 0 0 10px 10px; }
            .highlight { background: #fff3cd; padding: 15px; border-left: 4px solid #ffc107; margin: 20px 0; }
            .details { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }
            .old-details { background: #f8d7da; border-left: 4px solid #dc3545; }
            .new-details { background: #d1edff; border-left: 4px solid #0066cc; }
            .footer { text-align: center; margin-top: 30px; color: #666; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>🗓️ Booking Rescheduled</h1>
                <p>Your appointment has been successfully rescheduled</p>
            </div>
            <div class='content'>
                <p>Dear <strong>$customerName</strong>,</p>
                
                <p>Your booking has been rescheduled successfully. Here are the updated details:</p>
                
                <div class='details old-details'>
                    <h3>❌ Previous Schedule:</h3>
                    <p><strong>Date:</strong> {$bookingDetails['old_date']}</p>
                    <p><strong>Time:</strong> {$bookingDetails['old_time']}</p>
                </div>
                
                <div class='details new-details'>
                    <h3>✅ New Schedule:</h3>
                    <p><strong>Service:</strong> $serviceName</p>
                    <p><strong>Date:</strong> {$bookingDetails['date']}</p>
                    <p><strong>Time:</strong> {$bookingDetails['time']}</p>
                    <p><strong>Status:</strong> Pending (awaiting artist confirmation)</p>
                </div>
                
                <div class='highlight'>
                    <p><strong>📝 Please Note:</strong> Your booking status has been reset to 'Pending' and the artist will need to confirm the new schedule. You will receive another email once the artist confirms.</p>
                </div>
                
                <p>If you have any questions or need to make further changes, please contact us.</p>
                
                <div class='footer'>
                    <p>Thank you for choosing Henna Harmony!</p>
                    <p>Best regards,<br>The Henna Harmony Team</p>
                </div>
            </div>
        </div>
    </body>
    </html>
    ";
}

function getRescheduleArtistEmailContent($artistName, $customerName, $bookingDetails) {
    $serviceName = $bookingDetails['select_type'] === 'service' ? $bookingDetails['service_type'] : $bookingDetails['offer'];
    
    return "
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #8B4513, #A0522D); color: white; padding: 30px 20px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px 20px; border-radius: 0 0 10px 10px; }
            .highlight { background: #fff3cd; padding: 15px; border-left: 4px solid #ffc107; margin: 20px 0; }
            .details { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }
            .old-details { background: #f8d7da; border-left: 4px solid #dc3545; }
            .new-details { background: #d1edff; border-left: 4px solid #0066cc; }
            .action-needed { background: #e2f3ff; border: 2px solid #0066cc; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center; }
            .footer { text-align: center; margin-top: 30px; color: #666; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>🔄 Booking Rescheduled</h1>
                <p>A customer has rescheduled their appointment</p>
            </div>
            <div class='content'>
                <p>Dear <strong>$artistName</strong>,</p>
                
                <p>Customer <strong>$customerName</strong> has rescheduled their booking. Please review the new schedule:</p>
                
                <div class='details old-details'>
                    <h3>❌ Previous Schedule:</h3>
                    <p><strong>Date:</strong> {$bookingDetails['old_date']}</p>
                    <p><strong>Time:</strong> {$bookingDetails['old_time']}</p>
                </div>
                
                <div class='details new-details'>
                    <h3>✅ Requested New Schedule:</h3>
                    <p><strong>Service:</strong> $serviceName</p>
                    <p><strong>Customer:</strong> $customerName</p>
                    <p><strong>Date:</strong> {$bookingDetails['date']}</p>
                    <p><strong>Time:</strong> {$bookingDetails['time']}</p>
                </div>
                
                <div class='action-needed'>
                    <h3>⏰ Action Required</h3>
                    <p><strong>Please log into your artist panel to confirm or adjust this rescheduled booking.</strong></p>
                    <p>The booking status has been reset to 'Pending' until you confirm the new schedule.</p>
                </div>
                
                <p>Please respond as soon as possible to confirm your availability for the new date and time.</p>
                
                <div class='footer'>
                    <p>Best regards,<br>The Henna Harmony Team</p>
                </div>
            </div>
        </div>
    </body>
    </html>
    ";
}
?>