<?php
// Usage: include and call getBookingEmailContent($artistName, $userName, $userEmail, $bookingDetails)
function getBookingEmailContent($artistName, $userName, $userEmail, $bookingDetails) {
	$type = isset($bookingDetails['select_type']) ? ucfirst($bookingDetails['select_type']) : 'Booking';
	$serviceOrOffer = $type === 'Service' ? $bookingDetails['service_type'] : $bookingDetails['offer'];
	$date = isset($bookingDetails['date']) ? $bookingDetails['date'] : '';
	$time = isset($bookingDetails['time']) ? $bookingDetails['time'] : '';
	$clientAddress = isset($bookingDetails['client_address']) ? $bookingDetails['client_address'] : '';
	$description = isset($bookingDetails['description']) ? $bookingDetails['description'] : '';
	$price = isset($bookingDetails['price']) ? $bookingDetails['price'] : '';

	$html = "<div style='font-family:Arial,sans-serif;max-width:600px;margin:auto;border:1px solid #eee;padding:24px;border-radius:12px;'>"
		. "<h2 style='color:#664a3f;'>New Booking Notification</h2>"
		. "<p>Dear <b>" . htmlspecialchars($artistName) . "</b>,</p>"
		. "<p>You have received a new booking from <b>" . htmlspecialchars($userName) . "</b> (" . htmlspecialchars($userEmail) . ").</p>"
		. "<h3 style='color:#2c2c2c;'>Booking Details:</h3>"
		. "<ul style='line-height:1.7;'>"
		. "<li><b>Type:</b> $type</li>"
		. "<li><b>Service/Offer:</b> " . htmlspecialchars($serviceOrOffer) . "</li>"
		. "<li><b>Date:</b> " . htmlspecialchars($date) . "</li>"
		. "<li><b>Time:</b> " . htmlspecialchars($time) . "</li>"
		. "<li><b>Client Address:</b> " . htmlspecialchars($clientAddress) . "</li>"
		. "<li><b>Description:</b> " . nl2br(htmlspecialchars($description)) . "</li>"
		. "<li><b>Price:</b> Rs" . htmlspecialchars($price) . "</li>"
		. "</ul>"
		. "<p style='margin-top:18px;'>Please <a href='http://localhost/Hena-Booking-System/Frontend/Artist/Artist_index.html' style='color:#e6a1a6;'>log in to your account</a> for further details and to manage this booking.</p>"
		. "<p style='color:#888;font-size:13px;margin-top:32px;'>This is an automated notification from Henna Harmony.</p>"
		. "</div>";
	return $html;
}
?>
