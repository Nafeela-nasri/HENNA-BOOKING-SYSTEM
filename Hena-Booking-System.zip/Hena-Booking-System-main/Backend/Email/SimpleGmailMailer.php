<?php
// Simple Gmail Mailer using PHPMailer
// Make sure you have PHPMailer installed (https://github.com/PHPMailer/PHPMailer)
// You can install via Composer: composer require phpmailer/phpmailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
	require_once __DIR__ . '/src/Exception.php';
	require_once __DIR__ . '/src/PHPMailer.php';
	require_once __DIR__ . '/src/SMTP.php';
}

function send_gmail_mail($to, $subject, $body, $altBody = '') {
	$mail = new PHPMailer(true);
	try {
		// Gmail SMTP configuration
		$mail->isSMTP();
		$mail->Host = 'smtp.gmail.com';
		$mail->SMTPAuth = true;
		$mail->Username = 'm.mohamed.shinan@gmail.com'; // <-- CHANGE THIS
		$mail->Password = 'ulvkvqlvrrdgbdor';      // <-- CHANGE THIS (App Password, not your Gmail password)
		$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
		$mail->Port = 587;

		$mail->setFrom('m.mohamed.shinan@gmail.com', 'Henna Harmony'); // <-- CHANGE THIS
		$mail->addAddress($to);
		$mail->isHTML(true);
		$mail->Subject = $subject;
		$mail->Body = $body;
		$mail->AltBody = $altBody ?: strip_tags($body);

		$mail->send();
		return true;
	} catch (Exception $e) {
		error_log('Mail Error: ' . $mail->ErrorInfo);
		return false;
	}
}
?>
