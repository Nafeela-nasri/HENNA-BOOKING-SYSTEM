<?php
// Usage: include and call getBookingStatusEmailContent($userName, $status, $bookingDetails)
function getBookingStatusEmailContent($userName, $status, $bookingDetails) {
    $type = isset($bookingDetails['select_type']) ? ucfirst($bookingDetails['select_type']) : 'Booking';
    $serviceOrOffer = $type === 'Service' ? $bookingDetails['service_type'] : $bookingDetails['offer'];
    $date = isset($bookingDetails['date']) ? $bookingDetails['date'] : '';
    $time = isset($bookingDetails['time']) ? $bookingDetails['time'] : '';
    $statusText = '';
    if ($status === 'confirmed') {
        $statusText = 'has been <b>confirmed</b>';
    } elseif ($status === 'cancelled') {
        $statusText = 'has been <b>cancelled</b>';
    } elseif ($status === 'completed') {
        $statusText = 'has been <b>completed</b>';
    }
    $html = "<div style='font-family:Arial,sans-serif;max-width:600px;margin:auto;border:1px solid #eee;padding:24px;border-radius:12px;'>"
        . "<h2 style='color:#664a3f;'>Booking Status Update</h2>"
        . "<p>Dear <b>" . htmlspecialchars($userName) . "</b>,</p>"
        . "<p>Your booking for <b>" . htmlspecialchars($serviceOrOffer) . "</b> on <b>" . htmlspecialchars($date) . "</b> at <b>" . htmlspecialchars($time) . "</b> $statusText.</p>"
        . "<p style='color:#888;font-size:13px;margin-top:32px;'>This is an automated notification from Henna Harmony.</p>"
        . "</div>";
    return $html;
}
?>
