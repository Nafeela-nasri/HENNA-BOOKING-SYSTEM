<?php
// Backend/Artist/design_api.php
header('Content-Type: application/json');
require_once '../db.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        // New endpoint: get_by_artist_id
        if (isset($_GET['route']) && $_GET['route'] === 'get_by_artist_id') {
            $artist_id = $_GET['artist_id'] ?? null;
            if ($artist_id) {
                $sql = "SELECT * FROM designs WHERE artist_id = " . intval($artist_id);
                $result = $conn->query($sql);
                $designs = [];
                while ($row = $result->fetch_assoc()) {
                    $designs[] = $row;
                }
                echo json_encode(['success' => true, 'designs' => $designs]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Missing artist_id']);
            }
            break;
        }
// New endpoint: get_by_artist_id
if (isset($_GET['route']) && $_GET['route'] === 'get_by_artist_id') {
    $artist_id = isset($_GET['artist_id']) ? intval($_GET['artist_id']) : 0;
    if ($artist_id > 0) {
        $result = $conn->query("SELECT * FROM services WHERE artist_id=$artist_id");
        $services = [];
        while ($row = $result->fetch_assoc()) {
            $services[] = $row;
        }
        echo json_encode(['success' => true, 'services' => $services]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Missing artist_id']);
    }
    exit;
}
    case 'POST':
        // Handle design upload
        $artist_id = $_POST['artist_id'] ?? null;
        $title = $_POST['title'] ?? '';
        $category = $_POST['category'] ?? '';
        $description = $_POST['description'] ?? '';
        $image_path = '';

        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $img_name = uniqid('design_') . '_' . basename($_FILES['image']['name']);
            $target_dir = __DIR__ . '/Images/';
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            $target_file = $target_dir . $img_name;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $image_path = 'Backend/Artist/Images/' . $img_name;
            }
        }

        if ($artist_id && $title && $category && $image_path) {
            $stmt = $conn->prepare("INSERT INTO designs (artist_id, title, category, description, image_path, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->bind_param('issss', $artist_id, $title, $category, $description, $image_path);
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Design uploaded successfully.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Database error.']);
            }
            $stmt->close();
        } else {
            echo json_encode(['success' => false, 'message' => 'Missing required fields.']);
        }
        break;

    case 'GET':
        // Fetch designs (optionally by artist_id)
        $artist_id = $_GET['artist_id'] ?? null;
        $sql = "SELECT * FROM designs";
        if ($artist_id) {
            $sql .= " WHERE artist_id = " . intval($artist_id);
        }
        $result = $conn->query($sql);
        $designs = [];
        while ($row = $result->fetch_assoc()) {
            $designs[] = $row;
        }
        echo json_encode($designs);
        break;

    case 'PUT':
        // Update design info
        parse_str(file_get_contents('php://input'), $_PUT);
        $id = $_PUT['id'] ?? null;
        $title = $_PUT['title'] ?? '';
        $category = $_PUT['category'] ?? '';
        $description = $_PUT['description'] ?? '';
        // Image update not handled in PUT for simplicity
        if ($id && $title && $category) {
            $stmt = $conn->prepare("UPDATE designs SET title=?, category=?, description=? WHERE id=?");
            $stmt->bind_param('sssi', $title, $category, $description, $id);
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Design updated successfully.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Database error.']);
            }
            $stmt->close();
        } else {
            echo json_encode(['success' => false, 'message' => 'Missing required fields.']);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
        break;
}

$conn->close();
