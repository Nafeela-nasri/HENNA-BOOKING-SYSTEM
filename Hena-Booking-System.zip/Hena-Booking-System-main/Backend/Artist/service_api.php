<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'php_error' => $errstr,
        'file' => $errfile,
        'line' => $errline,
        'errno' => $errno
    ]);
    exit;
});
include '../db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
// New endpoint: get_all_services (for customer panel)
if (isset($_GET['route']) && $_GET['route'] === 'get_all_services') {
    $result = $conn->query("SELECT * FROM services WHERE active=1");
    $services = [];
    while ($row = $result->fetch_assoc()) {
        $services[] = $row;
    }
    echo json_encode(['success' => true, 'services' => $services]);
    exit;
}
// New endpoint: get_by_artist_id
if (isset($_GET['route']) && $_GET['route'] === 'get_by_artist_id') {
    $artist_id = isset($_GET['artist_id']) ? intval($_GET['artist_id']) : 0;
    if ($artist_id > 0) {
        $result = $conn->query("SELECT * FROM services WHERE artist_id=$artist_id");
        $services = [];
        while ($row = $result->fetch_assoc()) {
            $services[] = $row;
        }
        echo json_encode(['success' => true, 'services' => $services]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Missing artist_id']);
    }
    exit;
}
    // Get all services for an artist
    $artist_id = isset($_GET['artist_id']) ? intval($_GET['artist_id']) : 0;
    if ($artist_id > 0) {
        $result = $conn->query("SELECT * FROM services WHERE artist_id=$artist_id");
        $services = [];
        while ($row = $result->fetch_assoc()) {
            $services[] = $row;
        }
        echo json_encode(['success' => true, 'services' => $services]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Missing artist_id']);
    }
    exit;
}

if ($method === 'POST') {
    // Add new service for an artist (with image upload)
    if (isset($_FILES['serviceImage'])) {
        $targetDir = __DIR__ . '/Images/';
        $fileName = uniqid('service_') . '_' . basename($_FILES['serviceImage']['name']);
        $targetFile = $targetDir . $fileName;
        $imagePath = 'Backend/Artist/Images/' . $fileName;
        if (move_uploaded_file($_FILES['serviceImage']['tmp_name'], $targetFile)) {
            // Image uploaded successfully
        } else {
            echo json_encode(['success' => false, 'error' => 'Image upload failed']);
            exit;
        }
    } else {
        $imagePath = '';
    }
    // Get other fields from POST
    $artist_id = intval($_POST['artist_id']);
    $name = $conn->real_escape_string($_POST['name']);
    $price = intval($_POST['price']);
    $duration = floatval($_POST['duration']);
    $description = $conn->real_escape_string($_POST['description']);
    $category = isset($_POST['category']) ? $conn->real_escape_string($_POST['category']) : '';
    $active = isset($_POST['active']) ? (intval($_POST['active']) ? 1 : 0) : 1;
    $sql = "INSERT INTO services (artist_id, name, price, duration, description, category, image_path, active) VALUES ($artist_id, '$name', $price, $duration, '$description', '$category', '$imagePath', $active)";
    if ($conn->query($sql)) {
        echo json_encode(['success' => true, 'service_id' => $conn->insert_id]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

if ($method === 'PUT') {
    // Edit service
    $data = json_decode(file_get_contents('php://input'), true);
    $id = intval($data['id']);
    $artist_id = intval($data['artist_id']);
    $name = $conn->real_escape_string($data['name']);
    $price = intval($data['price']);
    $duration = floatval($data['duration']);
    $description = $conn->real_escape_string($data['description']);
    $category = $conn->real_escape_string($data['category']);
    $active = isset($data['active']) ? (intval($data['active']) ? 1 : 0) : 1;
    $sql = "UPDATE services SET name='$name', price=$price, duration=$duration, description='$description', category='$category', active=$active WHERE id=$id AND artist_id=$artist_id";
    if ($conn->query($sql)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

if ($method === 'DELETE') {
    // Delete service
    $data = json_decode(file_get_contents('php://input'), true);
    $id = intval($data['id']);
    $artist_id = intval($data['artist_id']);
    $sql = "DELETE FROM services WHERE id=$id AND artist_id=$artist_id";
    if ($conn->query($sql)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

echo json_encode(['success' => false, 'error' => 'Invalid request']);
?>
