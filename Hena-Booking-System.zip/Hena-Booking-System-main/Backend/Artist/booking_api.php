<?php
header('Content-Type: application/json');
include '../db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    // Create new booking
    $raw_post = file_get_contents('php://input');
    $data = json_decode($raw_post, true);
    $user_id = intval($data['user_id']);
    $artist_id = intval($data['artist_id']);
    $user_email = isset($data['user_email']) ? $conn->real_escape_string($data['user_email']) : '';
    $artist_email = isset($data['artist_email']) ? $conn->real_escape_string($data['artist_email']) : '';
    $select_type = $conn->real_escape_string($data['select_type']); // 'service' or 'offer'
    $service_type = isset($data['service_type']) ? $conn->real_escape_string($data['service_type']) : null;
    $offer = isset($data['offer']) ? $conn->real_escape_string($data['offer']) : null;
    $date = $conn->real_escape_string($data['date']);
    $time = $conn->real_escape_string($data['time']);
    $client_address = $conn->real_escape_string($data['client_address']);
    $description = isset($data['description']) ? $conn->real_escape_string($data['description']) : '';
    $price = isset($data['price']) ? floatval($data['price']) : 0;
    $status = isset($data['status']) ? $conn->real_escape_string($data['status']) : 'pending';

    // Only one of service_type or offer should be set, and only save name (not price) in those columns
    if ($select_type === 'service') {
        // If service_type contains ' - Rs', only save the name part
        if ($service_type && strpos($service_type, ' - Rs') !== false) {
            $service_type = explode(' - Rs', $service_type)[0];
        }
        $offer = null;
    } elseif ($select_type === 'offer') {
        if ($offer && strpos($offer, ' - Rs') !== false) {
            $offer = explode(' - Rs', $offer)[0];
        }
        $service_type = null;
    }

    $sql = "INSERT INTO bookings (user_id, user_email, artist_id, artist_email, select_type, service_type, offer, date, time, client_address, description, price, status) VALUES (
        $user_id, '$user_email', $artist_id, '$artist_email', '$select_type', " .
        ($service_type !== null ? "'$service_type'" : "NULL") . ", " .
        ($offer !== null ? "'$offer'" : "NULL") . ", '$date', '$time', '$client_address', '$description', $price, '$status')";
    if ($conn->query($sql)) {
        // Send email to artist_email
        $booking_id = $conn->insert_id;
        // Fetch artist name (optional, fallback to email)
        $artistName = $artist_email;
        $userName = $user_email;
        // Try to get artist and user names from DB
        $artistRes = $conn->query("SELECT name FROM artists WHERE id=$artist_id LIMIT 1");
        if ($artistRes && $artistRes->num_rows > 0) {
            $row = $artistRes->fetch_assoc();
            $artistName = $row['name'];
        }
        $userRes = $conn->query("SELECT name FROM users WHERE id=$user_id LIMIT 1");
        if ($userRes && $userRes->num_rows > 0) {
            $row = $userRes->fetch_assoc();
            $userName = $row['name'];
        }

        // Prepare booking details for template
        $bookingDetails = [
            'select_type' => $select_type,
            'service_type' => $service_type,
            'offer' => $offer,
            'date' => $date,
            'time' => $time,
            'client_address' => $client_address,
            'description' => $description,
            'price' => $price
        ];

        // Include mailer and template
        require_once __DIR__ . '/../Email/SimpleGmailMailer.php';
        require_once __DIR__ . '/../Email/Booking_template.php';
        $subject = "New Booking from $userName via Henna Harmony";
        $body = getBookingEmailContent($artistName, $userName, $user_email, $bookingDetails);

        // Send email (assume send_gmail_mail function exists)
        $mailResult = false;
        if (function_exists('send_gmail_mail')) {
            $mailResult = send_gmail_mail($artist_email, $subject, $body);
        }

        echo json_encode([
            'success' => true,
            'booking_id' => $booking_id,
            'email_sent' => $mailResult
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

// NEW ENDPOINT: Get bookings by customer email
if ($method === 'GET' && isset($_GET['route']) && $_GET['route'] === 'get_by_email') {
    $email = isset($_GET['email']) ? $conn->real_escape_string($_GET['email']) : '';
    if (!$email) {
        echo json_encode(['success' => false, 'error' => 'Missing email']);
        exit;
    }

    $sql = "SELECT * FROM bookings WHERE user_email = '$email'";
    $result = $conn->query($sql);
    $bookings = [];
    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }

    echo json_encode(['success' => true, 'bookings' => $bookings]);
    exit;
}


if ($method === 'GET') {
    // Get bookings by user_id or artist_id, with optional date filter
    $user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : null;
    $artist_id = isset($_GET['artist_id']) ? intval($_GET['artist_id']) : null;
    $filter = isset($_GET['filter']) ? $_GET['filter'] : null;
    $today = date('Y-m-d');
    $where = '';
    if ($user_id) {
        $where = "WHERE user_id = $user_id";
    } elseif ($artist_id) {
        $where = "WHERE artist_id = $artist_id";
    }
    if ($filter === 'upcoming') {
        $where .= ($where ? ' AND ' : 'WHERE ') . "date >= '$today'";
    } elseif ($filter === 'past') {
        $where .= ($where ? ' AND ' : 'WHERE ') . "date < '$today'";
    }
    $sql = "SELECT * FROM bookings $where ORDER BY date ASC, time ASC";
    $result = $conn->query($sql);
    $bookings = [];
    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }
    echo json_encode(['success' => true, 'bookings' => $bookings]);
    exit;
}

// Dedicated endpoint for updating only status via PUT
if ($method === 'PUT' && isset($_GET['route']) && $_GET['route'] === 'update_status') {
    parse_str(file_get_contents('php://input'), $_PUT);
    $booking_id = isset($_PUT['id']) ? intval($_PUT['id']) : null;
    $status = isset($_PUT['status']) ? $conn->real_escape_string($_PUT['status']) : null;
    if ($booking_id && $status) {   
        error_log("[BookingAPI] PUT update_status called for booking_id=$booking_id, status=$status");
        // Fetch booking details
        $bookingRes = $conn->query("SELECT * FROM bookings WHERE id = $booking_id LIMIT 1");
        if ($bookingRes && $bookingRes->num_rows > 0) {
            $booking = $bookingRes->fetch_assoc();
            $user_email = $booking['user_email'];
            $artist_name = $booking['artist_email']; // fallback if artist name not found
            $user_name = $user_email; // fallback if user name not found
            $service_type = $booking['service_type'];
            $offer = $booking['offer'];
            $date = $booking['date'];
            $time = $booking['time'];
            $select_type = $booking['select_type'];
            // Try to get artist and user names from DB
            $artistRes = $conn->query("SELECT name FROM artists WHERE id=" . intval($booking['artist_id']) . " LIMIT 1");
            if ($artistRes && $artistRes->num_rows > 0) {
                $row = $artistRes->fetch_assoc();
                $artist_name = $row['name'];
            }
            $userRes = $conn->query("SELECT name FROM users WHERE id=" . intval($booking['user_id']) . " LIMIT 1");
            if ($userRes && $userRes->num_rows > 0) {
                $row = $userRes->fetch_assoc();
                $user_name = $row['name'];
            }
            // Update status
            $sql = "UPDATE bookings SET status = '$status' WHERE id = $booking_id";
            if ($conn->query($sql)) {
                // Send email to user_email if status is confirmed/cancelled/completed
                $sendMail = false;
                $subject = '';
                $body = '';
                $bookingDetails = [
                    'select_type' => $select_type,
                    'service_type' => $service_type,
                    'offer' => $offer,
                    'date' => $date,
                    'time' => $time
                ];
                require_once __DIR__ . '/../Email/SimpleGmailMailer.php';
                require_once __DIR__ . '/../Email/BookingStatus_template.php';
                if (in_array($status, ['confirmed', 'cancelled', 'completed'])) {
                    error_log("[BookingAPI] Preparing to send status email to user_email=$user_email for status=$status");
                    $subject = "Your booking has been $status | Henna Harmony";
                    $body = getBookingStatusEmailContent($user_name, $status, $bookingDetails);
                    $sendMail = true;
                }
                $mailResult = false;
                if ($sendMail && function_exists('send_gmail_mail')) {
                    $mailResult = send_gmail_mail($user_email, $subject, $body);
                    error_log("[BookingAPI] send_gmail_mail result for $user_email, status=$status: " . var_export($mailResult, true));
                } else if ($sendMail) {
                    error_log("[BookingAPI] send_gmail_mail function does not exist!");
                }
                echo json_encode(['success' => true, 'email_sent' => $mailResult]);
            } else {
                error_log("[BookingAPI] Failed to update booking status in DB: " . $conn->error);
                echo json_encode(['success' => false, 'error' => $conn->error]);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Booking not found']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Missing id or status']);
    }
    exit;
}

// NEW ENDPOINT: Reschedule booking (update date and time only)
if ($method === 'PUT' && isset($_GET['route']) && $_GET['route'] === 'reschedule') {
    parse_str(file_get_contents('php://input'), $_PUT);
    $booking_id = isset($_PUT['id']) ? intval($_PUT['id']) : null;
    $new_date = isset($_PUT['date']) ? $conn->real_escape_string($_PUT['date']) : null;
    $new_time = isset($_PUT['time']) ? $conn->real_escape_string($_PUT['time']) : null;
    
    if ($booking_id && $new_date && $new_time) {
        error_log("[BookingAPI] PUT reschedule called for booking_id=$booking_id, date=$new_date, time=$new_time");
        
        // Fetch booking details first
        $bookingRes = $conn->query("SELECT * FROM bookings WHERE id = $booking_id LIMIT 1");
        if ($bookingRes && $bookingRes->num_rows > 0) {
            $booking = $bookingRes->fetch_assoc();
            
            // Update date, time and reset status to pending
            $sql = "UPDATE bookings SET date = '$new_date', time = '$new_time', status = 'pending' WHERE id = $booking_id";
            if ($conn->query($sql)) {
                // Get user and artist info for email notification
                $user_email = $booking['user_email'];
                $artist_email = $booking['artist_email'];
                $user_name = $user_email; // fallback
                $artist_name = $artist_email; // fallback
                
                // Try to get actual names
                $userRes = $conn->query("SELECT name FROM users WHERE id=" . intval($booking['user_id']) . " LIMIT 1");
                if ($userRes && $userRes->num_rows > 0) {
                    $row = $userRes->fetch_assoc();
                    $user_name = $row['name'];
                }
                $artistRes = $conn->query("SELECT name FROM artists WHERE id=" . intval($booking['artist_id']) . " LIMIT 1");
                if ($artistRes && $artistRes->num_rows > 0) {
                    $row = $artistRes->fetch_assoc();
                    $artist_name = $row['name'];
                }
                
                // Prepare booking details for email
                $bookingDetails = [
                    'select_type' => $booking['select_type'],
                    'service_type' => $booking['service_type'],
                    'offer' => $booking['offer'],
                    'date' => $new_date,
                    'time' => $new_time,
                    'old_date' => $booking['date'],
                    'old_time' => $booking['time']
                ];
                
                // Send notification emails
                require_once __DIR__ . '/../Email/SimpleGmailMailer.php';
                require_once __DIR__ . '/../Email/BookingReschedule_template.php';
                
                $mailResults = [];
                
                // Email to customer
                $customerSubject = "Booking Rescheduled - Henna Harmony";
                $customerBody = getRescheduleCustomerEmailContent($user_name, $bookingDetails);
                if (function_exists('send_gmail_mail')) {
                    $mailResults['customer'] = send_gmail_mail($user_email, $customerSubject, $customerBody);
                }
                
                // Email to artist
                $artistSubject = "Booking Rescheduled by Customer - Henna Harmony";
                $artistBody = getRescheduleArtistEmailContent($artist_name, $user_name, $bookingDetails);
                if (function_exists('send_gmail_mail')) {
                    $mailResults['artist'] = send_gmail_mail($artist_email, $artistSubject, $artistBody);
                }
                
                echo json_encode([
                    'success' => true, 
                    'message' => 'Booking rescheduled successfully',
                    'email_sent' => $mailResults
                ]);
            } else {
                error_log("[BookingAPI] Failed to reschedule booking in DB: " . $conn->error);
                echo json_encode(['success' => false, 'error' => $conn->error]);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Booking not found']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Missing booking id, date, or time']);
    }
    exit;
}

if ($method === 'DELETE') {
    // Delete booking by id
    parse_str(file_get_contents('php://input'), $_DELETE);
    $booking_id = intval($_DELETE['id']);
    $sql = "DELETE FROM bookings WHERE id = $booking_id";
    if ($conn->query($sql)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

echo json_encode(['success' => false, 'error' => 'Invalid request']);
?>