<?php
header('Content-Type: application/json');
require_once '../db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    // Add a new review
    $data = json_decode(file_get_contents('php://input'), true);
    $artist_id = isset($data['artist_id']) ? intval($data['artist_id']) : 0;
    $user_id = isset($data['user_id']) ? intval($data['user_id']) : 0;
    $artist = isset($data['artist']) ? $data['artist'] : '';
    $service = isset($data['service']) ? $data['service'] : '';
    $rating = isset($data['rating']) ? intval($data['rating']) : 0;
    $review = isset($data['review']) ? $data['review'] : '';
    $booking_id = isset($data['booking_id']) ? intval($data['booking_id']) : 0;

    if ($artist_id && $user_id && $rating) {
        $stmt = $conn->prepare("INSERT INTO reviews (artist_id, user_id, artist, service, rating, review) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('iissis', $artist_id, $user_id, $artist, $service, $rating, $review);
        if ($stmt->execute()) {
            // If booking_id is provided, update review status in bookings table
            if ($booking_id) {
                $updateSql = "UPDATE bookings SET review = 'completed' WHERE id = $booking_id";
                $conn->query($updateSql);
            }
            echo json_encode(['success' => true, 'message' => 'Review added successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to add review']);
        }
        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    }
    exit;
}

// GET reviews by artist_id with customer name and avatar - FIXED VERSION
if ($method === 'GET' && isset($_GET['route']) && $_GET['route'] === 'get_by_artist_id') {
    $artist_id = isset($_GET['artist_id']) ? intval($_GET['artist_id']) : 0;
    
    if ($artist_id) {
        // Use LEFT JOIN to include reviews even if user doesn't exist
        // Also handle potential NULL values and image path construction
        $sql = "SELECT 
                    r.id, 
                    r.user_id, 
                    r.rating, 
                    r.review, 
                    r.created_at,
                    COALESCE(u.name, 'Unknown User') AS customerName,
                    CASE 
                        WHEN u.image_path IS NOT NULL AND u.image_path != '' 
                        THEN CONCAT('../../', u.image_path)
                        ELSE 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
                    END AS avatar
                FROM reviews r 
                LEFT JOIN users u ON r.user_id = u.id 
                WHERE r.artist_id = ? 
                ORDER BY r.created_at DESC";
                
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $artist_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $reviews = [];
        while ($row = $result->fetch_assoc()) {
            $reviews[] = [
                'id' => $row['id'],
                'user_id' => $row['user_id'],
                'rating' => intval($row['rating']),
                'review' => $row['review'],
                'created_at' => $row['created_at'],
                'customerName' => $row['customerName'],
                'avatar' => $row['avatar']
            ];
        }
        
        $stmt->close();
        echo json_encode(['success' => true, 'reviews' => $reviews]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Missing artist_id']);
    }
    exit;
}

if ($method === 'GET') {
    // Fetch reviews (by artist_id or user_id) - Basic version without JOIN
    $artist_id = isset($_GET['artist_id']) ? intval($_GET['artist_id']) : 0;
    $user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
    $sql = "SELECT * FROM reviews";
    $where = [];
    if ($artist_id) {
        $where[] = "artist_id = $artist_id";
    }
    if ($user_id) {
        $where[] = "user_id = $user_id";
    }
    if (count($where) > 0) {
        $sql .= " WHERE " . implode(' AND ', $where);
    }
    $sql .= " ORDER BY created_at DESC";
    $result = $conn->query($sql);
    $reviews = [];
    while ($row = $result->fetch_assoc()) {
        $reviews[] = $row;
    }
    echo json_encode(['success' => true, 'reviews' => $reviews]);
    exit;
}

// Default response
echo json_encode(['success' => false, 'message' => 'Invalid request']);
exit;
?>