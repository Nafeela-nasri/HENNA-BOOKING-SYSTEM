
<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');
// Custom error handler to return errors as JSON
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'php_error' => $errstr,
        'file' => $errfile,
        'line' => $errline,
        'errno' => $errno
    ]);
    exit;
});
include '../db.php';

$method = $_SERVER['REQUEST_METHOD'];


if ($method === 'GET') {
    // ...existing code...
    if (isset($_GET['email']) && isset($_GET['password'])) {
        $email = $conn->real_escape_string($_GET['email']);
        $password = $conn->real_escape_string($_GET['password']);
        $result = $conn->query("SELECT id, name, email FROM artists WHERE email='$email' AND password='$password' LIMIT 1");
        if ($result && $result->num_rows > 0) {
            $artist = $result->fetch_assoc();
            echo json_encode(['success' => true, 'artist' => $artist]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Invalid credentials']);
        }
    } else {
        $result = $conn->query('SELECT * FROM artists');
        $artists = [];
        while ($row = $result->fetch_assoc()) {
            $artists[] = $row;
        }
        echo json_encode(['success' => true, 'artists' => $artists]);
    }
    exit;
}

// Fetch artists for frontend dummyArtists replacement
if (isset($_GET['route']) && $_GET['route'] === 'fetch_simple' && $method === 'GET') {
    $result = $conn->query('SELECT id, name, email, profile_image as image_path FROM artists');
    $artists = [];
    while ($row = $result->fetch_assoc()) {
        $artists[] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'email' => $row['email'],
            'img' => $row['image_path']
        ];
    }
    echo json_encode(['success' => true, 'artists' => $artists]);
    exit;
}

// Handle profile update with image upload for POST (multipart/form-data) only
if ($method === 'POST' && strpos($_SERVER['CONTENT_TYPE'], 'multipart/form-data') !== false) {
    // Debug: log all POST keys and values
    error_log('POST keys: ' . implode(', ', array_keys($_POST)));
    foreach ($_POST as $k => $v) {
        error_log('POST ' . $k . ': ' . $v);
    }
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $name = isset($_POST['name']) ? $conn->real_escape_string($_POST['name']) : '';
    $email = isset($_POST['email']) ? $conn->real_escape_string($_POST['email']) : '';
    $specialty = isset($_POST['specialty']) ? $conn->real_escape_string($_POST['specialty']) : '';
    $experience = isset($_POST['experience']) ? intval($_POST['experience']) : 0;
    $phone = isset($_POST['phone']) ? $conn->real_escape_string($_POST['phone']) : '';
    $location = isset($_POST['location']) ? $conn->real_escape_string($_POST['location']) : '';
    $bio = isset($_POST['bio']) ? $conn->real_escape_string($_POST['bio']) : '';
    $profile_image_path = '';
    $upload_error = '';
    if (isset($_FILES['profile_image'])) {
        if ($_FILES['profile_image']['error'] == UPLOAD_ERR_OK) {
            $targetDir = __DIR__ . '/Images/';
            if (!is_dir($targetDir)) {
                if (!mkdir($targetDir, 0777, true)) {
                    $upload_error = 'Failed to create directory: ' . $targetDir;
                    error_log($upload_error);
                }
            }
            if (!$upload_error) {
                $img_name = basename($_FILES['profile_image']['name']);
                $targetFile = $targetDir . $img_name;
                if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $targetFile)) {
                    $profile_image_path = 'Backend/Admin/Images/' . $img_name;
                    error_log('Image saved successfully: ' . $targetFile);
                } else {
                    $upload_error = 'Failed to move uploaded file.';
                    error_log($upload_error . ' Source: ' . $_FILES['profile_image']['tmp_name'] . ' Target: ' . $targetFile);
                }
            }
        } else {
            $upload_error = 'File upload error: ' . $_FILES['profile_image']['error'];
            error_log($upload_error);
        }
    }
    if ($id > 0) {
        $sql = "UPDATE artists SET name='$name', email='$email', specialty='$specialty', experience=$experience, phone='$phone', location='$location', bio='$bio'";
        if ($profile_image_path) {
            $sql .= ", profile_image='$profile_image_path'";
        }
        $sql .= " WHERE id=$id";
        $db_result = $conn->query($sql);
        $image_status = ($profile_image_path && !$upload_error) ? 'saved' : 'not_saved';
        if ($db_result) {
            echo json_encode([
                'success' => true,
                'profile_image' => $profile_image_path,
                'upload_error' => $upload_error,
                'image_status' => $image_status
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => $conn->error,
                'upload_error' => $upload_error,
                'image_status' => $image_status
            ]);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Missing artist id', 'upload_error' => $upload_error]);
    }
    exit;
}

if ($method === 'POST') {
    // Add new artist (JSON body)
    $data = json_decode(file_get_contents('php://input'), true);
    $name = $conn->real_escape_string($data['name']);
    $email = $conn->real_escape_string($data['email']);
    $password = $conn->real_escape_string($data['password']);
    $specialty = $conn->real_escape_string($data['specialty']);
    $experience = intval($data['experience']);
    $phone = $conn->real_escape_string($data['phone']);
    $location = $conn->real_escape_string($data['location']);
    $bio = $conn->real_escape_string($data['bio']);
    $sql = "INSERT INTO artists (name, email, password, specialty, experience, phone, location, bio, status) VALUES ('$name', '$email', '$password', '$specialty', $experience, '$phone', '$location', '$bio', 'pending')";
    if ($conn->query($sql)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

if ($method === 'PUT') {
    // Edit artist (JSON body, no image)
    $data = json_decode(file_get_contents('php://input'), true);
    $id = intval($data['id']);
    $name = $conn->real_escape_string($data['name']);
    $email = $conn->real_escape_string($data['email']);
    $specialty = $conn->real_escape_string($data['specialty']);
    $experience = intval($data['experience']);
    $phone = $conn->real_escape_string($data['phone']);
    $location = $conn->real_escape_string($data['location']);
    $bio = $conn->real_escape_string($data['bio']);
    $sql = "UPDATE artists SET name='$name', email='$email', specialty='$specialty', experience=$experience, phone='$phone', location='$location', bio='$bio' WHERE id=$id";
    if ($conn->query($sql)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

if ($method === 'DELETE') {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = intval($data['id']);
    $sql = "DELETE FROM artists WHERE id=$id";
    if ($conn->query($sql)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

echo json_encode(['success' => false, 'error' => 'Invalid request']);
?>
