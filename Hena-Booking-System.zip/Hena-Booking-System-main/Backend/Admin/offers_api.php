<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'php_error' => $errstr,
        'file' => $errfile,
        'line' => $errline,
        'errno' => $errno
    ]);
    exit;
});
include '../db.php';

$method = $_SERVER['REQUEST_METHOD'];

// New endpoint: GET all offers for admin panel
if ($method === 'GET' && isset($_GET['route']) && $_GET['route'] === 'get_all_offers') {
    $result = $conn->query('SELECT * FROM offers ORDER BY created_at DESC');
    $offers = [];
    while ($row = $result->fetch_assoc()) {
        $offers[] = $row;
    }
    echo json_encode(['success' => true, 'offers' => $offers]);
    exit;
}

if ($method === 'GET') {
    // Get all offers
    $result = $conn->query('SELECT * FROM offers');
    $offers = [];
    while ($row = $result->fetch_assoc()) {
        $offers[] = $row;
    }
    echo json_encode(['success' => true, 'offers' => $offers]);
    exit;
}

if ($method === 'POST') {
    // Add new offer (JSON body)
    $raw_post = file_get_contents('php://input');
    error_log('Offer POST body: ' . $raw_post);
    $data = json_decode($raw_post, true);
    error_log('Offer POST decoded valid_until: ' . (isset($data['valid_until']) ? $data['valid_until'] : 'NOT SET'));
    $name = $conn->real_escape_string($data['name']);
    $description = $conn->real_escape_string($data['description']);
    $artist_id = intval($data['artist_id']);
    $service_ids = json_encode($data['service_ids']); // array of service ids
    $original_price = floatval($data['original_price']);
    $discount_percentage = floatval($data['discount_percentage']);
    $offer_price = floatval($data['offer_price']);
    $discount_amount = floatval($data['discount_amount']);
    $valid_from = $conn->real_escape_string($data['valid_from']);
    $valid_until_raw = isset($data['valid_until']) ? $data['valid_until'] : '';
    $status = $conn->real_escape_string($data['status']);

    // Validate and format valid_until
    $valid_until = '';
    if (!empty($valid_until_raw)) {
        // Accept both date and datetime, but store only date
        $dt = date_create($valid_until_raw);
        if ($dt) {
            $valid_until = $conn->real_escape_string($dt->format('Y-m-d'));
        } else {
            // Invalid date format
            echo json_encode(['success' => false, 'error' => 'Invalid valid_until date format']);
            exit;
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'valid_until is required']);
        exit;
    }

    $sql = "INSERT INTO offers (name, description, artist_id, service_ids, original_price, discount_percentage, offer_price, discount_amount, valid_from, valid_until, status) VALUES (
        '$name', '$description', $artist_id, '$service_ids', $original_price, $discount_percentage, $offer_price, $discount_amount, '$valid_from', '$valid_until', '$status')";
    if ($conn->query($sql)) {
        echo json_encode(['success' => true, 'offer_id' => $conn->insert_id]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

echo json_encode(['success' => false, 'error' => 'Invalid request']);
?>
