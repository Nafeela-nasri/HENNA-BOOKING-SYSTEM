<?php
header('Content-Type: application/json');
include '../db.php';

$method = $_SERVER['REQUEST_METHOD'];

// Helper: get JSON body for POST/PUT
function getJsonBody() {
    return json_decode(file_get_contents('php://input'), true);
}

if ($method === 'POST') {
    // Create notification
    $data = getJsonBody();
    $target_audience = $conn->real_escape_string($data['target_audience']);
    $user_id = isset($data['user_id']) ? $conn->real_escape_string($data['user_id']) : null;
    $artist_id = isset($data['artist_id']) ? $conn->real_escape_string($data['artist_id']) : null;
    $title = $conn->real_escape_string($data['title']);
    $message = $conn->real_escape_string($data['message']);
    $status = isset($data['status']) ? $conn->real_escape_string($data['status']) : 'active';
    $sql = "INSERT INTO notifications (target_audience, user_id, artist_id, title, message, status) VALUES (?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssss', $target_audience, $user_id, $artist_id, $title, $message, $status);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'id' => $stmt->insert_id]);
    } else {
        echo json_encode(['success' => false, 'error' => $stmt->error]);
    }
    $stmt->close();
    exit;
}

if ($method === 'DELETE') {
    // Delete notification by ID
    // Accept ID via query string or JSON body
    $id = isset($_GET['id']) ? intval($_GET['id']) : null;
    if (!$id) {
        // Try to get from JSON body
        $data = getJsonBody();
        $id = isset($data['id']) ? intval($data['id']) : null;
    }
    if ($id) {
        $stmt = $conn->prepare('DELETE FROM notifications WHERE id=?');
        $stmt->bind_param('i', $id);
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                echo json_encode(['success' => true, 'deleted_id' => $id]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Notification not found or already deleted', 'deleted_id' => $id]);
            }
        } else {
            echo json_encode(['success' => false, 'error' => $stmt->error, 'deleted_id' => $id]);
        }
        $stmt->close();
        exit;
    } else {
        echo json_encode(['success' => false, 'error' => 'Missing notification ID']);
        exit;
    }
}
if ($method === 'GET') {
    // Get all or by user_id/artist_id
    $user_id = isset($_GET['user_id']) ? $conn->real_escape_string($_GET['user_id']) : null;
    $artist_id = isset($_GET['artist_id']) ? $conn->real_escape_string($_GET['artist_id']) : null;
    if ($user_id) {
        // Get notifications for a specific user (target_audience all, customers, or specific-customer with user_id in list)
        $sql = "SELECT * FROM notifications WHERE (target_audience='all') OR (target_audience='customers') OR (target_audience='specific-customer' AND FIND_IN_SET(?, user_id)) ORDER BY created_at DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $notifications = [];
        while ($row = $result->fetch_assoc()) {
            $notifications[] = $row;
        }
        echo json_encode(['success' => true, 'notifications' => $notifications]);
        $stmt->close();
        exit;
    } else if ($artist_id) {
        // Get notifications for a specific artist (target_audience artists or specific-artist with artist_id in list)
        $sql = "SELECT * FROM notifications WHERE (target_audience='artists') OR (target_audience='specific-artist' AND FIND_IN_SET(?, artist_id)) ORDER BY created_at DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $artist_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $notifications = [];
        while ($row = $result->fetch_assoc()) {
            $notifications[] = $row;
        }
        echo json_encode(['success' => true, 'notifications' => $notifications]);
        $stmt->close();
        exit;
    } else {
        // Get all notifications
        $result = $conn->query("SELECT * FROM notifications ORDER BY created_at DESC");
        $notifications = [];
        while ($row = $result->fetch_assoc()) {
            $notifications[] = $row;
        }
        echo json_encode(['success' => true, 'notifications' => $notifications]);
        exit;
    }
}

http_response_code(400);
echo json_encode(['success' => false, 'error' => 'Invalid request']);
