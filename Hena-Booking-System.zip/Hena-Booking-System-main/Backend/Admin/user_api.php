
<?php
header('Content-Type: application/json');
include '../db.php';


$method = $_SERVER['REQUEST_METHOD'];
$route = isset($_GET['route']) ? $_GET['route'] : '';


if ($route === 'login' && $method === 'POST') {
    // Login: verify credentials
    $data = json_decode(file_get_contents('php://input'), true);
    $email = $conn->real_escape_string($data['email']);
    $password = $conn->real_escape_string($data['password']);
    $result = $conn->query("SELECT * FROM users WHERE email='$email' AND password='$password' AND status='active' LIMIT 1");
    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();
        unset($user['password']); // Don't send password back
        echo json_encode(['success' => true, 'user' => $user]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid credentials']);
    }
    exit;
}
// Fetch users for frontend dummyCustomers replacement
if ($route === 'fetch_simple' && $method === 'GET') {
    $result = $conn->query('SELECT id, name, email, image_path FROM users');
    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'email' => $row['email'],
            'img' => $row['image_path']
        ];
    }
    echo json_encode(['success' => true, 'users' => $users]);
    exit;
}

if ($route === 'update_profile' && $method === 'POST') {
    // Update user profile (name, email, phone, address, image)
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $name = isset($_POST['name']) ? $conn->real_escape_string($_POST['name']) : '';
    $email = isset($_POST['email']) ? $conn->real_escape_string($_POST['email']) : '';
    $phone = isset($_POST['phone']) ? $conn->real_escape_string($_POST['phone']) : '';
    $address = isset($_POST['address']) ? $conn->real_escape_string($_POST['address']) : '';
    $image_path = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = __DIR__ . '/Images/';
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }
        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $fileName = 'profile_' . $id . '_' . time() . '.' . $ext;
        $targetFile = $targetDir . $fileName;
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $image_path = 'Backend/Admin/Images/' . $fileName;
        }
    }
    $sql = "UPDATE users SET name='$name', email='$email', phone='$phone', address='$address'";
    if ($image_path) {
        $sql .= ", image_path='$image_path'";
    }
    $sql .= " WHERE id=$id";
    if ($conn->query($sql)) {
        $result = $conn->query("SELECT * FROM users WHERE id=$id LIMIT 1");
        $user = $result ? $result->fetch_assoc() : null;
        unset($user['password']);
        echo json_encode(['success' => true, 'user' => $user]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

switch ($method) {
    case 'GET':
        // Get all users
        $result = $conn->query('SELECT * FROM users');
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        echo json_encode(['success' => true, 'users' => $users]);
        break;
    case 'POST':
        // Add new user
        $data = json_decode(file_get_contents('php://input'), true);
        $name = $conn->real_escape_string($data['name']);
        $email = $conn->real_escape_string($data['email']);
        $role = $conn->real_escape_string($data['role']);
        $phone = $conn->real_escape_string($data['phone']);
        $password = isset($data['password']) ? $conn->real_escape_string($data['password']) : '';
        $sql = "INSERT INTO users (name, email, role, phone, password, status) VALUES ('$name', '$email', '$role', '$phone', '$password', 'active')";
        if ($conn->query($sql)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => $conn->error]);
        }
        break;
    case 'PUT':
        // Edit user
        $data = json_decode(file_get_contents('php://input'), true);
        $id = intval($data['id']);
        $name = $conn->real_escape_string($data['name']);
        $email = $conn->real_escape_string($data['email']);
        $role = $conn->real_escape_string($data['role']);
        $phone = $conn->real_escape_string($data['phone']);
        // Only update password if provided
        if (isset($data['password']) && $data['password'] !== '') {
            $password = $conn->real_escape_string($data['password']);
            $sql = "UPDATE users SET name='$name', email='$email', role='$role', phone='$phone', password='$password' WHERE id=$id";
        } else {
            $sql = "UPDATE users SET name='$name', email='$email', role='$role', phone='$phone' WHERE id=$id";
        }
        if ($conn->query($sql)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => $conn->error]);
        }
        break;
    case 'DELETE':
        // Delete user
        $data = json_decode(file_get_contents('php://input'), true);
        $id = intval($data['id']);
        $sql = "DELETE FROM users WHERE id=$id";
        if ($conn->query($sql)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => $conn->error]);
        }
        break;
    default:
        echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
?>
