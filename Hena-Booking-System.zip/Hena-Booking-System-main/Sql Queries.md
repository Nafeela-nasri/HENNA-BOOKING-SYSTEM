Sql Queries

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(100) NOT NULL,
    address VARCHAR(255),
    image_path VARCHAR(255),
    status VARCHAR(20) DEFAULT 'active'
);

CREATE TABLE artists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    password VARCHAR(100),
    specialty VARCHAR(50),
    experience INT DEFAULT 0,
    phone VARCHAR(20),
    location VARCHAR(100),
    bio TEXT,
    profile_image VARCHAR(255),
    status VARCHAR(20) DEFAULT 'pending'
);

CREATE TABLE services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    artist_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    price INT NOT NULL,
    duration FLOAT NOT NULL,
    description TEXT,
    category VARCHAR(50),
    image_path VARCHAR(255),
    active TINYINT(1) DEFAULT 1,
    FOREIGN KEY (artist_id) REFERENCES artists(id) ON DELETE CASCADE
);

CREATE TABLE designs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    artist_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    description TEXT,
    image_path VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE offers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    artist_id INT NOT NULL,
    service_ids TEXT NOT NULL, -- store as comma-separated IDs or JSON
    original_price DECIMAL(10,2) NOT NULL,
    discount_percentage DECIMAL(5,2) NOT NULL,
    offer_price DECIMAL(10,2) NOT NULL,
    discount_amount DECIMAL(10,2) NOT NULL,
    valid_from DATE NOT NULL,
    valid_until DATE NOT NULL,
    status VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    user_email VARCHAR(100),
    artist_id INT NOT NULL,
    artist_email VARCHAR(100),
    select_type VARCHAR(20) NOT NULL,
    service_type VARCHAR(100),
    offer VARCHAR(100),
    date DATE NOT NULL,
    time VARCHAR(10) NOT NULL,
    client_address VARCHAR(255),
    description TEXT,
    price DECIMAL(10,2),
    status VARCHAR(50) DEFAULT 'pending',
    review VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (artist_id) REFERENCES artists(id) ON DELETE CASCADE
);


-- Reviews Table
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    artist_id INT NOT NULL,
    user_id INT NOT NULL,
    artist VARCHAR(100),
    service VARCHAR(100),
    rating INT NOT NULL, -- 1 to 5
    review TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (artist_id) REFERENCES artists(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Notification Table
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    target_audience VARCHAR(50) NOT NULL, -- customers, artists, specific-customer, specific-artist
    user_id VARCHAR(255), -- comma-separated user ids if specific-customer
    artist_id VARCHAR(255), -- comma-separated artist ids if specific-artist
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);