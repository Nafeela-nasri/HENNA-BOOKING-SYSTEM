let currentUser = null
let currentSection = "home"
let currentRating = 0

// Sample Data
let products = []
let artists = []

// Initialize the application
document.addEventListener("DOMContentLoaded", () => {
  // Notification bell click logic for customer
  const bell = document.getElementById("notificationBellservice");
  const panel = document.getElementById("customerNotificationPanel");
  const closeBtn = document.getElementById("closeCustomerNotificationPanel");
  if (bell && panel) {
    bell.addEventListener("click", async (e) => {
      e.stopPropagation();
      if (!panel.classList.contains("open")) {
        await loadCustomerNotifications();
        panel.classList.add("open");
      } else {
        panel.classList.remove("open");
      }
    });
    // Close panel when clicking outside
    document.addEventListener("click", (e) => {
      if (!panel.contains(e.target) && e.target !== bell) {
        panel.classList.remove("open");
      }
    });
  }
  if (closeBtn && panel) {
    closeBtn.addEventListener("click", function (e) {
      e.stopPropagation();
      panel.classList.remove("open");
    });
  }
  // Fetch and render notifications for the customer
  async function loadCustomerNotifications() {
    const panelBody = document.getElementById("customerNotificationPanelBody");
    if (!panelBody) return;
    panelBody.innerHTML = '<div style="text-align:center;color:#888;padding:1.5rem 0;">Loading notifications...</div>';

    let userId = null;
    try {
      // Try to get currentUser from localStorage if not already loaded
      if (!currentUser) {
        const stored = localStorage.getItem("currentUser");
        if (stored) currentUser = JSON.parse(stored);
      }
      userId = currentUser && currentUser.id ? currentUser.id : null;
    } catch (e) {
      userId = null;
    }

    let url = "../../Backend/Admin/notification_api.php";
    if (userId) {
      url += `?user_id=${encodeURIComponent(userId)}`;
    }
    try {
      const res = await fetch(url);
      const data = await res.json();
      if (data.success && Array.isArray(data.notifications)) {
        if (data.notifications.length === 0) {
          panelBody.innerHTML = '<div style="text-align:center;color:#888;padding:1.5rem 0;">No notifications found.</div>';
          return;
        }
        panelBody.innerHTML = data.notifications.map((notif) => renderNotificationItem(notif)).join("");
      } else {
        panelBody.innerHTML = '<div style="text-align:center;color:#888;padding:1.5rem 0;">Failed to load notifications.</div>';
      }
    } catch (e) {
      panelBody.innerHTML = '<div style="text-align:center;color:#888;padding:1.5rem 0;">Error loading notifications.</div>';
    }
  }

  // Render a single notification item (simple style)
  function renderNotificationItem(notif) {
    // Choose icon and color based on title or type
    let icon = "fa-bell", color = "#2196f3";
    if (/confirm/i.test(notif.title)) { icon = "fa-calendar-check"; color = "#4caf50"; }
    else if (/review/i.test(notif.title)) { icon = "fa-star"; color = "#ff9800"; }
    else if (/offer|discount/i.test(notif.title)) { icon = "fa-gift"; color = "#e91e63"; }
    // Unread if status is 'active', else read
    const unread = notif.status === "active" ? "unread" : "";
    // Format time (simple, fallback to created_at)
    let time = notif.created_at ? formatNotificationTime(notif.created_at) : "";
    return `
    <div class="notification-item ${unread}" style="display:flex;gap:1rem;padding:0.7rem 0.5rem;border-bottom:1px solid #f2f2f2;align-items:flex-start;">
      <i class="fas ${icon} notification-icon" style="color:${color};font-size:1.3rem;"></i>
      <div class="notification-content">
        <h5 style="margin:0 0 0.2rem 0;font-size:1rem;">${escapeHtml(notif.title || "Notification")}</h5>
        <p style="margin:0 0 0.2rem 0;font-size:0.95rem;">${escapeHtml(notif.message || "")}</p>
        <span class="notification-time" style="font-size:0.85rem;color:#888;">${time}</span>
      </div>
    </div>
  `;
  }

  // Format notification time as relative (e.g., '2 min ago')
  function formatNotificationTime(dateStr) {
    const date = new Date(dateStr.replace(/-/g, '/'));
    const now = new Date();
    const diff = Math.floor((now - date) / 1000); // seconds
    if (diff < 60) return `${diff} sec ago`;
    if (diff < 3600) return `${Math.floor(diff / 60)} min ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} hour${Math.floor(diff / 3600) > 1 ? 's' : ''} ago`;
    return date.toLocaleDateString();
  }

  // Escape HTML for safe rendering
  function escapeHtml(str) {
    return String(str).replace(/[&<>'"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '\'': '&#39;', '"': '&quot;' }[c];
    });
  }
  initializeApp()
  loadStoredData()
  updateAuthUI()
  showSection("home")

  // Start customer realtime polling after initial load
  startCustomerRealtimePolling();

  // Password visibility toggles
  const toggleLoginPassword = document.getElementById("toggleLoginPassword")
  const toggleRegisterPassword = document.getElementById("toggleRegisterPassword")

  if (toggleLoginPassword) {
    toggleLoginPassword.addEventListener("click", function () {
      const input = document.getElementById("loginPassword")
      const icon = this.querySelector("i")
      if (input && icon) {
        if (input.type === "password") {
          input.type = "text"
          icon.classList.remove("fa-eye")
          icon.classList.add("fa-eye-slash")
        } else {
          input.type = "password"
          icon.classList.remove("fa-eye-slash")
          icon.classList.add("fa-eye")
        }
      }
    })
  }

  if (toggleRegisterPassword) {
    toggleRegisterPassword.addEventListener("click", function () {
      const input = document.getElementById("regPassword")
      const icon = this.querySelector("i")
      if (input && icon) {
        if (input.type === "password") {
          input.type = "text"
          icon.classList.remove("fa-eye")
          icon.classList.add("fa-eye-slash")
        } else {
          input.type = "password"
          icon.classList.remove("fa-eye-slash")
          icon.classList.add("fa-eye")
        }
      }
    })
  }

  // Populate review form dropdowns when review form is shown
  const addReview = document.getElementById("addReview")
  if (addReview) {
    const observer = new MutationObserver(() => {
      if (addReview.style.display !== "none") {
        populateReviewFormDropdowns()
      }
    })
    observer.observe(addReview, { attributes: true, attributeFilter: ["style"] })
  }
  // Populate review form dropdowns for Artist and Service
  function populateReviewFormDropdowns() {
    const reviewArtistSelect = document.getElementById("reviewArtist")
    const reviewServiceSelect = document.getElementById("reviewService")
    if (reviewArtistSelect && reviewServiceSelect && currentUser) {
      reviewArtistSelect.innerHTML = '<option value="">Select Artist</option>'
      reviewServiceSelect.innerHTML = '<option value="">Select Booking</option>'
      // Fetch user's bookings
      fetch(`../../Backend/Artist/booking_api.php?user_id=${currentUser.id}`)
        .then((res) => res.json())
        .then((data) => {
          if (data.success && Array.isArray(data.bookings)) {
            // Only completed bookings with valid IDs
            const completedBookings = data.bookings.filter(
              (b) => b.status === "completed" && b.id && !isNaN(Number(b.id)),
            )
            if (completedBookings.length === 0) {
              reviewServiceSelect.innerHTML = '<option value="">No completed bookings</option>'
              reviewServiceSelect.disabled = true
            } else {
              completedBookings.forEach((b) => {
                let label = ""
                if (b.service_type) {
                  label = b.service_type
                } else if (b.offer) {
                  label = b.offer
                }
                if (label) {
                  reviewServiceSelect.innerHTML += `<option value="${b.id}">${label} (${b.date})</option>`
                }
              })
              reviewServiceSelect.disabled = false
            }
            // Unique artist IDs from bookings
            const artistIds = [...new Set(completedBookings.map((b) => b.artist_id))]
            // Fetch all artists for name/profile_image mapping
            fetch("../../Backend/Admin/artist_api.php")
              .then((res) => res.json())
              .then((artistData) => {
                const artistMap = {}
                if (artistData.success && Array.isArray(artistData.artists)) {
                  artistData.artists.forEach((a) => {
                    artistMap[a.id] = a
                  })
                }
                artistIds.forEach((artistId) => {
                  const artist = artistMap[artistId]
                  if (artist) {
                    reviewArtistSelect.innerHTML += `<option value="${artistId}">${artist.name}</option>`
                  } else {
                    reviewArtistSelect.innerHTML += `<option value="${artistId}">${artistId}</option>`
                  }
                })
              })
          } else {
            reviewServiceSelect.innerHTML = '<option value="">No completed bookings</option>'
            reviewServiceSelect.disabled = true
          }
        })
        .catch(() => {
          reviewServiceSelect.innerHTML = '<option value="">Error loading bookings</option>'
          reviewServiceSelect.disabled = true
        })
    }
  }
})

function initializeApp() {
  // Navigation event listeners
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault()
      const section = e.target.dataset.section
      showSection(section)
    })
  })

  // Auth button event listeners
  const loginBtn = document.getElementById("loginBtn")
  const registerBtn = document.getElementById("registerBtn")
  const logoutBtn = document.getElementById("logoutBtn")
  const loginFromBookings = document.getElementById("loginFromBookings")
  const loginFromProfile = document.getElementById("loginFromProfile")

  if (loginBtn) loginBtn.addEventListener("click", showLoginModal)
  if (registerBtn) registerBtn.addEventListener("click", showRegisterModal)
  if (logoutBtn) logoutBtn.addEventListener("click", logout)
  if (loginFromBookings) loginFromBookings.addEventListener("click", showLoginModal)
  if (loginFromProfile) loginFromProfile.addEventListener("click", showLoginModal)

  // Modal event listeners
  setupModalEventListeners()

  // Form event listeners
  setupFormEventListeners()

  // Tab event listeners
  setupTabEventListeners()

  // Load initial data
  loadProducts()
  loadArtists()
  loadOffers()

  // Setup booking form logic
  setupBookingFormLogic()
}

// Update notification badge and panel UI given the fetched data (can be called even when panel closed)
function updateCustomerNotificationsUI(data) {
  try {
    const notificationIcon = document.querySelector('.notification-icon');
    const bell = document.getElementById('notificationBellservice');
    const panel = document.getElementById('customerNotificationPanel');
    const panelBody = document.getElementById('customerNotificationPanelBody');

    // Normalize data shape
    if (!data || !data.success || !Array.isArray(data.notifications)) {
      // If there's at least a badge element, clear count
      if (notificationIcon) notificationIcon.dataset.count = 0;
      if (panelBody && panel && panel.classList.contains('open')) {
        panelBody.innerHTML = '<div style="text-align:center;color:#888;padding:1.5rem 0;">No notifications.</div>';
      }
      return;
    }

    const notifs = data.notifications;
    const unreadCount = notifs.filter(n => n.status === 'active').length;

    // Update badge/count on the bell (simple data attribute or small bubble)
    if (notificationIcon) {
      notificationIcon.setAttribute('data-count', String(unreadCount));
      // show/hide visual indicator
      if (unreadCount > 0) notificationIcon.classList.add('has-unread');
      else notificationIcon.classList.remove('has-unread');
    }

    // If panel is open, update panel contents immediately
    if (panel && panel.classList.contains('open') && panelBody) {
      if (notifs.length === 0) {
        panelBody.innerHTML = '<div style="text-align:center;color:#888;padding:1.5rem 0;">No notifications found.</div>';
      } else {
        panelBody.innerHTML = notifs.map(n => renderNotificationItem(n)).join('');
      }
    }
  } catch (e) {
    // swallow errors — we don't want UI update failures to break polling
    console.error('updateCustomerNotificationsUI error', e);
  }
}

// Customer realtime polling: prioritize notifications and current section
function startCustomerRealtimePolling() {
  if (window._customerRealtimeId) return;
  // Immediate tick then every 1s
  customerRealtimeTick();
  window._customerRealtimeId = setInterval(customerRealtimeTick, 1000);
}

function stopCustomerRealtimePolling() {
  if (window._customerRealtimeId) {
    clearInterval(window._customerRealtimeId);
    window._customerRealtimeId = null;
  }
}

async function customerRealtimeTick() {
  // Prevent overlapping ticks
  if (window._customerRealtimeInProgress) return;
  window._customerRealtimeInProgress = true;

  // If any modal is open or user is editing, refresh cache quietly but skip DOM updates
  const modalOpen = !!document.querySelector('.modal.show, .modal.active');
  try {
  // Priority: notifications always first — include user_id when available
  let notifUrl = '../../Backend/Admin/notification_api.php';
  if (currentUser && currentUser.id) notifUrl += `?user_id=${encodeURIComponent(currentUser.id)}`;
  const notifPromise = fetch(notifUrl).then(r => r.json()).catch(() => null);

    // Active section priority mapping
    const section = currentSection || 'home';
    let priorityPromises = [];
    let backgroundPromises = [];

    function safeFetch(url) { return fetch(url).then(r => r.json()).catch(() => null); }

    if (section === 'home') {
      priorityPromises.push(safeFetch('../../Backend/Admin/notification_api.php'));
      backgroundPromises.push(safeFetch('../../Backend/Artist/service_api.php?route=get_all_services'));
      backgroundPromises.push(safeFetch('../../Backend/Admin/artist_api.php'));
      backgroundPromises.push(safeFetch('../../Backend/Admin/offers_api.php?route=get_all_offers'));
    } else if (section === 'browse') {
      priorityPromises.push(safeFetch('../../Backend/Artist/service_api.php?route=get_all_services'));
      backgroundPromises.push(safeFetch('../../Backend/Admin/artist_api.php'));
      backgroundPromises.push(safeFetch('../../Backend/Admin/offers_api.php?route=get_all_offers'));
    } else if (section === 'artists') {
      priorityPromises.push(safeFetch('../../Backend/Admin/artist_api.php'));
      backgroundPromises.push(safeFetch('../../Backend/Artist/service_api.php?route=get_all_services'));
    } else if (section === 'offers') {
      priorityPromises.push(safeFetch('../../Backend/Admin/offers_api.php?route=get_all_offers'));
      backgroundPromises.push(safeFetch('../../Backend/Admin/artist_api.php'));
    } else if (section === 'bookings') {
      if (currentUser && currentUser.id) priorityPromises.push(safeFetch(`../../Backend/Artist/booking_api.php?user_id=${currentUser.id}`));
      backgroundPromises.push(safeFetch('../../Backend/Admin/artist_api.php'));
      backgroundPromises.push(safeFetch('../../Backend/Artist/service_api.php?route=get_all_services'));
    } else if (section === 'profile') {
      if (currentUser && currentUser.id) priorityPromises.push(safeFetch(`../../Backend/Admin/user_api.php?user_id=${currentUser.id}`));
      priorityPromises.push(safeFetch(`../../Backend/Artist/review_api.php?user_id=${currentUser?.id || ''}`));
      backgroundPromises.push(safeFetch('../../Backend/Admin/artist_api.php'));
    } else {
      // default low priority fetches
      backgroundPromises.push(safeFetch('../../Backend/Admin/artist_api.php'));
      backgroundPromises.push(safeFetch('../../Backend/Artist/service_api.php?route=get_all_services'));
      backgroundPromises.push(safeFetch('../../Backend/Admin/offers_api.php?route=get_all_offers'));
    }

    // Ensure notifications are included as highest priority
    if (!priorityPromises.includes(notifPromise)) priorityPromises.unshift(notifPromise);

    // Ensure notifications are resolved first so badge/panel can update fast
    const notifResult = await notifPromise;
    try {
      updateCustomerNotificationsUI(notifResult);
    } catch (e) {
      console.error('Failed to update notification UI', e);
    }

    // Run priority fetches first
    const prResults = await Promise.all(priorityPromises.map(p => p.catch?.() || p));

    // If not modal open, update UI immediately based on section
    if (!modalOpen) {
      try {
        // update notifications if returned
        const notifRes = prResults.find(r => r && r.notifications !== undefined);
        if (notifRes && notifRes.success && Array.isArray(notifRes.notifications)) {
          // If notification panel exists and is not open, you might update a badge
          // Render notifications only when panel is open (to avoid UI blinking)
          const panel = document.getElementById('customerNotificationPanel');
          if (panel && panel.classList.contains('open')) {
            await loadCustomerNotifications();
          }
        }

        // handle active section updates
        if (section === 'home') {
          // optionally update hero stats or similar (not implemented here)
        } else if (section === 'browse') {
          await loadProducts();
        } else if (section === 'artists') {
          await loadArtists();
        } else if (section === 'offers') {
          await loadOffers();
        } else if (section === 'bookings') {
          if (currentUser) await loadUserBookings();
        } else if (section === 'profile') {
          if (currentUser) await loadUserProfile();
          if (currentUser) await loadUserReviews();
        }
      } catch (e) {
        // ignore render errors
      }
    }

    // Run background fetches but don't block UI
    setTimeout(async () => {
      try {
        const bgResults = await Promise.all(backgroundPromises);
        // Not aggressively updating UI from background results to avoid interruptions
      } catch (e) {
        // ignore
      }
    }, 100);
  } finally {
    window._customerRealtimeInProgress = false;
  }
}

function setupBookingFormLogic() {
  const bookingPriceInput = document.getElementById("bookingPrice")
  // Auto-fill Client Address if available in currentUser
  const clientAddressInput = document.getElementById("clientaddress")
  if (clientAddressInput) {
    const storedUser = localStorage.getItem("currentUser")
    if (storedUser) {
      const userObj = JSON.parse(storedUser)
      if (userObj.address) {
        clientAddressInput.value = userObj.address
      }
    }
  }

  // Show payment summary when Service Type or Offer is selected
  const serviceTypeSelect = document.getElementById("serviceType")
  const offerTypeSelect = document.getElementById("offerType")
  const artistSelect = document.getElementById("artistSelect")
  const paymentSummaryInline = document.getElementById("paymentSummaryInline")

  function updatePaymentSummary() {
    const selectedTypeElement = document.querySelector('input[name="bookingType"]:checked')
    if (!selectedTypeElement) return

    const selectedType = selectedTypeElement.value
    let serviceName = ""
    let price = ""
    let description = ""
    if (selectedType === "service" && serviceTypeSelect && serviceTypeSelect.value) {
      const option = serviceTypeSelect.options[serviceTypeSelect.selectedIndex]
      serviceName = option ? option.textContent : ""
      price = option
        ? option.getAttribute("data-price") ||
        (option.textContent.match(/Rs\d+/) ? option.textContent.match(/Rs(\d+)/)[1] : "")
        : ""
      description = option ? option.getAttribute("data-description") || "" : ""
    } else if (selectedType === "offer" && offerTypeSelect && offerTypeSelect.value) {
      const option = offerTypeSelect.options[offerTypeSelect.selectedIndex]
      serviceName = option ? option.textContent : ""
      price = option
        ? option.getAttribute("data-price") ||
        (option.textContent.match(/Rs\d+/) ? option.textContent.match(/Rs(\d+)/)[1] : "")
        : ""
      description = option ? option.getAttribute("data-description") || "" : ""
    }
    if (bookingPriceInput) bookingPriceInput.value = price
    const bookingDescriptionInput = document.getElementById("bookingDescription")
    if (bookingDescriptionInput) bookingDescriptionInput.value = description

    let artistName = ""
    if (artistSelect && artistSelect.value) {
      const option = artistSelect.options[artistSelect.selectedIndex]
      artistName = option ? option.textContent : ""
    }

    if (serviceName && price && artistName && paymentSummaryInline) {
      paymentSummaryInline.innerHTML = `
                <h3>Payment Summary</h3>
                <p><strong>Service/Offer:</strong> ${serviceName}</p>
                <p><strong>Description:</strong> ${description}</p>
                <p><strong>Price:</strong> Rs ${price}</p>
                <p><strong>Artist:</strong> ${artistName}</p>
            `
      paymentSummaryInline.style.display = "block"
    } else if (paymentSummaryInline) {
      paymentSummaryInline.innerHTML = ""
      paymentSummaryInline.style.display = "none"
    }
  }

  if (serviceTypeSelect) {
    serviceTypeSelect.addEventListener("change", updatePaymentSummary)
  }
  if (offerTypeSelect) {
    offerTypeSelect.addEventListener("change", updatePaymentSummary)
  }
  if (artistSelect) {
    artistSelect.addEventListener("change", updatePaymentSummary)
  }

  // Add event listeners for booking type radio buttons
  document.querySelectorAll('input[name="bookingType"]').forEach((radio) => {
    radio.addEventListener("change", () => {
      updatePaymentSummary()
      handleBookingTypeChange()
    })
  })

  // Booking type radio logic
  const typeRadioGroup = document.getElementById("typeRadioGroup")
  const serviceTypeGroup = document.getElementById("serviceTypeGroup")
  const offerTypeGroup = document.getElementById("offerTypeGroup")

  if (typeRadioGroup && serviceTypeGroup && offerTypeGroup) {
    typeRadioGroup.addEventListener("change", (e) => {
      const selectedType = document.querySelector('input[name="bookingType"]:checked').value
      if (selectedType === "service") {
        serviceTypeGroup.style.display = ""
        offerTypeGroup.style.display = "none"
        // Make serviceType required, offerType not required
        document.getElementById("serviceType").required = true
        document.getElementById("offerType").required = false
      } else {
        serviceTypeGroup.style.display = "none"
        offerTypeGroup.style.display = ""
        document.getElementById("serviceType").required = false
        document.getElementById("offerType").required = true
      }
      updatePaymentSummary()
    })

    // Initial state
    const selectedTypeElement = document.querySelector('input[name="bookingType"]:checked')
    if (selectedTypeElement) {
      const selectedType = selectedTypeElement.value
      if (selectedType === "service") {
        serviceTypeGroup.style.display = ""
        offerTypeGroup.style.display = "none"
        document.getElementById("serviceType").required = true
        document.getElementById("offerType").required = false
      } else {
        serviceTypeGroup.style.display = "none"
        offerTypeGroup.style.display = ""
        document.getElementById("serviceType").required = false
        document.getElementById("offerType").required = true
      }
    }
  }
}

function handleBookingTypeChange() {
  const typeRadioGroup = document.getElementById("typeRadioGroup")
  const serviceTypeGroup = document.getElementById("serviceTypeGroup")
  const offerTypeGroup = document.getElementById("offerTypeGroup")

  if (!typeRadioGroup || !serviceTypeGroup || !offerTypeGroup) return

  const selectedTypeElement = document.querySelector('input[name="bookingType"]:checked')
  if (!selectedTypeElement) return

  const selectedType = selectedTypeElement.value

  if (selectedType === "service") {
    serviceTypeGroup.style.display = "block"
    offerTypeGroup.style.display = "none"
    const serviceTypeSelect = document.getElementById("serviceType")
    const offerTypeSelect = document.getElementById("offerType")
    if (serviceTypeSelect) serviceTypeSelect.required = true
    if (offerTypeSelect) offerTypeSelect.required = false
  } else {
    serviceTypeGroup.style.display = "none"
    offerTypeGroup.style.display = "block"
    const serviceTypeSelect = document.getElementById("serviceType")
    const offerTypeSelect = document.getElementById("offerType")
    if (serviceTypeSelect) serviceTypeSelect.required = false
    if (offerTypeSelect) offerTypeSelect.required = true
  }
}

function loadOffers() {
  const offersGrid = document.getElementById("offersGrid")
  if (!offersGrid) return

  offersGrid.innerHTML = '<div style="text-align:center;color:var(--light-text);padding:2rem;">Loading offers...</div>'

  // First, fetch artists and build artistMap
  // Try to fetch artists, but if it fails, still show offers
  const artistMap = {}
  const artistImageMap = {}
  fetch("../../Backend/Admin/artist_api.php")
    .then((res) => res.json())
    .then((artistData) => {
      if (artistData.success && Array.isArray(artistData.artists)) {
        artistData.artists.forEach((a) => {
          artistMap[a.id] = a.name
          artistImageMap[a.id] = a.profile_image || ""
        })
      }
    })
    .catch(() => {
      /* ignore artist fetch error */
    })
    .finally(() => {
      fetch("../../Backend/Admin/offers_api.php?route=get_all_offers")
        .then((res) => res.json())
        .then((data) => {
          if (data.success && Array.isArray(data.offers)) {
            if (data.offers.length === 0) {
              offersGrid.innerHTML = '<div class="empty-state"><h3>No offers available at the moment.</h3></div>'
              return
            }
            offersGrid.innerHTML = data.offers
              .map((offer) => {
                const artistName =
                  artistMap[offer.artist_id] || `<span style='color:#8c6e62;'>Artist ID: ${offer.artist_id}</span>`
                const artistImg = artistImageMap[offer.artist_id] ? `../../${artistImageMap[offer.artist_id]}` : ""
                return `
                                <div class="offer-card">
                                    <div style="display:flex;align-items:center;justify-content:space-between;">
                                        <h3>${offer.name}</h3>
                                        <span class="status-badge status-${offer.status}">${offer.status.charAt(0).toUpperCase() + offer.status.slice(1)}</span>
                                    </div>
                                    <p style="color:var(--accent-color);margin-bottom:1rem;">${offer.description}</p>
                                    <div style="margin-bottom:1rem;display:flex;align-items:center;gap:1rem;">
                                        <strong>Artist:</strong>
                                        ${artistImg ? `<img src='${artistImg}' alt='${artistName}' style='width:38px;height:38px;border-radius:50%;object-fit:cover;border:2px solid var(--border-color);margin-right:0.5rem;'>` : ""}
                                        <span class="artist-name" style="font-weight:600;">${artistName}</span>
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <strong>Discount:</strong> <span style="color:var(--success-color);font-weight:600;">${offer.discount_percentage}%</span>
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <strong>Original Price:</strong> <span style="text-decoration:line-through;color:var(--danger-color);">Rs ${offer.original_price}</span>
                                        <strong style="margin-left:1rem;">Offer Price:</strong> <span style="color:var(--primary-color);font-weight:600;">Rs ${offer.offer_price}</span>
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <strong>Valid:</strong> ${offer.valid_from} to ${offer.valid_until}
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <strong>Services:</strong> ${Array.isArray(offer.service_ids) ? offer.service_ids.join(", ") : offer.service_ids}
                                    </div>
                                </div>
                            `
              })
              .join("")
          } else {
            offersGrid.innerHTML = '<div class="empty-state"><h3>Failed to load offers.</h3></div>'
          }
        })
        .catch((error) => {
          console.error("Error loading offers:", error)
          offersGrid.innerHTML = '<div class="empty-state"><h3>Failed to load offers.</h3></div>'
        })
    })
}

function setupModalEventListeners() {
  // Close modal buttons
  document.querySelectorAll(".close").forEach((closeBtn) => {
    closeBtn.addEventListener("click", (e) => {
      e.target.closest(".modal").classList.remove("show")
    })
  })

  // Close modal when clicking outside
  document.querySelectorAll(".modal").forEach((modal) => {
    modal.addEventListener("click", (e) => {
      if (e.target === modal) {
        modal.classList.remove("show")
      }
    })
  })

  // Success modal OK button
  const successOk = document.getElementById("successOk")
  if (successOk) {
    successOk.addEventListener("click", () => {
      document.getElementById("successModal").classList.remove("show")
    })
  }
}

function setupFormEventListeners() {
  // Login form
  const loginForm = document.getElementById("loginForm")
  if (loginForm) {
    loginForm.addEventListener("submit", handleLogin)
  }

  // Register form
  const registerForm = document.getElementById("registerForm")
  if (registerForm) {
    registerForm.addEventListener("submit", handleRegister)
  }

  // Booking form
  const bookingForm = document.getElementById("bookingForm")
  if (bookingForm) {
    bookingForm.addEventListener("submit", handleBooking)
  }

  // Profile form
  const profileForm = document.getElementById("profileForm")
  if (profileForm) {
    profileForm.addEventListener("submit", handleProfileUpdate)
  }

  // Review form
  const reviewForm = document.getElementById("reviewForm")
  if (reviewForm) {
    reviewForm.addEventListener("submit", handleReviewSubmit)
  }

  // Star rating
  document.querySelectorAll(".star").forEach((star) => {
    star.addEventListener("click", (e) => {
      currentRating = Number.parseInt(e.target.dataset.rating)
      updateStarRating()
    })
  })
}

function setupTabEventListeners() {
  // Booking tabs
  document.querySelectorAll(".booking-tabs .tab-btn").forEach((tab) => {
    tab.addEventListener("click", (e) => {
      switchTab(e.target, "booking-tabs")
    })
  })

  // Profile tabs
  document.querySelectorAll(".profile-tabs .tab-btn").forEach((tab) => {
    tab.addEventListener("click", (e) => {
      switchTab(e.target, "profile-tabs")
    })
  })
}

function showSection(sectionName) {
  // Hide all sections
  document.querySelectorAll(".section").forEach((section) => {
    section.classList.remove("active")
  })

  // Show the selected section
  const targetSection = document.getElementById(sectionName)
  if (targetSection) {
    targetSection.classList.add("active")
  }
  currentSection = sectionName

  // Update navigation active state
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.classList.remove("active")
  })

  const activeLink = document.querySelector(`[data-section="${sectionName}"]`)
  if (activeLink) {
    activeLink.classList.add("active")
  }

  // Load section-specific data
  if (sectionName === "bookings" && currentUser) {
    loadUserBookings()
  } else if (sectionName === "profile" && currentUser) {
    loadUserProfile()
    loadUserPayments()
    loadUserReviews()
  }
}

function showLoginModal() {
  const loginModal = document.getElementById("loginModal")
  if (loginModal) {
    loginModal.classList.add("show")
  }
}

function showRegisterModal() {
  const registerModal = document.getElementById("registerModal")
  if (registerModal) {
    registerModal.classList.add("show")
  }
}

function handleLogin(e) {
  e.preventDefault()

  const emailInput = document.getElementById("loginEmail")
  const passwordInput = document.getElementById("loginPassword")

  if (!emailInput || !passwordInput) return

  const email = emailInput.value
  const password = passwordInput.value

  if (email && password) {
    fetch("../../Backend/Admin/user_api.php?route=login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: email, password: password }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.user) {
          currentUser = data.user
          localStorage.setItem("currentUser", JSON.stringify(currentUser))
          localStorage.setItem("customer_login", "true")
          document.getElementById("loginModal").classList.remove("show")
          updateAuthUI()
          showSuccess("Login successful! Welcome to Henna Harmony.")
          // If we came from a restricted section, stay there
          if (currentSection === "bookings" || currentSection === "profile") {
            showSection(currentSection)
          }
        } else {
          alert("Login failed: Verification does not match")
        }
      })
      .catch(() => {
        alert("Login failed: Network error")
      })
  }
}

function handleRegister(e) {
  e.preventDefault()

  const nameInput = document.getElementById("regName")
  const emailInput = document.getElementById("regEmail")
  const phoneInput = document.getElementById("regPhone")
  const passwordInput = document.getElementById("regPassword")

  if (!nameInput || !emailInput || !phoneInput || !passwordInput) return

  const name = nameInput.value
  const email = emailInput.value
  const phone = phoneInput.value
  const password = passwordInput.value

  if (name && email && phone && password) {
    fetch("../../Backend/Admin/user_api.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: name,
        email: email,
        phone: phone,
        password: password,
        role: "customer",
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          showSuccess("Registration successful! Welcome to Henna Harmony.")
          document.getElementById("registerModal").classList.remove("show")
          document.getElementById("registerForm").reset()
        } else {
          alert("Registration failed: " + (data.error || "Unknown error"))
        }
      })
      .catch(() => {
        alert("Registration failed: Network error")
      })
  }
}

function logout() {
  currentUser = null
  localStorage.removeItem("currentUser")
  localStorage.removeItem("customer_login")
  updateAuthUI()
  showSection("home")
  showSuccess("Logged out successfully!")
  // Stop realtime polling when user logs out
  stopCustomerRealtimePolling();
}

function updateAuthUI() {
  const loginBtn = document.getElementById("loginBtn")
  const registerBtn = document.getElementById("registerBtn")
  const logoutBtn = document.getElementById("logoutBtn")
  const notificationIcon = document.querySelector(".notification-icon") // Add this line

  const bookingsAuthRequired = document.getElementById("bookingsAuthRequired")
  const bookingsContent = document.getElementById("bookingsContent")
  const profileAuthRequired = document.getElementById("profileAuthRequired")
  const profileContent = document.getElementById("profileContent")

  if (currentUser) {
    // User is logged in
    if (loginBtn) loginBtn.style.display = "none"
    if (registerBtn) registerBtn.style.display = "none"
    if (logoutBtn) {
      logoutBtn.style.display = "block"
      logoutBtn.textContent = `Logout (${currentUser.name})`
    }
    if (notificationIcon) notificationIcon.style.display = "block" // Show notification bell

    if (bookingsAuthRequired) bookingsAuthRequired.style.display = "none"
    if (bookingsContent) bookingsContent.style.display = "block"
    if (profileAuthRequired) profileAuthRequired.style.display = "none"
    if (profileContent) profileContent.style.display = "block"

    populateArtistSelect()
  } else {
    // User is not logged in
    if (loginBtn) loginBtn.style.display = "block"
    if (registerBtn) registerBtn.style.display = "block"
    if (logoutBtn) logoutBtn.style.display = "none"
    if (notificationIcon) notificationIcon.style.display = "none" // Hide notification bell

    if (bookingsAuthRequired) bookingsAuthRequired.style.display = "block"
    if (bookingsContent) bookingsContent.style.display = "none"
    if (profileAuthRequired) profileAuthRequired.style.display = "block"
    if (profileContent) profileContent.style.display = "none"
  }
}

function loadProducts() {
  const productsGrid = document.getElementById("productsGrid")
  const filterTabs = document.getElementById("dynamicFilterTabs")

  if (!productsGrid) return

  fetch("../../Backend/Artist/service_api.php?route=get_all_services")
    .then((res) => res.json())
    .then((data) => {
      if (data.success && Array.isArray(data.services)) {
        products = data.services

        // Get unique categories
        const categories = Array.from(new Set(products.map((p) => p.category).filter(Boolean)))
        let buttonsHtml = `<button class="filter-btn active" data-filter="all">All Designs</button>`
        categories.forEach((cat) => {
          buttonsHtml += `<button class="filter-btn" data-filter="${cat.toLowerCase()}">${cat}</button>`
        })

        if (filterTabs) {
          filterTabs.innerHTML = buttonsHtml

          // Add event listeners for filter buttons
          filterTabs.querySelectorAll(".filter-btn").forEach((btn) => {
            btn.addEventListener("click", (e) => {
              filterTabs.querySelectorAll(".filter-btn").forEach((b) => b.classList.remove("active"))
              e.target.classList.add("active")
              filterProducts(e.target.dataset.filter)
            })
          })
        }

        // Initial render: show all products
        productsGrid.innerHTML = products
          .map(
            (product) => `
                    <div class="product-card" data-category="${product.category ? product.category.toLowerCase() : ""}">
                        <img src="../../${product.image_path}" alt="${product.name}" class="product-image">
                        <div class="product-info">
                            <h3>${product.name}</h3>
                            <p>${product.description}</p>
                            <div class="product-price">Rs ${product.price}</div>
                            <button class="btn btn-primary" onclick="selectService('${product.name}', ${product.price})">Select Service</button>
                        </div>
                    </div>
                `,
          )
          .join("")
      } else {
        productsGrid.innerHTML = "<p>No services found.</p>"
      }
    })
    .catch((error) => {
      console.error("Error loading products:", error)
      productsGrid.innerHTML = "<p>Error loading services.</p>"
    })
}

function loadArtists() {
  const artistsGrid = document.getElementById("artistsGrid")
  if (!artistsGrid) return

  fetch("../../Backend/Admin/artist_api.php")
    .then((res) => res.json())
    .then((data) => {
      if (data.success && Array.isArray(data.artists)) {
        artists = data.artists.map((a) => ({
          id: a.id,
          name: a.name,
          specializations: a.specialty ? a.specialty.split(",").map((s) => s.trim()) : [],
          rating: null,
          experience: a.experience
            ? a.experience.toString().includes("year")
              ? a.experience
              : a.experience + " years"
            : "",
          image: a.profile_image
            ? "../../" + a.profile_image
            : "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg",
          bio: a.bio || "",
        }))

        artistsGrid.innerHTML = artists
          .map(
            (artist) => `
                    <div class="artist-card">
                        <img src="${artist.image}" alt="${artist.name}" class="artist-image">
                        <div class="artist-info">
                            <h3>${artist.name}</h3>
                            <p>${artist.bio}</p>
                            <div class="specializations">
                                ${artist.specializations.map((spec) => `<span class="specialization-tag">${spec}</span>`).join("")}
                            </div>
                            <div class="rating">${artist.rating !== null ? `★ ${artist.rating}` : ""} (${artist.experience} experience)</div>
                            <div style="display:flex;gap:1rem;margin-top:1rem;">
                                <button class="btn btn-primary" onclick="selectArtist('${artist.name}')">Select Artist</button>
                                <button class="btn btn-primary" onclick="showPortfolio(${artist.id}, '${artist.name}')">Portfolio</button>
                            </div>
                        </div>
                    </div>
                `,
          )
          .join("")
      } else {
        artistsGrid.innerHTML = "<p>No artists found.</p>"
      }
    })
    .catch((error) => {
      console.error("Error loading artists:", error)
      artistsGrid.innerHTML = "<p>Error loading artists.</p>"
    })
}

// ✅ Move this OUTSIDE loadArtists, so it’s global
function showPortfolio(artistId, artistName) {
  const portfolioModal = document.getElementById("portfolioModal")
  const portfolioGrid = document.getElementById("portfolioGrid")
  const portfolioTitle = document.getElementById("portfolioTitle")
  if (!portfolioModal || !portfolioGrid || !portfolioTitle) return

  portfolioTitle.textContent = `${artistName}'s Portfolio`
  portfolioGrid.innerHTML =
    '<div style="text-align:center;color:var(--light-text);padding:2rem;">Loading portfolio...</div>'
  portfolioModal.style.display = "flex"
  portfolioModal.classList.add("show")

  fetch(`../../Backend/Artist/design_api.php?route=get_by_artist_id&artist_id=${artistId}`)
    .then((res) => res.json())
    .then((data) => {
      if (data.success && Array.isArray(data.designs) && data.designs.length > 0) {
        let html = `
      <div style="
        display:grid;
        grid-template-columns:repeat(auto-fill, minmax(350px, 1fr));
        gap:1.5rem;
        padding:1rem;
      ">
    `
        data.designs.forEach((design) => {
          html += `
        <div class="portfolio-card">
          <div class="portfolio-image-wrapper">
            <img src="../../${design.image_path}" alt="${design.title}" class="portfolio-image">
            <div class="portfolio-overlay">
              <h4>${design.title}</h4>
              <p>${design.category}</p>
              <p>${design.description || ""}</p>
            </div>
          </div>
        </div>
      `
        })
        html += "</div>"
        portfolioGrid.innerHTML = html
      } else {
        portfolioGrid.innerHTML =
          '<div style="text-align:center;color:var(--light-text);padding:2rem;">No designs found for this artist.</div>'
      }
    })

    .catch(() => {
      portfolioGrid.innerHTML =
        '<div style="text-align:center;color:var(--danger-color);padding:2rem;">Error loading portfolio.</div>'
    })
}

document.addEventListener("DOMContentLoaded", () => {
  const closePortfolio = document.getElementById("closePortfolio")
  const portfolioModal = document.getElementById("portfolioModal")
  if (closePortfolio && portfolioModal) {
    closePortfolio.addEventListener("click", () => {
      portfolioModal.classList.remove("show")
      portfolioModal.style.display = "none"
    })
  }
  if (portfolioModal) {
    portfolioModal.addEventListener("click", (e) => {
      if (e.target === portfolioModal) {
        portfolioModal.classList.remove("show")
        portfolioModal.style.display = "none"
      }
    })
  }
})

function filterProducts(category) {
  const productCards = document.querySelectorAll(".product-card")

  productCards.forEach((card) => {
    if (category === "all" || card.dataset.category === category) {
      card.style.display = "block"
    } else {
      card.style.display = "none"
    }
  })
}

function selectService(serviceName, price) {
  if (!currentUser) {
    showLoginModal()
    return
  }

  showSection("bookings")
  const bookTab = document.querySelector('[data-tab="book"]')
  if (bookTab) bookTab.click()

  // Populate service selection
  const serviceSelect = document.getElementById("serviceType")
  if (serviceSelect) {
    serviceSelect.value = serviceName.toLowerCase().replace(/\s+/g, "")

    // If service not found in options, add it temporarily
    if (!serviceSelect.value) {
      const option = document.createElement("option")
      option.value = serviceName.toLowerCase().replace(/\s+/g, "")
      option.textContent = `${serviceName} - $${price}`
      serviceSelect.appendChild(option)
      serviceSelect.value = option.value
    }
  }
}

function selectArtist(artistName) {
  if (!currentUser) {
    showLoginModal()
    return
  }

  showSection("bookings")
  const bookTab = document.querySelector('[data-tab="book"]')
  if (bookTab) bookTab.click()

  // Populate artist selection
  const artistSelect = document.getElementById("artistSelect")
  if (artistSelect) {
    for (let i = 0; i < artistSelect.options.length; i++) {
      if (artistSelect.options[i].textContent === artistName) {
        artistSelect.selectedIndex = i
        break
      }
    }
  }
}

function populateArtistSelect() {
  const artistSelect = document.getElementById("artistSelect")
  if (!artistSelect) return

  artistSelect.innerHTML = '<option value="">Select Artist</option>'

  fetch("../../Backend/Admin/artist_api.php")
    .then((res) => res.json())
    .then((data) => {
      if (data.success && Array.isArray(data.artists)) {
        artistSelect.innerHTML += data.artists.map((a) => `<option value="${a.id}">${a.name}</option>`).join("")
        // Cache artist emails in a global map for quick lookup
        window._artistEmailMap = {};
        data.artists.forEach((a) => {
          window._artistEmailMap[a.id] = a.email;
        });
      } else {
        artistSelect.innerHTML += '<option value="">No artists found</option>'
      }

      // Add event listener to update Service Type and Offer dropdowns when artist changes
      artistSelect.addEventListener("change", () => {
        const serviceSelect = document.getElementById("serviceType")
        const offerSelect = document.getElementById("offerType")

        if (serviceSelect) serviceSelect.innerHTML = '<option value="">Select Service</option>'
        if (offerSelect) offerSelect.innerHTML = '<option value="">Select Offer</option>'

        const artistId = artistSelect.value

        // Log artist email to console
        if (artistId && data.artists) {
          const foundArtist = data.artists.find((a) => String(a.id) === String(artistId))
          if (foundArtist && foundArtist.email) {
            console.log("Selected artist email:", foundArtist.email)
          }
        }

        if (artistId) {
          // Fetch services for this artist
          fetch(`../../Backend/Artist/service_api.php?route=get_by_artist_id&artist_id=${artistId}`)
            .then((res) => res.json())
            .then((data) => {
              if (serviceSelect) {
                if (data.success && Array.isArray(data.services) && data.services.length > 0) {
                  serviceSelect.innerHTML += data.services
                    .map((s) => `<option value="${s.id}">${s.name} - Rs${s.price}</option>`)
                    .join("")
                } else {
                  serviceSelect.innerHTML += '<option value="">No services found for this artist</option>'
                }
              }
            })
            .catch(() => {
              if (serviceSelect) serviceSelect.innerHTML += '<option value="">Error loading services</option>'
            })

          // Fetch offers for this artist
          fetch(`../../Backend/Admin/offers_api.php?route=get_all_offers`)
            .then((res) => res.json())
            .then((data) => {
              if (offerSelect) {
                if (data.success && Array.isArray(data.offers)) {
                  const filteredOffers = data.offers.filter((o) => o.artist_id == artistId)
                  if (filteredOffers.length > 0) {
                    offerSelect.innerHTML += filteredOffers
                      .map((o) => `<option value="${o.id}">${o.name} - Rs${o.offer_price}</option>`)
                      .join("")
                  } else {
                    offerSelect.innerHTML += '<option value="">No offers found for this artist</option>'
                  }
                } else {
                  offerSelect.innerHTML += '<option value="">Error loading offers</option>'
                }
              }
            })
            .catch(() => {
              if (offerSelect) offerSelect.innerHTML += '<option value="">Error loading offers</option>'
            })
        }
      })
    })
    .catch(() => {
      artistSelect.innerHTML += '<option value="">Error loading artists</option>'
    })
}

function switchTab(clickedTab, tabGroup) {
  // Remove active class from all tabs in this group
  clickedTab.parentNode.querySelectorAll(".tab-btn").forEach((tab) => {
    tab.classList.remove("active")
  })

  // Add active class to clicked tab
  clickedTab.classList.add("active")

  // Hide all tab contents in this section
  const section = clickedTab.closest(".section")
  section.querySelectorAll(".tab-content").forEach((content) => {
    content.classList.remove("active")
  })

  // Show the selected tab content
  const tabName = clickedTab.dataset.tab
  const tabContent = section.querySelector(`#${tabName}`)
  if (tabContent) {
    tabContent.classList.add("active")
  }
}

function handleBooking(e) {
  const bookingDescriptionInput = document.getElementById("bookingDescription")
  const bookingPriceInput = document.getElementById("bookingPrice")
  e.preventDefault()

  if (!currentUser) {
    showLoginModal()
    return
  }

  const serviceTypeSelect = document.getElementById("serviceType")
  const artistSelect = document.getElementById("artistSelect")
  const dateInput = document.getElementById("appointmentDate")
  const timeInput = document.getElementById("appointmentTime")
  const clientAddressInput = document.getElementById("clientaddress")

  const offerTypeSelect = document.getElementById("offerType")
  if (!artistSelect || !dateInput || !timeInput) return

  // Determine select_type
  const bookingTypeRadio = document.querySelector('input[name="bookingType"]:checked')
  if (!bookingTypeRadio) {
    alert("Please select Service Type or Offer")
    return
  }
  const selectType = bookingTypeRadio.value // 'service' or 'offer'

  let serviceType = null
  let offer = null
  const description = bookingDescriptionInput ? bookingDescriptionInput.value : ""
  const price = bookingPriceInput ? bookingPriceInput.value : ""
  if (selectType === "service") {
    if (!serviceTypeSelect || !serviceTypeSelect.value) {
      alert("Please select a service type")
      return
    }
    serviceType = serviceTypeSelect.options[serviceTypeSelect.selectedIndex].text
  } else if (selectType === "offer") {
    if (!offerTypeSelect || !offerTypeSelect.value) {
      alert("Please select an offer")
      return
    }
    offer = offerTypeSelect.options[offerTypeSelect.selectedIndex].text
  }

  const artistId = artistSelect.value
  const date = dateInput.value
  const time = timeInput.value
  const clientAddress = clientAddressInput ? clientAddressInput.value : ""
  const status = "pending"

  if (!artistId || !date || !time) {
    alert("Please fill all required fields")
    return
  }

  // Get user_email from currentUser
  const userEmail = currentUser && currentUser.email ? currentUser.email : ""

  // Get artist_email from artistSelect (by searching the option list or fetching from API)
  let artistEmail = ""
  const artistOptions = artistSelect.options
  // Try to get artist email from a cached list if available
  if (window._artistEmailMap && artistId in window._artistEmailMap) {
    artistEmail = window._artistEmailMap[artistId]
  } else {
    // Fallback: fetch artist list and find email
    if (artistId) {
      fetch("../../Backend/Admin/artist_api.php")
        .then((res) => res.json())
        .then((data) => {
          if (data.success && Array.isArray(data.artists)) {
            const found = data.artists.find((a) => String(a.id) === String(artistId))
            if (found && found.email) {
              artistEmail = found.email
            }
          }
        })
    }
  }

  // Loader logic for Book Appointment button
  const bookingForm = document.getElementById("bookingForm");
  const bookBtn = bookingForm ? bookingForm.querySelector('button[type="submit"]') : null;
  let originalBtnContent = '';
  if (bookBtn) {
    originalBtnContent = bookBtn.innerHTML;
    bookBtn.disabled = true;
    bookBtn.innerHTML = `<div class="loader" style="width:32px;height:32px;min-width:32px;min-height:32px;display:inline-block;vertical-align:middle;">
      <div class="bar1"></div><div class="bar2"></div><div class="bar3"></div><div class="bar4"></div><div class="bar5"></div><div class="bar6"></div><div class="bar7"></div><div class="bar8"></div><div class="bar9"></div><div class="bar10"></div><div class="bar11"></div><div class="bar12"></div>
    </div>`;
  }
  fetch("../../Backend/Artist/booking_api.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      user_id: currentUser.id,
      user_email: userEmail,
      artist_id: artistId,
      artist_email: artistEmail,
      select_type: selectType,
      service_type: serviceType,
      offer: offer,
      date: date,
      time: time,
      client_address: clientAddress,
      description: description,
      price: price,
      status: status,
    }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (bookBtn) {
        bookBtn.disabled = false;
        bookBtn.innerHTML = originalBtnContent;
      }
      if (data.success) {
        showSuccess("Booking created successfully!")
        document.getElementById("bookingForm").reset()
        // Show payment summary inline
        const paymentSummaryInline = document.getElementById("paymentSummaryInline")
        if (paymentSummaryInline) {
          paymentSummaryInline.innerHTML = `
                    <h3>Payment Summary</h3>
                    <p><strong>Type:</strong> ${selectType === "service" ? "Service Type" : "Offer"}</p>
                    <p><strong>${selectType === "service" ? "Service" : "Offer"}:</strong> ${selectType === "service" ? serviceType : offer}</p>
                    <p><strong>Artist:</strong> ${artistId}</p>
                    <p><strong>Date:</strong> ${date}</p>
                    <p><strong>Time:</strong> ${time}</p>
                `
          paymentSummaryInline.style.display = "block"
        }
        loadUserBookings()
      } else {
        alert("Booking failed: " + (data.error || "Unknown error"))
      }
    })
    .catch((error) => {
      if (bookBtn) {
        bookBtn.disabled = false;
        bookBtn.innerHTML = originalBtnContent;
      }
      console.error("Booking error:", error)
      alert("Booking failed: Network error")
    })
}

function showPaymentModal(booking) {
  const modal = document.getElementById("paymentModal")
  const summary = document.getElementById("paymentSummary")

  if (modal && summary) {
    summary.innerHTML = `
            <h3>Payment Summary</h3>
            <p><strong>Service:</strong> ${booking.service}</p>
            <p><strong>Artist:</strong> ${booking.artist}</p>
            <p><strong>Date:</strong> ${booking.date}</p>
            <p><strong>Time:</strong> ${booking.time}</p>
            <div class="total">Total: ${booking.price}</div>
        `

    modal.classList.add("show")
  }
}
function loadUserBookings() {
  if (!currentUser) return

  const appointmentsList = document.getElementById("appointmentsList")
  const historyList = document.getElementById("historyList")
  if (!appointmentsList || !historyList) return

  // Fetch bookings for current user from backend
  fetch(`../../Backend/Artist/booking_api.php?user_id=${currentUser.id}`)
    .then((res) => res.json())
    .then((data) => {
      if (data.success && Array.isArray(data.bookings)) {
        const today = new Date().toISOString().slice(0, 10)
        const upcoming = []
        const past = []
        data.bookings.forEach((b) => {
          if (b.date >= today && !['cancelled by customer', 'cancelled', 'completed'].includes(b.status)) {
            upcoming.push(b)
          } else {
            past.push(b)
          }
        })

        // My Appointments (today and future, excluding cancelled/completed)
        if (upcoming.length === 0) {
          const existingHeader = appointmentsList.querySelector(".appointments-header")
          appointmentsList.innerHTML = ""
          if (existingHeader) {
            appointmentsList.appendChild(existingHeader)
          }
          appointmentsList.innerHTML +=
            '<div class="empty-state"><h3>No active appointments</h3><p>Book your first appointment to get started!</p></div>'
        } else {
          const existingHeader = appointmentsList.querySelector(".appointments-header")
          appointmentsList.innerHTML = ""
          if (existingHeader) {
            appointmentsList.appendChild(existingHeader)
          }

          appointmentsList.innerHTML += upcoming
            .map(
              (b) => {
                // Determine which buttons to show based on status
                let actionButtons = '';

                // Always show reschedule for non-cancelled bookings
                actionButtons += `<button class="btn btn-secondary btn-sm" onclick="rescheduleBooking(${b.id}, '${(b.select_type === "service" ? b.service_type : b.offer).replace(/'/g, "&#39;")}')">Reschedule</button>`;

                // Only show cancel button if status is not already cancelled
                if (!['cancelled by customer', 'cancelled'].includes(b.status)) {
                  actionButtons += `<button class="btn btn-danger btn-sm" onclick="cancelBooking(${b.id})">Cancel</button>`;
                }

                // Format status display
                let statusDisplay = b.status.toUpperCase();
                let statusClass = b.status.replace(/\s+/g, '-').toLowerCase();

                return `
                  <div class="appointment-item advanced-table-row">
                      <div class="table-col">${b.select_type === "service" ? b.service_type : b.offer}</div>
                      <div class="table-col">${b.description || ""}</div>
                      <div class="table-col">${b.price ? "Rs " + b.price : ""}</div>
                      <div class="table-col">${b.artist_id}</div>
                      <div class="table-col">${b.date} at ${b.time}</div>
                      <div class="table-col"><span class="status-badge status-${statusClass}">${statusDisplay}</span></div>
                      <div class="table-col">
                          ${actionButtons}
                      </div>
                  </div>
                `;
              }
            )
            .join("")
        }

        // History (past bookings and cancelled/completed)
        if (past.length === 0) {
          const existingHeader = historyList.querySelector(".history-header")
          historyList.innerHTML = ""
          if (existingHeader) {
            historyList.appendChild(existingHeader)
          }
          historyList.innerHTML +=
            '<div class="empty-state"><h3>No booking history</h3><p>Your completed bookings will appear here.</p></div>'
        } else {
          const existingHeader = historyList.querySelector(".history-header")
          historyList.innerHTML = ""
          if (existingHeader) {
            historyList.appendChild(existingHeader)
          }

          historyList.innerHTML += past
            .map(
              (b) => {
                let actionButtons = '';

                // Only show review button for completed bookings
                if (b.status === "completed" && b.review === "pending") {
                  actionButtons += `<button class="btn btn-primary btn-sm" onclick="addReview(${b.id}, '${b.select_type === "service" ? b.service_type : b.offer}')">Review</button>`;
                }

                // Show "Book Again" for all past bookings
                actionButtons += `<button class="btn btn-secondary btn-sm" onclick="rebookService('${b.select_type === "service" ? b.service_type : b.offer}')">Book Again</button>`;

                // Format status display
                let statusDisplay = b.status.toUpperCase();
                let statusClass = b.status.replace(/\s+/g, '-').toLowerCase();

                return `
                  <div class="history-item advanced-table-row">
                      <div class="table-col">${b.select_type === "service" ? b.service_type : b.offer}</div>
                      <div class="table-col">${b.description || ""}</div>
                      <div class="table-col">${b.price ? "Rs " + b.price : ""}</div>
                      <div class="table-col">${b.artist_id}</div>
                      <div class="table-col">${b.date} at ${b.time}</div>
                      <div class="table-col"><span class="status-badge status-${statusClass}">${statusDisplay}</span></div>
                      <div class="table-col">
                          ${actionButtons}
                      </div>
                  </div>
                `;
              }
            )
            .join("")
        }
      } else {
        // Error handling - keep headers but show error message
        const appointmentsHeader = appointmentsList.querySelector(".appointments-header")
        const historyHeader = historyList.querySelector(".history-header")

        appointmentsList.innerHTML = ""
        historyList.innerHTML = ""

        if (appointmentsHeader) appointmentsList.appendChild(appointmentsHeader)
        if (historyHeader) historyList.appendChild(historyHeader)

        appointmentsList.innerHTML += '<div class="empty-state"><h3>Error loading appointments.</h3></div>'
        historyList.innerHTML += '<div class="empty-state"><h3>Error loading history.</h3></div>'
      }
    })
    .catch(() => {
      // Error handling - keep headers but show error message
      const appointmentsHeader = appointmentsList.querySelector(".appointments-header")
      const historyHeader = historyList.querySelector(".history-header")

      appointmentsList.innerHTML = ""
      historyList.innerHTML = ""

      if (appointmentsHeader) appointmentsList.appendChild(appointmentsHeader)
      if (historyHeader) historyList.appendChild(historyHeader)

      appointmentsList.innerHTML += '<div class="empty-state"><h3>Error loading appointments.</h3></div>'
      historyList.innerHTML += '<div class="empty-state"><h3>Error loading history.</h3></div>'
    })
}

function completeBooking(bookingId) {
  const bookings = JSON.parse(localStorage.getItem("bookings") || "[]")
  const bookingIndex = bookings.findIndex((b) => b.id === bookingId)

  if (bookingIndex !== -1) {
    bookings[bookingIndex].status = "completed"
    bookings[bookingIndex].completedDate = new Date().toISOString()
    localStorage.setItem("bookings", JSON.stringify(bookings))

    showSuccess("Appointment marked as completed!")
    loadUserBookings()
  }
}

function rescheduleBooking(bookingId, serviceName) {
  // Open the reschedule modal and set booking ID
  const modal = document.getElementById("rescheduleModal");
  const bookingIdInput = document.getElementById("rescheduleBookingId");
  const dateInput = document.getElementById("rescheduleDate");
  const timeInput = document.getElementById("rescheduleTime");
  const modalTitle = modal ? modal.querySelector("h2") : null;

  if (modal && bookingIdInput && dateInput && timeInput) {
    bookingIdInput.value = bookingId;
    dateInput.value = "";
    timeInput.value = "";

    // Set minimum date to today
    const today = new Date().toISOString().split('T')[0];
    dateInput.min = today;

    if (modalTitle) {
      if (serviceName && serviceName.trim() !== "") {
        modalTitle.textContent = `Reschedule Appointment for ${serviceName}`;
      } else {
        modalTitle.textContent = "Reschedule Appointment";
      }
    }

    modal.classList.add("show");
  }
}

// Reschedule modal close logic
document.addEventListener("DOMContentLoaded", () => {
  const closeReschedule = document.getElementById("closeReschedule");
  const rescheduleModal = document.getElementById("rescheduleModal");
  if (closeReschedule && rescheduleModal) {
    closeReschedule.addEventListener("click", () => {
      rescheduleModal.classList.remove("show");
    });
  }
  // Close modal when clicking outside
  if (rescheduleModal) {
    rescheduleModal.addEventListener("click", (e) => {
      if (e.target === rescheduleModal) {
        rescheduleModal.classList.remove("show");
      }
    });
  }
});

// Handle reschedule form submit
document.addEventListener("DOMContentLoaded", () => {
  const rescheduleForm = document.getElementById("rescheduleForm");
  if (rescheduleForm) {
    rescheduleForm.addEventListener("submit", function (e) {
      e.preventDefault();

      const bookingId = document.getElementById("rescheduleBookingId").value;
      const newDate = document.getElementById("rescheduleDate").value;
      const newTime = document.getElementById("rescheduleTime").value;

      if (!bookingId || !newDate || !newTime) {
        alert("Please fill in all fields");
        return;
      }

      // Show loading state
      const submitBtn = rescheduleForm.querySelector('button[type="submit"]');
      const originalBtnText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = "Rescheduling...";

      // Create form data for PUT request
      const formData = new URLSearchParams();
      formData.append('id', bookingId);
      formData.append('date', newDate);
      formData.append('time', newTime);

      // Send PUT request to reschedule endpoint
      fetch("../../Backend/Artist/booking_api.php?route=reschedule", {
        method: "PUT",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: formData.toString()
      })
        .then(res => res.json())
        .then(data => {
          // Reset button state
          submitBtn.disabled = false;
          submitBtn.textContent = originalBtnText;

          if (data.success) {
            showSuccess("Appointment rescheduled successfully! The artist will be notified and needs to confirm the new schedule.");

            // Close modal
            const modal = document.getElementById("rescheduleModal");
            if (modal) modal.classList.remove("show");

            // Reset form
            rescheduleForm.reset();

            // Reload bookings to show updated data
            if (typeof loadUserBookings === 'function') {
              loadUserBookings();
            }
          } else {
            alert("Failed to reschedule appointment: " + (data.error || "Unknown error"));
          }
        })
        .catch(error => {
          // Reset button state
          submitBtn.disabled = false;
          submitBtn.textContent = originalBtnText;

          console.error("Reschedule error:", error);
          alert("Error rescheduling appointment. Please try again.");
        });
    });
  }
});

function cancelBooking(bookingId) {
  if (confirm("Are you sure you want to cancel this appointment?")) {
    // Show loading state
    const cancelBtn = document.querySelector(`button[onclick="cancelBooking(${bookingId})"]`);
    const originalText = cancelBtn ? cancelBtn.textContent : "";
    if (cancelBtn) {
      cancelBtn.disabled = true;
      cancelBtn.textContent = "Cancelling...";
    }

    // Create form data for PUT request
    const formData = new URLSearchParams();
    formData.append('id', bookingId);
    formData.append('status', 'cancelled by customer');

    // Send PUT request to update status endpoint
    fetch("../../Backend/Artist/booking_api.php?route=update_status", {
      method: "PUT",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: formData.toString()
    })
      .then(res => res.json())
      .then(data => {
        // Reset button state
        if (cancelBtn) {
          cancelBtn.disabled = false;
          cancelBtn.textContent = originalText;
        }

        if (data.success) {
          showSuccess("Appointment cancelled successfully.");
          loadUserBookings(); // Reload bookings to reflect the change
        } else {
          alert("Failed to cancel appointment: " + (data.error || "Unknown error"));
        }
      })
      .catch(error => {
        // Reset button state
        if (cancelBtn) {
          cancelBtn.disabled = false;
          cancelBtn.textContent = originalText;
        }

        console.error("Cancel booking error:", error);
        alert("Error cancelling appointment. Please try again.");
      });
  }
}

function rebookService(serviceName) {
  showSection("bookings")
  const bookTab = document.querySelector('[data-tab="book"]')
  if (bookTab) bookTab.click()

  // Try to pre-select the service
  const serviceSelect = document.getElementById("serviceType")
  if (serviceSelect) {
    for (let i = 0; i < serviceSelect.options.length; i++) {
      if (serviceSelect.options[i].textContent.includes(serviceName)) {
        serviceSelect.selectedIndex = i
        break
      }
    }
  }
}

function loadUserProfile() {
  if (!currentUser) return

  const profileNameInput = document.getElementById("profileName")
  const profileEmailInput = document.getElementById("profileEmail")
  const profilePhoneInput = document.getElementById("profilePhone")
  const profileAddressInput = document.getElementById("profileAddress")

  if (profileNameInput) profileNameInput.value = currentUser.name || ""
  if (profileEmailInput) profileEmailInput.value = currentUser.email || ""
  if (profilePhoneInput) profilePhoneInput.value = currentUser.phone || ""
  if (profileAddressInput) profileAddressInput.value = currentUser.address || ""

  // Show profile image if exists
  const imgPreview = document.getElementById("profileImagePreview")
  if (imgPreview) {
    if (currentUser.image_path) {
      imgPreview.src = "../../" + currentUser.image_path
      imgPreview.style.display = "inline-block"
    } else {
      imgPreview.style.display = "none"
    }
  }
}

function handleProfileUpdate(e) {
  e.preventDefault()
  if (!currentUser) return

  const profileNameInput = document.getElementById("profileName")
  const profileEmailInput = document.getElementById("profileEmail")
  const profilePhoneInput = document.getElementById("profilePhone")
  const profileAddressInput = document.getElementById("profileAddress")
  const imageInput = document.getElementById("profileImage")

  if (!profileNameInput || !profileEmailInput || !profilePhoneInput) return

  const formData = new FormData()
  formData.append("id", currentUser.id)
  formData.append("name", profileNameInput.value)
  formData.append("email", profileEmailInput.value)
  formData.append("phone", profilePhoneInput.value)
  if (profileAddressInput) formData.append("address", profileAddressInput.value)

  if (imageInput && imageInput.files.length > 0) {
    formData.append("image", imageInput.files[0])
  }

  fetch("../../Backend/Admin/user_api.php?route=update_profile", {
    method: "POST",
    body: formData,
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.success && data.user) {
        currentUser = data.user
        localStorage.setItem("currentUser", JSON.stringify(currentUser))
        showSuccess("Profile updated successfully!")
        updateAuthUI()
        loadUserProfile()
      } else {
        showSuccess("Profile update failed.")
      }
    })
    .catch(() => {
      showSuccess("Profile update failed.")
    })
}

function loadUserPayments() {
  if (!currentUser) return

  const payments = JSON.parse(localStorage.getItem("payments") || "[]")
  const userPayments = payments.filter((p) => p.userId === currentUser.id)

  const paymentsList = document.getElementById("paymentsList")
  if (!paymentsList) return

  if (userPayments.length === 0) {
    paymentsList.innerHTML =
      '<div class="empty-state"><h3>No payment history</h3><p>Your payment transactions will appear here.</p></div>'
  } else {
    paymentsList.innerHTML = userPayments
      .map(
        (payment) => `
            <div class="payment-item">
                <div class="payment-details">
                    <h4>Payment #${payment.id}</h4>
                    <p><strong>Amount:</strong> ${payment.amount}</p>
                    <p><strong>Method:</strong> ${payment.method} (**** ${payment.cardLast4})</p>
                    <p><strong>Date:</strong> ${new Date(payment.date).toLocaleDateString()}</p>
                    <span class="status-badge status-${payment.status}">${payment.status.toUpperCase()}</span>
                </div>
            </div>
        `,
      )
      .join("")
  }
}

function loadUserReviews() {
  if (!currentUser) return

  const reviewsList = document.getElementById("reviewsList")
  if (!reviewsList) return
  reviewsList.innerHTML =
    '<div style="text-align:center;color:var(--light-text);padding:2rem;">Loading reviews...</div>'

  fetch(`../../Backend/Artist/review_api.php?user_id=${currentUser.id}`)
    .then((res) => res.json())
    .then((data) => {
      if (data.success && data.reviews.length > 0) {
        reviewsList.innerHTML = ""
        data.reviews.forEach((review) => {
          const item = document.createElement("div")
          item.className = "review-item"
          item.innerHTML = `
                        <div class="review-header">
                            <span class="review-service">${review.service || ""}</span>
                            <span class="review-date">${new Date(review.created_at).toLocaleDateString()}</span>
                        </div>
                        <div class="review-rating">${"★".repeat(review.rating)}${"☆".repeat(5 - review.rating)}</div>
                        <div class="review-text">${review.review}</div>
                    `
          reviewsList.appendChild(item)
        })
      } else {
        reviewsList.innerHTML =
          '<div class="empty-state"><h3>No reviews yet<br>Write your first review after completing a service!</h3></div>'
      }
    })
    .catch(() => {
      reviewsList.innerHTML =
        '<div class="empty-state"><h3>No reviews yet<br>Write your first review after completing a service!</h3></div>'
    })
}

function addReview(bookingId, serviceName) {
  showSection("profile")
  const reviewsTab = document.querySelector('[data-tab="reviews"]')
  if (reviewsTab) reviewsTab.click()

  // Pre-select the service
  const serviceSelect = document.getElementById("reviewService")
  if (serviceSelect) {
    serviceSelect.value = bookingId
  }

  // Show review form
  const addReviewSection = document.getElementById("addReview")
  if (addReviewSection) {
    addReviewSection.style.display = "block"
  }
}

function updateStarRating() {
  document.querySelectorAll(".star").forEach((star, index) => {
    if (index < currentRating) {
      star.classList.add("active")
    } else {
      star.classList.remove("active")
    }
    // Set reviewRating when star is clicked
    star.onclick = () => {
      currentRating = index + 1
      updateStarRating()
    }
  })
}

function handleReviewSubmit(e) {
  e.preventDefault()
  if (!currentUser) return
  const reviewServiceSelect = document.getElementById("reviewService")
  const reviewTextArea = document.getElementById("reviewText")
  if (!reviewServiceSelect || !reviewTextArea) return
  const bookingId = reviewServiceSelect.value
  const rating = currentRating
  const text = reviewTextArea.value
  // Prevent submission if bookingId is empty, 'new', or not a number
  if (!bookingId || bookingId === "new" || isNaN(Number(bookingId)) || !rating || !text) {
    if (!bookingId || bookingId === "new" || isNaN(Number(bookingId)))
      console.error("Review submit: Invalid booking selected. bookingId:", bookingId)
    if (!rating) console.error("Review submit: rating is empty")
    if (!text) console.error("Review submit: review text is empty")
    alert("Please fill all fields and select a valid booking and rating")
    return
  }
  fetch(`../../Backend/Artist/booking_api.php?user_id=${currentUser.id}`)
    .then((res) => res.json())
    .then((data) => {
      if (data.success && Array.isArray(data.bookings)) {
        const booking = data.bookings.find((b) => b.id == bookingId)
        console.log("Selected booking:", booking)
        if (!booking) {
          console.error("Review submit: Invalid booking selected. bookingId:", bookingId)
          alert("Invalid booking selected")
          return
        }
        // Get artist_id, service, artist name
        const artist_id = booking.artist_id
        // If select_type is 'offer', use offer name only if it's not 'new'
        let service = ""
        if (booking.select_type === "offer") {
          service = booking.offer && booking.offer !== "new" ? booking.offer : ""
        } else {
          service = booking.service_type || ""
        }
        // Fetch artist name
        fetch("../../Backend/Admin/artist_api.php")
          .then((res) => res.json())
          .then((artistData) => {
            let artistName = ""
            if (artistData.success && Array.isArray(artistData.artists)) {
              const artistObj = artistData.artists.find((a) => a.id == artist_id)
              if (artistObj) artistName = artistObj.name
            }
            const postBody = {
              artist_id,
              user_id: currentUser.id,
              artist: artistName,
              service,
              rating,
              review: text,
              booking_id: bookingId, // Pass booking id to backend
            }
            console.log("Review submit POST body:", postBody)
            // POST review to backend
            fetch("../../Backend/Artist/review_api.php", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(postBody),
            })
              .then((res) => res.json())
              .then((resp) => {
                console.log("Review submit response:", resp)
                if (resp.success) {
                  showSuccess("Review submitted successfully!")
                  // Reset form
                  const reviewForm = document.getElementById("reviewForm")
                  if (reviewForm) reviewForm.reset()
                  currentRating = 0
                  updateStarRating()
                  // Reload reviews
                  loadUserReviews()
                  // Reload bookings so review status is updated in History tab
                  loadUserBookings()
                } else {
                  alert("Failed to submit review")
                }
              })
              .catch((err) => {
                console.error("Review submit error:", err)
                alert("Error submitting review")
              })
          })
      } else {
        console.error("Review submit: No bookings found for user", currentUser.id)
        alert("Invalid booking selected")
      }
    })
}

function formatCardNumber(e) {
  const value = e.target.value.replace(/\s+/g, "").replace(/[^0-9]/gi, "")
  const formattedValue = value.match(/.{1,4}/g)?.join(" ") || value
  e.target.value = formattedValue
}

function formatExpiryDate(e) {
  let value = e.target.value.replace(/\D/g, "")
  if (value.length >= 2) {
    value = value.substring(0, 2) + "/" + value.substring(2, 4)
  }
  e.target.value = value
}

function showSuccess(message) {
  const successMessage = document.getElementById("successMessage")
  const successModal = document.getElementById("successModal")

  if (successMessage) successMessage.textContent = message
  if (successModal) successModal.classList.add("show")
}

function loadStoredData() {
  const storedUser = localStorage.getItem("currentUser")
  if (storedUser) {
    currentUser = JSON.parse(storedUser)
  }
}

window.selectService = selectService
window.selectArtist = selectArtist
window.completeBooking = completeBooking
window.rescheduleBooking = rescheduleBooking
window.cancelBooking = cancelBooking
window.rebookService = rebookService
window.addReview = addReview
window.formatCardNumber = formatCardNumber
window.formatExpiryDate = formatExpiryDate
window.showPortfolio = showPortfolio
