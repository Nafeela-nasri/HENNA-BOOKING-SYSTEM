// Artist Panel JavaScript

// Global State
let currentSection = 'dashboard';
let currentUser = null;
let portfolioItems = [];
let services = [];
let bookings = [];
let customers = [];
let reviews = [];
let salesStatusChart = null;
let salesTopItemsBar = null;
let salesRevenueWeekday = null;
let salesRevenueTrend = null;
let chartBookingsMonthly = null;
let chartRevenueMonthly = null;
let chartTopItems = null;
let chartByWeekday = null;
let customerByMonthChart = null;
let customerNewReturningPieChart = null;
let customerTopSpendersChart = null;
let perfCompletionRateMonthlyChart = null;
let perfRatingTrendMonthlyChart = null;

// Dummy Data
const dummyData = {
    portfolioItems: [],

    services: [],

    bookings: [],

    customers: [],

    reviews: []
};

// Initialize Application
document.addEventListener('DOMContentLoaded', function () {
    initializeApp();
    setArtistHeaderProfile();
        const reportLinks = document.querySelectorAll('[data-section="sales"], [data-section="customer"], [data-section="inventory"], [data-section="performance"]');
    reportLinks.forEach(link => {
        link.addEventListener('click', handleNavigation);
    });

    // Load notifications for artist
    loadArtistNotifications();

    // Setup topbar and layout controls
    setupUIControls();
    applySavedThemePreference();
        // ===== REAL-TIME DATA POLLING (every 5 seconds) =====
        // Optimized real-time polling: fetch only visible section, poll every 2 seconds
        async function startRealtimePolling() {
            if (localStorage.getItem('Artistlogin') !== 'true') return;
            // Always update header
            setArtistHeaderProfile();
            // Fetch only the data for the current section
            switch (currentSection) {
                case 'dashboard':
                    await Promise.all([
                        loadDashboardStats(),
                        loadDashboardCharts()
                    ]);
                    break;
                case 'profile':
                    // Profile info is updated via setArtistHeaderProfile above
                    break;
                case 'portfolio':
                    await loadPortfolioFromBackend();
                    break;
                case 'services':
                    await loadServices();
                    break;
                case 'bookings':
                    await loadBookings();
                    break;
                case 'customers':
                    await loadCustomers();
                    break;
                case 'reviews':
                    await loadReviews();
                    break;
                case 'reports':
                    await generateReports();
                    break;
                default:
                    // Fallback: update dashboard
                    await Promise.all([
                        loadDashboardStats(),
                        loadDashboardCharts()
                    ]);
            }
        }

        // Start polling every 2 seconds for main data
        setInterval(startRealtimePolling, 2000);

        // Start polling notifications every 1 second for instant updates
        setInterval(function() {
            if (localStorage.getItem('Artistlogin') === 'true') {
                loadArtistNotifications();
            }
        }, 1000);

        // Also run once on load if logged in
        if (localStorage.getItem('Artistlogin') === 'true') {
            startRealtimePolling();
            loadArtistNotifications();
        }
        // Initialize report date inputs and attach listeners
        try {
            const startEl = document.getElementById('startDate');
            const endEl = document.getElementById('endDate');
            if (startEl && endEl) {
                const now = new Date();
                if (!startEl.value) startEl.value = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0,10);
                if (!endEl.value) endEl.value = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().slice(0,10);
                startEl.addEventListener('change', () => generateReports());
                endEl.addEventListener('change', () => generateReports());
                // Run once to populate reports
                generateReports();
            }
        } catch (e) { console.error('Error initializing report date inputs', e); }
});

// Topbar and layout controls
function setupUIControls() {
    const sidebar = document.getElementById('artistSidebar');
    const main = document.getElementById('artistMain');
    const collapseBtn = document.getElementById('collapseSidebarBtn');
    const toggleBtn = document.getElementById('sidebarToggleBtn');
    const profileToggle = document.getElementById('profileMenuToggle');
    const profileMenu = document.getElementById('profileMenu');
    const darkToggle = document.getElementById('darkModeToggle');
    const globalSearchInput = document.getElementById('globalSearchInput');

    // Collapse/expand (desktop) from sidebar header button
    if (collapseBtn && sidebar && main) {
        collapseBtn.addEventListener('click', function () {
            sidebar.classList.toggle('collapsed');
            main.classList.toggle('expanded');
        });
    }

    // Toggle sidebar (mobile hamburger)
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', function () {
            // On small screens we slide in/out, on large we collapse
            if (window.matchMedia('(max-width: 768px)').matches) {
                sidebar.classList.toggle('open');
            } else if (main) {
                sidebar.classList.toggle('collapsed');
                main.classList.toggle('expanded');
            }
        });
    }

    // Close mobile sidebar when clicking outside
    document.addEventListener('click', function (e) {
        if (!sidebar) return;
        if (window.matchMedia('(max-width: 768px)').matches && sidebar.classList.contains('open')) {
            const withinSidebar = sidebar.contains(e.target);
            const isToggle = toggleBtn && toggleBtn.contains(e.target);
            if (!withinSidebar && !isToggle) sidebar.classList.remove('open');
        }
    });

    // Profile menu toggle
    if (profileToggle && profileMenu) {
        profileToggle.addEventListener('click', function (e) {
            e.stopPropagation();
            profileMenu.classList.toggle('open');
        });
        document.addEventListener('click', function () {
            profileMenu.classList.remove('open');
        });
    }

    // Dark mode toggle + persistence
    if (darkToggle) {
        // Initialize switch state from storage
        const saved = localStorage.getItem('artistTheme');
        if (saved === 'dark') {
            darkToggle.checked = true;
            document.body.classList.add('theme-dark');
        }
        darkToggle.addEventListener('change', function () {
            if (darkToggle.checked) {
                document.body.classList.add('theme-dark');
                localStorage.setItem('artistTheme', 'dark');
            } else {
                document.body.classList.remove('theme-dark');
                localStorage.setItem('artistTheme', 'light');
            }
        });
    }

    // Global search (Enter key): route to Customers and apply filter
    if (globalSearchInput) {
        globalSearchInput.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                const term = globalSearchInput.value.trim();
                if (!term) return;
                showSection('customers');
                // Ensure customers are loaded, then filter
                setTimeout(() => {
                    const customerSearch = document.getElementById('customerSearch');
                    if (customerSearch) {
                        customerSearch.value = term;
                        const inputEvent = new Event('input', { bubbles: true });
                        customerSearch.dispatchEvent(inputEvent);
                    }
                }, 150);
            }
        });
    }
}

function applySavedThemePreference() {
    const saved = localStorage.getItem('artistTheme');
    if (saved === 'dark') {
        document.body.classList.add('theme-dark');
    } else if (saved === 'light') {
        document.body.classList.remove('theme-dark');
    }
}

// Fetch and render notifications for the artist
function loadArtistNotifications() {
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    const container = document.getElementById('artistNotificationsContainer');
    if (!container) return;
    if (!artistUser || !artistUser.id) {
        container.innerHTML = '<div style="padding:1rem;color:#888;">Login to see notifications.</div>';
        return;
    }
    // Fetch notifications for this artist (target_audience = artists, specific-artist, or all)
    // 1. Fetch artist-specific notifications
    fetch(`../../Backend/Admin/notification_api.php?artist_id=${artistUser.id}`)
        .then(res => res.json())
        .then(data => {
            let notifications = [];
            if (data.success && Array.isArray(data.notifications)) {
                notifications = data.notifications;
            }
            // 2. Fetch 'all' notifications (target_audience = 'all')
            fetch(`../../Backend/Admin/notification_api.php`)
                .then(res2 => res2.json())
                .then(data2 => {
                    if (data2.success && Array.isArray(data2.notifications)) {
                        // Filter only those with target_audience === 'all'
                        const allNotifs = data2.notifications.filter(n => n.target_audience === 'all');
                        notifications = [...allNotifs, ...notifications];
                    }
                    if (notifications.length) {
                        container.innerHTML = notifications.map(n => renderArtistNotification(n)).join('');
                    } else {
                        container.innerHTML = '<div style="padding:1rem;color:#888;">No notifications found.</div>';
                    }
                })
                .catch(() => {
                    if (notifications.length) {
                        container.innerHTML = notifications.map(n => renderArtistNotification(n)).join('');
                    } else {
                        container.innerHTML = '<div style="padding:1rem;color:#888;">Error loading notifications.</div>';
                    }
                });
        })
        .catch(() => {
            container.innerHTML = '<div style="padding:1rem;color:#888;">Error loading notifications.</div>';
        });
}

function renderArtistNotification(n) {
    // Choose icon based on title/message keywords
    let icon = 'fa-bell';
    if (/booking|confirm/i.test(n.title)) icon = 'fa-calendar-check';
    else if (/review/i.test(n.title)) icon = 'fa-star';
    else if (/service/i.test(n.title)) icon = 'fa-concierge-bell';
    // Format time (show date for now)
    let time = n.created_at ? n.created_at.split(' ')[0] : '';
    return `
        <div class="notification-item${n.status === 'unread' ? ' unread' : ''}">
            <i class="fas ${icon} notification-icon"></i>
            <div class="notification-content">
                <h4>${n.title}</h4>
                <p>${n.message}</p>
                <span class="notification-time">${time}</span>
            </div>
        </div>
    `;
}

function setArtistHeaderProfile() {
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    const imgEl = document.getElementById('artistHeaderProfileImg');
    const nameEl = document.getElementById('artistHeaderProfileName');
    if (artistUser && imgEl && nameEl) {
        let imgSrc = artistUser.profile_image;
        if (imgSrc && !imgSrc.startsWith('http')) {
            imgSrc = '../../' + imgSrc;
        }
        imgEl.src = imgSrc || 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop';
        nameEl.textContent = artistUser.name || '';
    }
}

function initializeApp() {
    // Portfolio: always load from backend
    loadPortfolioFromBackend();
    // Fetch services from backend for logged-in artist
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (artistUser && artistUser.id) {
        fetch(`../../Backend/Artist/service_api.php?artist_id=${artistUser.id}`)
            .then(res => res.json())
            .then(data => {
                if (data.success && Array.isArray(data.services)) {
                    services = data.services;
                    loadServices();
                }
            });
    } else {
        services = [];
    }
    // bookings will be loaded from backend, not dummy data
    customers = [...dummyData.customers];
    reviews = [...dummyData.reviews];
    // Profile preview will use backend data only

    // Setup event listeners
    setupEventListeners();

    // Check login state using 'Artistlogin' key
    if (localStorage.getItem('Artistlogin') === 'true') {
        showDashboard();
    } else {
        showLogin();
    }
}

function setupEventListeners() {
    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Navigation
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', handleNavigation);
    });

    // Profile form
    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', handleProfileUpdate);
        // Image upload preview
        const profileImageInput = document.getElementById('profileImage');
        if (profileImageInput) {
            profileImageInput.addEventListener('change', function (e) {
                const preview = document.getElementById('profileImagePreview');
                preview.innerHTML = '';
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function (ev) {
                        const img = document.createElement('img');
                        img.src = ev.target.result;
                        img.style.maxWidth = '120px';
                        img.style.borderRadius = '8px';
                        preview.innerHTML = '';
                        preview.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        }
    }

    // Upload form
    const uploadForm = document.getElementById('uploadForm');
    if (uploadForm) {
        uploadForm.addEventListener('submit', handleUploadDesign);
    }

    // Service form
    const serviceForm = document.getElementById('serviceForm');
    if (serviceForm) {
        serviceForm.addEventListener('submit', handleAddService);
    }

    // Filter tabs
    const filterTabs = document.querySelectorAll('.tab-btn');
    filterTabs.forEach(tab => {
        tab.addEventListener('click', handleFilterBookings);
    });

    // Customer search
    const customerSearch = document.getElementById('customerSearch');
    if (customerSearch) {
        customerSearch.addEventListener('input', handleCustomerSearch);
    }
}

// Authentication Functions
function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    fetch('../../Backend/Admin/artist_api.php?email=' + encodeURIComponent(email) + '&password=' + encodeURIComponent(password))
        .then(res => res.json())
        .then(data => {
            if (data.success && data.artist) {
                // Fetch full artist profile to get profile_image
                fetch('../../Backend/Admin/artist_api.php')
                    .then(res => res.json())
                    .then(profileData => {
                        let profileImage = '';
                        if (profileData.success && Array.isArray(profileData.artists)) {
                            const artist = profileData.artists.find(a => a.id == data.artist.id);
                            if (artist && artist.profile_image) {
                                profileImage = artist.profile_image;
                            }
                        }
                        currentUser = {
                            id: data.artist.id,
                            name: data.artist.name,
                            email: data.artist.email,
                            profile_image: profileImage
                        };
                        localStorage.setItem('artistUser', JSON.stringify(currentUser));
                        localStorage.setItem('Artistlogin', 'true');
                        showDashboard();
                        if (profileImage) {
                            document.getElementById('profileAvatar').src = `../../${profileImage}`;
                        }
                    });
            } else {
                alert(data.error || 'Invalid credentials.');
            }
        })
        .catch(() => {
            alert('Login failed. Please try again.');
        });
}


function logout() {
    currentUser = null;
    localStorage.removeItem('artistUser');
    localStorage.removeItem('Artistlogin');
    showLogin();
}

function showLogin() {
    document.getElementById('loginScreen').style.display = 'flex';
    document.getElementById('dashboardScreen').style.display = 'none';
}

function showDashboard() {
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('dashboardScreen').style.display = 'flex';

    setArtistHeaderProfile();

    // Load initial section
    showSection('dashboard');
    // Load dashboard charts
    loadDashboardCharts();
    // Load dashboard stat cards (live data)
    loadDashboardStats();
    // Auto-fill profile info from backend
    autoFillProfile();
    // Auto-fill profile info from backend using artistUser.id
    function autoFillProfile() {
        const artistUser = JSON.parse(localStorage.getItem('artistUser'));
        if (!artistUser || !artistUser.id) return;
        fetch(`../../Backend/Admin/artist_api.php`)
            .then(res => res.json())
            .then(data => {
                if (data.success && Array.isArray(data.artists)) {
                    const artist = data.artists.find(a => a.id == artistUser.id);
                    if (artist) {
                        // Fill form fields
                        document.getElementById('fullName').value = artist.name || '';
                        document.getElementById('phone').value = artist.phone || '';
                        document.getElementById('location').value = artist.location || '';
                        document.getElementById('experience').value = artist.experience || '';
                        document.getElementById('bio').value = artist.bio || '';
                        document.getElementById('specialties').value = artist.specialty || '';

                        // Fill profile header preview
                        if (artist.profile_image) {
                            // Split path and encode only the filename
                            const parts = artist.profile_image.split('/');
                            const fileName = encodeURIComponent(parts.pop());
                            const imagePath = parts.join('/') + '/' + fileName;
                            document.getElementById('profileAvatar').src = `../../${imagePath}`;
                        } else {
                            document.getElementById('profileAvatar').src = '';
                        }
                        document.getElementById('profileName').textContent = artist.name || '';
                        document.getElementById('profileBio').textContent = artist.bio || 'Professional Henna Artist';
                        document.getElementById('profileExperience').innerHTML = `<i class='fas fa-calendar'></i> ${artist.experience ? artist.experience + ' Years Experience' : ''}`;
                        document.getElementById('profileLocation').innerHTML = `<i class='fas fa-map-marker-alt'></i> ${artist.location || ''}`;
                    }
                }
            });
    }
}

// Navigation Functions
function handleNavigation(e) {
    e.preventDefault();

    const element = e.currentTarget;
    const sectionName = element.dataset.section;

    if (!sectionName) {
        console.error("No section data found");
        return;
    }

    // Check if this is a report subsection
    const reportSections = ['sales', 'customer', 'inventory', 'performance'];

    if (reportSections.includes(sectionName)) {
        // Handle report subsection
        showReportSection(sectionName);
    } else {
        // Handle main section
        showSection(sectionName);
    }

    // Update active nav item
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    element.classList.add('active');
}

function showSection(sectionName) {
    currentSection = sectionName;

    // Hide all main content sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });

    // Show selected section
    const targetSection = document.getElementById(sectionName);
    if (targetSection) {
        targetSection.classList.add('active');
    } else {
        console.error(`Section not found: ${sectionName}`);
    }

    // Update page title
    const pageTitle = document.getElementById('pageTitle');
    if (pageTitle) {
        pageTitle.textContent = sectionName.charAt(0).toUpperCase() + sectionName.slice(1);
    }

    // Load section-specific content
    switch (sectionName) {
        case 'portfolio':
            loadPortfolioFromBackend();
            break;
        case 'services':
            loadServices();
            break;
        case 'bookings':
            loadBookings();
            break;
        case 'customers':
            loadCustomers();
            break;
        case 'reviews':
            loadReviews();
            break;
        case 'reports':
            // Show the main reports section and default to sales report
            showReportSection('sales');
            break;
        case 'dashboard':
            loadDashboardCharts();
            loadDashboardStats();
            break;
    }
}

// Portfolio Functions
function loadPortfolio() {
    const portfolioGrid = document.getElementById('portfolioGrid');
    if (!portfolioGrid) return;
    if (!portfolioItems.length) {
        portfolioGrid.innerHTML = '<p>No designs uploaded yet.</p>';
        return;
    }
    portfolioGrid.innerHTML = portfolioItems.map(item => `
        <div class="portfolio-item">
            <img src="${item.image}" alt="${item.title}" class="portfolio-image">
            <div class="portfolio-info">
                <h4>${item.title}</h4>
                <p>${item.description}</p>
                <span class="portfolio-category">${item.category}</span>
            </div>
        </div>
    `).join('');
}

function openUploadModal() {
    const modal = document.getElementById('uploadModal');
    modal.classList.add('active');
}

function handleUploadDesign(e) {
    e.preventDefault();
    const title = document.getElementById('designTitle').value.trim();
    const category = document.getElementById('designCategory').value;
    const imageInput = document.getElementById('designImage');
    const description = document.getElementById('designDescription').value.trim();

    if (!title || !category || !imageInput.files.length) {
        alert('Please fill all required fields and select an image.');
        return;
    }

    // Get artist ID from localStorage
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) {
        alert('Artist not logged in.');
        return;
    }

    // Prepare form data
    const formData = new FormData();
    formData.append('artist_id', artistUser.id);
    formData.append('title', title);
    formData.append('category', category);
    formData.append('description', description);
    formData.append('image', imageInput.files[0]);

    // Send POST request to backend
    fetch('../../Backend/Artist/design_api.php', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Design uploaded successfully!');
                document.getElementById('uploadForm').reset();
                closeModal('uploadModal');
                // Fast refresh: reload portfolio immediately
                setTimeout(loadPortfolioFromBackend, 100);
            } else {
                alert(data.message || 'Upload failed.');
            }
        })
        .catch(() => {
            alert('Network error. Please try again.');
        });
}

// Load portfolio items from backend
function loadPortfolioFromBackend() {
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) return;
    fetch(`../../Backend/Artist/design_api.php?route=get_by_artist_id&artist_id=${artistUser.id}`)
        .then(res => res.json())
        .then(data => {
            if (data.success && Array.isArray(data.designs)) {
                portfolioItems = data.designs.map(item => ({
                    id: item.id,
                    title: item.title,
                    category: item.category,
                    image: item.image_path.startsWith('http') ? item.image_path : '../../' + item.image_path,
                    description: item.description,
                    uploadDate: item.created_at ? item.created_at.split('T')[0] : ''
                }));
            } else {
                portfolioItems = [];
            }
            loadPortfolio();
        });
}

// Services Functions
function loadServices() {
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) return;
    fetch(`../../Backend/Artist/service_api.php?route=get_by_artist_id&artist_id=${artistUser.id}`)
        .then(res => res.json())
        .then(data => {
            if (data.success && Array.isArray(data.services)) {
                services = data.services;
            } else {
                services = [];
            }
            const servicesGrid = document.getElementById('servicesGrid');
            if (!servicesGrid) return;
            servicesGrid.innerHTML = services.length === 0 ? '<p>No services found.</p>' : services.map(service => {
                let cardHtml = window.renderServiceCard ? window.renderServiceCard(service) : '';
                // Add actions below the card
                cardHtml += `<div class='service-actions' style='padding:8px;text-align:right;'>
                    <button class='btn btn-sm btn-primary' onclick='editService(${service.id})'>Edit</button>
                    <button class='btn btn-sm btn-secondary' onclick='toggleService(${service.id})'>${service.active == 1 ? 'Deactivate' : 'Activate'}</button>
                </div>`;
                return `<div class='service-card'>${cardHtml}</div>`;
            }).join('');
        });
}

function openServiceModal() {
    const modal = document.getElementById('serviceModal');
    modal.classList.add('active');
}

function handleAddService(e) {
    e.preventDefault();

    const name = document.getElementById('serviceName').value;
    const price = parseInt(document.getElementById('servicePrice').value);
    const duration = parseFloat(document.getElementById('serviceDuration').value);
    const description = document.getElementById('serviceDescription').value;
    const imageInput = document.getElementById('serviceImage');
    const imageFile = imageInput && imageInput.files.length > 0 ? imageInput.files[0] : null;

    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) return;

    const formData = new FormData();
    formData.append('artist_id', artistUser.id);
    formData.append('name', name);
    formData.append('price', price);
    formData.append('duration', duration);
    formData.append('description', description);
    formData.append('category', 'custom');
    formData.append('active', 1);
    if (imageFile) {
        formData.append('serviceImage', imageFile);
    }

    fetch('../../Backend/Artist/service_api.php', {
        method: 'POST',
        body: formData
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                // Refresh services from backend
                fetch(`../../Backend/Artist/service_api.php?artist_id=${artistUser.id}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.success && Array.isArray(data.services)) {
                            services = data.services;
                            loadServices();
                        }
                    });
                closeModal('serviceModal');
                document.getElementById('serviceForm').reset();
                alert('Service added successfully!');
            } else {
                alert('Failed to add service: ' + (data.error || 'Unknown error'));
            }
        });
}

function editService(id) {
    const service = services.find(s => s.id == id);
    if (!service) return;
    document.getElementById('serviceName').value = service.name;
    document.getElementById('servicePrice').value = service.price;
    document.getElementById('serviceDuration').value = service.duration;
    document.getElementById('serviceDescription').value = service.description;
    openServiceModal();
    // On submit, update service in backend
    const serviceForm = document.getElementById('serviceForm');
    serviceForm.onsubmit = function (e) {
        e.preventDefault();
        const artistUser = JSON.parse(localStorage.getItem('artistUser'));
        if (!artistUser || !artistUser.id) return;
        const updatedService = {
            id: service.id,
            artist_id: artistUser.id,
            name: document.getElementById('serviceName').value,
            price: parseInt(document.getElementById('servicePrice').value),
            duration: parseFloat(document.getElementById('serviceDuration').value),
            description: document.getElementById('serviceDescription').value,
            category: service.category,
            active: service.active
        };
        fetch('../../Backend/Artist/service_api.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updatedService)
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    fetch(`../../Backend/Artist/service_api.php?artist_id=${artistUser.id}`)
                        .then(res => res.json())
                        .then(data => {
                            if (data.success && Array.isArray(data.services)) {
                                services = data.services;
                                loadServices();
                            }
                        });
                    closeModal('serviceModal');
                    document.getElementById('serviceForm').reset();
                    alert('Service updated successfully!');
                } else {
                    alert('Failed to update service: ' + (data.error || 'Unknown error'));
                }
            });
        // Restore default submit after edit
        serviceForm.onsubmit = handleAddService;
    };
}

function toggleService(id) {
    const service = services.find(s => s.id == id);
    if (!service) return;
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) return;
    const updatedService = {
        id: service.id,
        artist_id: artistUser.id,
        name: service.name,
        price: service.price,
        duration: service.duration,
        description: service.description,
        category: service.category,
        active: service.active == 1 ? 0 : 1
    };
    fetch('../../Backend/Artist/service_api.php', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedService)
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                fetch(`../../Backend/Artist/service_api.php?artist_id=${artistUser.id}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.success && Array.isArray(data.services)) {
                            services = data.services;
                            loadServices();
                        }
                    });
            } else {
                alert('Failed to update service status: ' + (data.error || 'Unknown error'));
            }
        });
}

// Calendar Functions
function loadCalendar() {
    const calendarGrid = document.getElementById('calendarGrid');
    if (!calendarGrid) return;

    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();

    // Update month display
    const monthNames = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];
    document.getElementById('currentMonth').textContent = `${monthNames[currentMonth]} ${currentYear}`;

    // Generate calendar days
    const firstDay = new Date(currentYear, currentMonth, 1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();

    let calendarHTML = '';

    // Day headers
    const dayHeaders = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    dayHeaders.forEach(day => {
        calendarHTML += `<div class="calendar-day-header">${day}</div>`;
    });

    // Previous month days
    for (let i = 0; i < startingDay; i++) {
        const prevDate = new Date(currentYear, currentMonth, -startingDay + i + 1);
        calendarHTML += `<div class="calendar-day other-month">${prevDate.getDate()}</div>`;
    }

    // Current month days
    for (let day = 1; day <= daysInMonth; day++) {
        const isToday = day === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear();
        const hasAppointment = bookings.some(booking => {
            const bookingDate = new Date(booking.date);
            return bookingDate.getDate() === day &&
                bookingDate.getMonth() === currentMonth &&
                bookingDate.getFullYear() === currentYear;
        });

        const classes = ['calendar-day'];
        if (isToday) classes.push('today');
        if (hasAppointment) classes.push('has-appointment');

        calendarHTML += `
            <div class="${classes.join(' ')}">
                ${day}
                ${hasAppointment ? '<div class="appointment-dot"></div>' : ''}
            </div>
        `;
    }

    calendarGrid.innerHTML = calendarHTML;
}

// Booking Functions
function loadBookings(filter = 'all') {
    const bookingsList = document.getElementById('bookingsList');
    if (!bookingsList) return;

    // Get artistUser from localStorage
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) {
        bookingsList.innerHTML = '<div class="empty-state">Artist not logged in.</div>';
        return;
    }

    // Fetch bookings from backend by artist_id
    fetch(`../../Backend/Artist/booking_api.php?artist_id=${artistUser.id}`)
        .then(res => res.json())
        .then(data => {
            if (data.success && Array.isArray(data.bookings)) {
                let filteredBookings = filter === 'all' ? data.bookings : data.bookings.filter(b => b.status === filter);

                // ---- UPDATED SALES REPORT CALCULATIONS ----
                calculateSalesReport(data.bookings); // Pass all bookings for full report calculation
                renderSalesStatusChart(data.bookings);

                // ---- RENDER BOOKINGS LIST ----
                if (filteredBookings.length === 0) {
                    bookingsList.innerHTML = '<div class="empty-state">No bookings found.</div>';
                    return;
                }

                // Fetch all users once for mapping user_id to name/phone
                fetch('../../Backend/Admin/user_api.php')
                    .then(res => res.json())
                    .then(userData => {
                        let users = (userData.success && Array.isArray(userData.users)) ? userData.users : [];
                        bookingsList.innerHTML = filteredBookings.map(booking => {
                            // Display service_type or offer
                            let serviceOrOffer = booking.service_type ? booking.service_type : (booking.offer ? booking.offer : '');
                            // Find user by booking.user_id
                            let user = users.find(u => u.id == booking.user_id);
                            let customerName = user ? user.name : (booking.user_id ? `${booking.user_id}` : '');
                            let customerPhone = user ? user.phone : '';
                            let userEmail = booking.user_email || 'email';
                            // Date and time
                            let dateTime = `${formatDate(booking.date)} at ${booking.time}`;
                            // Client address
                            let clientAddress = booking.client_address || '';
                            // Price
                            let price = booking.price ? `Rs${booking.price}` : '';
                            let description = booking.description ? booking.description : '';
                            let status = booking.status;
                            // Actions
                            let actions = '';
                            if (status === 'pending') {
                                actions += `<button class="btn btn-sm btn-primary" onclick="updateBookingStatus(${booking.id}, 'confirmed')">Confirm</button>`;
                                actions += `<button class="btn btn-sm btn-secondary" onclick="updateBookingStatus(${booking.id}, 'cancelled')">Cancel</button>`;
                                actions += `<button class="btn btn-sm btn-secondary" onclick="contactCustomer('${customerPhone}')">Contact</button>`;
                            } else if (status === 'confirmed') {
                                actions += `<button class="btn btn-sm btn-primary" onclick="updateBookingStatus(${booking.id}, 'completed')">Mark Complete</button>`;
                                actions += `<button class="btn btn-sm btn-secondary" onclick="contactCustomer('${customerPhone}')">Contact</button>`;
                            } else if (status === 'cancelled') {
                                actions += `<button class="btn btn-sm btn-secondary" onclick="contactCustomer('${customerPhone}')">Contact</button>`;
                            } else if (status === 'completed') {
                                actions += `<button class="btn btn-sm btn-secondary" onclick="contactCustomer('${customerPhone}')">Contact</button>`;
                            }
                            return `
                                <div class="booking-card">
                                    <div class="booking-header">
                                        <div class="booking-details">
                                            <h4>${serviceOrOffer}</h4>
                                            <p><i class="fas fa-user"></i> ${customerName}</p>
                                            <p><i class="fas fa-user"></i> ${userEmail}</p>
                                            <p><i class="fas fa-calendar"></i> ${dateTime}</p>
                                            <p><i class="fas fa-phone"></i> ${clientAddress}</p>
                                            <p><i class="fas fa-dollar-sign"></i> ${price}</p>
                                            ${description ? `<p><i class="fas fa-sticky-note"></i> ${description}</p>` : ''}
                                        </div>
                                        <span class="booking-status ${status}">${status}</span>
                                    </div>
                                    <div class="booking-actions">
                                        ${actions}
                                    </div>
                                </div>
                            `;
                        }).join('');
                    })
                    .catch(() => {
                        bookingsList.innerHTML = '<div class="empty-state">Error loading users for bookings.</div>';
                    });
            } else {
                bookingsList.innerHTML = '<div class="empty-state">Error loading bookings.</div>';
            }
        })
        .catch(() => {
            bookingsList.innerHTML = '<div class="empty-state">Error loading bookings.</div>';
        });
}

function calculateSalesReport(allBookings) {
    // Filter bookings for revenue calculation (only confirmed and completed)
    const revenueBookings = allBookings.filter(booking => 
        booking.status === 'confirmed' || booking.status === 'completed'
    );

    // Calculate total revenue (only from confirmed/completed bookings)
    let totalRevenue = 0;
    revenueBookings.forEach(booking => {
        if (booking.price) {
            const price = parseFloat(booking.price.toString().replace(/[^0-9.]/g, "")) || 0;
            totalRevenue += price;
        }
    });

    // Calculate total confirmed/completed bookings
    const totalBookings = revenueBookings.length;

    // Calculate total cancelled bookings
    const totalCancelled = allBookings.filter(booking => 
        booking.status === 'cancelled' || booking.status === 'cancelled by customer'
    ).length;

    // Calculate average order value
    const averageOrderValue = totalBookings > 0 ? (totalRevenue / totalBookings) : 0;

    // Find most ordered item (from all bookings regardless of status)
    const itemCounts = {};
    allBookings.forEach(booking => {
        let serviceOrOffer = booking.service_type ? booking.service_type : (booking.offer ? booking.offer : 'Unknown');
        // Clean up the service/offer name (remove price if included)
        if (serviceOrOffer && serviceOrOffer.includes(' - Rs')) {
            serviceOrOffer = serviceOrOffer.split(' - Rs')[0];
        }
        itemCounts[serviceOrOffer] = (itemCounts[serviceOrOffer] || 0) + 1;
    });

    let mostOrderedItem = "-";
    if (Object.keys(itemCounts).length > 0) {
        mostOrderedItem = Object.entries(itemCounts).reduce((a, b) => a[1] > b[1] ? a : b)[0];
    }

    // Update the UI elements
    const totalRevenueEl = document.getElementById("totalRevenue");
    const totalBookingsEl = document.getElementById("totalBookings");
    const totalCancelledEl = document.getElementById("totalCancelled");
    const averageOrderEl = document.getElementById("averageOrder");
    const mostOrderedEl = document.getElementById("mostOrdered");

    if (totalRevenueEl) totalRevenueEl.textContent = `Rs${totalRevenue.toLocaleString()}`;
    if (totalBookingsEl) totalBookingsEl.textContent = totalBookings;
    if (totalCancelledEl) totalCancelledEl.textContent = totalCancelled;
    if (averageOrderEl) averageOrderEl.textContent = `Rs${Math.round(averageOrderValue)}`;
    if (mostOrderedEl) mostOrderedEl.textContent = mostOrderedItem;

    console.log("Sales Report Updated:", {
        totalRevenue,
        totalBookings,
        totalCancelled,
        averageOrderValue,
        mostOrderedItem
    });
}

function getStatusCounts(allBookings) {
    const counts = {
        pending: 0,
        confirmed: 0,
        completed: 0,
        cancelled: 0,
        cancelledByCustomer: 0
    };
    allBookings.forEach(b => {
        const s = (b.status || '').toLowerCase();
        if (s === 'pending') counts.pending++;
        else if (s === 'confirmed') counts.confirmed++;
        else if (s === 'completed') counts.completed++;
        else if (s === 'cancelled') counts.cancelled++;
        else if (s === 'cancelled by customer') counts.cancelledByCustomer++;
    });
    return counts;
}

function renderSalesStatusChart(allBookings) {
    const canvas = document.getElementById('salesStatusPie');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const counts = getStatusCounts(allBookings);
    const labels = ['Pending', 'Confirmed', 'Completed', 'Cancelled', 'Cancelled by Customer'];
    const data = [
        counts.pending,
        counts.confirmed,
        counts.completed,
        counts.cancelled,
        counts.cancelledByCustomer
    ];

    if (salesStatusChart) {
        salesStatusChart.data.labels = labels;
        salesStatusChart.data.datasets[0].data = data;
        salesStatusChart.update();
        return;
    }

    salesStatusChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels,
            datasets: [{
                data,
                backgroundColor: ['#f59e0b', '#3b82f6', '#10b981', '#ef4444', '#a855f7'],
                borderColor: '#ffffff',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom' },
                tooltip: { enabled: true }
            }
        }
    });
}

function renderSalesTopItemsBar(allBookings) {
    const canvas = document.getElementById('salesTopItemsBar');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const { labels, data } = topItemsData(allBookings, 8);

    if (salesTopItemsBar) {
        salesTopItemsBar.data.labels = labels;
        salesTopItemsBar.data.datasets[0].data = data;
        salesTopItemsBar.update();
        return;
    }

    salesTopItemsBar = new Chart(ctx, {
        type: 'bar',
        data: {
            labels,
            datasets: [{
                label: 'Top Items',
                data,
                backgroundColor: '#6366f1'
            }]
        },
        options: {
            responsive: true,
            scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
            plugins: { legend: { display: false } }
        }
    });
}

function revenueByWeekdayData(bookingsArr) {
    const labels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const sums = Array(7).fill(0);
    bookingsArr.forEach(b => {
        const s = (b.status || '').toLowerCase();
        if (s !== 'confirmed' && s !== 'completed') return;
        const d = new Date(b.date);
        if (isNaN(d)) return;
        const idx = d.getDay();
        const price = b.price ? parseFloat(b.price.toString().replace(/[^0-9.]/g, '')) || 0 : 0;
        sums[idx] += price;
    });
    return { labels, data: sums };
}

function renderSalesRevenueWeekday(allBookings) {
    const canvas = document.getElementById('salesRevenueWeekday');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const { labels, data } = revenueByWeekdayData(allBookings);
    if (salesRevenueWeekday) {
        salesRevenueWeekday.data.labels = labels;
        salesRevenueWeekday.data.datasets[0].data = data;
        salesRevenueWeekday.update();
        return;
    }
    salesRevenueWeekday = new Chart(ctx, {
        type: 'bar',
        data: {
            labels,
            datasets: [{
                label: 'Revenue by Weekday (Rs)',
                data,
                backgroundColor: '#22c55e'
            }]
        },
        options: {
            responsive: true,
            scales: { y: { beginAtZero: true } },
            plugins: { legend: { display: false } }
        }
    });
}

function revenueTrendLastNDays(bookingsArr, days = 30) {
    const today = new Date();
    const map = new Map();
    for (let i = days - 1; i >= 0; i--) {
        const d = new Date(today.getFullYear(), today.getMonth(), today.getDate() - i);
        const key = d.toISOString().slice(0, 10);
        map.set(key, 0);
    }
    bookingsArr.forEach(b => {
        const s = (b.status || '').toLowerCase();
        if (s !== 'confirmed' && s !== 'completed') return;
        const key = (new Date(b.date)).toISOString().slice(0, 10);
        if (!map.has(key)) return;
        const price = b.price ? parseFloat(b.price.toString().replace(/[^0-9.]/g, '')) || 0 : 0;
        map.set(key, map.get(key) + price);
    });
    const labels = Array.from(map.keys()).map(k => {
        const d = new Date(k);
        return `${d.getMonth() + 1}/${d.getDate()}`;
    });
    const data = Array.from(map.values());
    return { labels, data };
}

function renderSalesRevenueTrend(allBookings) {
    const canvas = document.getElementById('salesRevenueTrend');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const { labels, data } = revenueTrendLastNDays(allBookings, 30);
    if (salesRevenueTrend) {
        salesRevenueTrend.data.labels = labels;
        salesRevenueTrend.data.datasets[0].data = data;
        salesRevenueTrend.update();
        return;
    }
    salesRevenueTrend = new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [{
                label: 'Revenue (Last 30 Days) Rs',
                data,
                borderColor: '#0ea5e9',
                backgroundColor: 'rgba(14,165,233,0.15)',
                fill: true,
                tension: 0.35
            }]
        },
        options: {
            responsive: true,
            scales: { y: { beginAtZero: true } },
            plugins: { legend: { display: false } }
        }
    });
}

// Export Sales Report card to PDF
async function downloadSalesReport() {
    const card = document.getElementById('sales-report');
    if (!card) return;

    // Ensure chart is rendered before capture
    await new Promise(r => setTimeout(r, 200));

    const canvas = await html2canvas(card, { scale: 2, useCORS: true });
    const imgData = canvas.toDataURL('image/png');
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('p', 'mm', 'a4');

    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();

    const imgWidth = pageWidth - 20; // margins
    const imgHeight = canvas.height * imgWidth / canvas.width;

    let y = 10;
    pdf.addImage(imgData, 'PNG', 10, y, imgWidth, imgHeight);
    pdf.save('sales-report.pdf');
}

// Generic artist report PDF downloader (by report card id)
async function downloadArtistReport(reportId) {
    const card = document.getElementById(reportId);
    if (!card) return;
    await new Promise(r => setTimeout(r, 200));
    const canvas = await html2canvas(card, { scale: 2, useCORS: true });
    const imgData = canvas.toDataURL('image/png');
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pageWidth = pdf.internal.pageSize.getWidth();
    const imgWidth = pageWidth - 20;
    const imgHeight = canvas.height * imgWidth / canvas.width;
    pdf.addImage(imgData, 'PNG', 10, 10, imgWidth, imgHeight);
    pdf.save(reportId + '.pdf');
}

// ===== Bookings Report (Artist) =====
let bkStatusPieChart = null;
let bkMonthlyBarChart = null;
let bkWeekdayBarChart = null;
function loadBookingsReport() {
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) return;
    fetch(`../../Backend/Artist/booking_api.php?artist_id=${artistUser.id}`)
        .then(res => res.json())
        .then(data => {
            if (!data.success || !Array.isArray(data.bookings)) return;
            const b = data.bookings;
            // Stats
            const total = b.length;
            const pending = b.filter(x => (x.status||'').toLowerCase()==='pending').length;
            const confirmed = b.filter(x => (x.status||'').toLowerCase()==='confirmed').length;
            const completed = b.filter(x => (x.status||'').toLowerCase()==='completed').length;
            const cancelled = b.filter(x => ['cancelled','cancelled by customer'].includes((x.status||'').toLowerCase())).length;
            const setText = (id,val)=>{ const el=document.getElementById(id); if(el) el.textContent=String(val); };
            setText('bkTotalBookings', total);
            setText('bkPending', pending);
            setText('bkConfirmed', confirmed);
            setText('bkCompleted', completed);
            setText('bkCancelled', cancelled);

            // Status pie
            const pieEl = document.getElementById('bkStatusPie');
            if (pieEl) {
                const labels = ['Pending','Confirmed','Completed','Cancelled'];
                const dataSet = [pending, confirmed, completed, cancelled];
                if (!bkStatusPieChart) {
                    bkStatusPieChart = new Chart(pieEl.getContext('2d'), { type:'pie', data:{ labels, datasets:[{ data:dataSet, backgroundColor:['#f59e0b','#3b82f6','#10b981','#ef4444'] }] }, options:{ responsive:true, plugins:{ legend:{ position:'bottom' } } } });
                } else {
                    bkStatusPieChart.data.labels = labels;
                    bkStatusPieChart.data.datasets[0].data = dataSet;
                    bkStatusPieChart.update();
                }
            }

            // Monthly bar (last 6 months)
            const months = getLastSixMonths();
            const map = Object.fromEntries(months.map(m=>[m.key,0]));
            b.forEach(x=>{ const d=new Date(x.date); const key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`; if(!isNaN(d) && map[key]!==undefined) map[key]+=1; });
            const mEl = document.getElementById('bkMonthlyBar');
            if (mEl) {
                const labels = months.map(m=>m.label);
                const dataSet = months.map(m=>map[m.key]);
                if (!bkMonthlyBarChart) {
                    bkMonthlyBarChart = new Chart(mEl.getContext('2d'), { type:'bar', data:{ labels, datasets:[{ label:'Bookings', data:dataSet, backgroundColor:'#6366f1' }] }, options:{ responsive:true, scales:{ y:{ beginAtZero:true, ticks:{ precision:0 } } }, plugins:{ legend:{ display:false } } } });
                } else {
                    bkMonthlyBarChart.data.labels = labels;
                    bkMonthlyBarChart.data.datasets[0].data = dataSet;
                    bkMonthlyBarChart.update();
                }
            }

            // Weekday bar
            const wEl = document.getElementById('bkWeekdayBar');
            if (wEl) {
                const labels = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
                const cnt = Array(7).fill(0);
                b.forEach(x=>{ const d=new Date(x.date); if(!isNaN(d)) cnt[d.getDay()] += 1; });
                if (!bkWeekdayBarChart) {
                    bkWeekdayBarChart = new Chart(wEl.getContext('2d'), { type:'bar', data:{ labels, datasets:[{ label:'Bookings', data:cnt, backgroundColor:'#0ea5e9' }] }, options:{ responsive:true, scales:{ y:{ beginAtZero:true, ticks:{ precision:0 } } }, plugins:{ legend:{ display:false } } } });
                } else {
                    bkWeekdayBarChart.data.datasets[0].data = cnt;
                    bkWeekdayBarChart.update();
                }
            }
        });
}

// keep your existing loadBookings() here...

function generateReports() {
    // Read date inputs. If empty, default to current month.
    const startEl = document.getElementById('startDate');
    const endEl = document.getElementById('endDate');
    let startDate, endDate;
    const now = new Date();
    if (!startEl || !endEl) return;
    if (!startEl.value || !endEl.value) {
        // Default to first and last day of current month
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
        // Update inputs to reflect defaults
        startEl.value = startDate.toISOString().slice(0, 10);
        endEl.value = endDate.toISOString().slice(0, 10);
    } else {
        startDate = new Date(startEl.value + 'T00:00:00');
        endDate = new Date(endEl.value + 'T23:59:59');
    }

    if (endDate < startDate) {
        // If invalid, swap them
        const tmp = startDate; startDate = endDate; endDate = tmp;
        startEl.value = startDate.toISOString().slice(0,10);
        endEl.value = endDate.toISOString().slice(0,10);
    }

    // Now load each report with date filters
    loadSalesReport(startDate, endDate);
    loadCustomerReport(startDate, endDate);
    loadPerformanceReport(startDate, endDate);
}

function loadSalesReport(startDate, endDate) {
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) {
        console.log('No artist logged in for sales report');
        return;
    }

    // Fetch bookings and calculate sales report
    fetch(`../../Backend/Artist/booking_api.php?artist_id=${artistUser.id}`)
        .then(res => res.json())
        .then(data => {
            if (data.success && Array.isArray(data.bookings)) {
                let bookings = data.bookings;
                // Filter by date range if provided
                if (startDate && endDate) {
                    bookings = bookings.filter(b => {
                        const d = new Date(b.date);
                        if (isNaN(d)) return false;
                        return d >= startDate && d <= endDate;
                    });
                }
                calculateSalesReport(bookings);
                renderSalesStatusChart(bookings);
                renderSalesTopItemsBar(bookings);
                renderSalesRevenueWeekday(bookings);
                renderSalesRevenueTrend(bookings);
            } else {
                console.log('No bookings found for sales report');
                // Set all values to 0 if no bookings
                document.getElementById("totalRevenue").textContent = "Rs0";
                document.getElementById("totalBookings").textContent = "0";
                document.getElementById("totalCancelled").textContent = "0";
                document.getElementById("averageOrder").textContent = "Rs0";
                document.getElementById("mostOrdered").textContent = "-";
                renderSalesStatusChart([]);
                renderSalesTopItemsBar([]);
                renderSalesRevenueWeekday([]);
                renderSalesRevenueTrend([]);
            }
        })
        .catch(error => {
            console.error('Error loading sales report:', error);
        });
}

// ====== DASHBOARD CHARTS ======
function loadDashboardCharts() {
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) return;

    fetch(`../../Backend/Artist/booking_api.php?artist_id=${artistUser.id}`)
        .then(res => res.json())
        .then(data => {
            if (!data.success || !Array.isArray(data.bookings)) return;
            const all = data.bookings;
            renderChartBookingsMonthly(all);
            renderChartRevenueMonthly(all);
            renderChartTopItems(all);
            renderChartByWeekday(all);
        })
        .catch(() => {});
}

async function loadCustomerBookingStats(customerEmail) {
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) return;

    try {
        const res = await fetch(`../../Backend/Artist/booking_api.php?artist_id=${artistUser.id}`);
        const data = await res.json();

        if (!data.success || !Array.isArray(data.bookings)) return;

        // Filter bookings belonging to this customer
        const customerBookings = data.bookings.filter(b => 
            (b.user_email || '').toLowerCase() === customerEmail.toLowerCase()
        );

        // Initialize counters
        let confirmed = 0, completed = 0, cancelled = 0, cancelledByCustomer = 0, totalSpent = 0;

        customerBookings.forEach(b => {
            const status = (b.status || '').toLowerCase();
            if (status === 'confirmed') confirmed++;
            else if (status === 'completed') completed++;
            else if (status === 'cancelled') cancelled++;
            else if (status === 'cancelled by customer') cancelledByCustomer++;

            // Add to total spent if confirmed or completed
            if (status === 'confirmed' || status === 'completed') {
                const price = parseFloat(b.price?.toString().replace(/[^0-9.]/g, "")) || 0;
                totalSpent += price;
            }
        });

        // Update modal UI
        document.getElementById('modalConfirmed').textContent = confirmed;
        document.getElementById('modalCompleted').textContent = completed;
        document.getElementById('modalCancelled').textContent = cancelled;
        document.getElementById('modalCancelledByCustomer').textContent = cancelledByCustomer;
        document.getElementById('modalTotalSpent').textContent = `Rs${totalSpent.toFixed(2)}`;

    } catch (err) {
        console.error("Error loading customer stats:", err);
    }
}

// ====== DASHBOARD STATS (live) ======
function loadDashboardStats() {
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) return;

    Promise.all([
        fetch(`../../Backend/Artist/booking_api.php?artist_id=${artistUser.id}`).then(r => r.json()),
        fetch(`../../Backend/Artist/review_api.php?route=get_by_artist_id&artist_id=${artistUser.id}`).then(r => r.json()),
        fetch(`../../Backend/Admin/user_api.php`).then(r => r.json())
    ]).then(([bookingData, reviewData, userData]) => {
        // Appointments this month
        let monthAppointments = 0;
        let totalEarnings = 0;
        if (bookingData.success && Array.isArray(bookingData.bookings)) {
            const now = new Date();
            const m = now.getMonth();
            const y = now.getFullYear();
            monthAppointments = bookingData.bookings.filter(b => {
                const d = new Date(b.date);
                return !isNaN(d) && d.getMonth() === m && d.getFullYear() === y;
            }).length;

            // Earnings = sum price for confirmed / completed
            bookingData.bookings.forEach(b => {
                const s = (b.status || '').toLowerCase();
                if (s === 'confirmed' || s === 'completed') {
                    const price = b.price ? parseFloat(b.price.toString().replace(/[^0-9.]/g, '')) || 0 : 0;
                    totalEarnings += price;
                }
            });
        }
        const apptEl = document.getElementById('statAppointmentsThisMonth');
        const earnEl = document.getElementById('statTotalEarnings');
        if (apptEl) apptEl.textContent = String(monthAppointments);
        if (earnEl) earnEl.textContent = `Rs${totalEarnings.toLocaleString()}`;

        // Average rating
        let avgRating = 0;
        if (reviewData.success && Array.isArray(reviewData.reviews) && reviewData.reviews.length) {
            const sum = reviewData.reviews.reduce((s, r) => s + (parseFloat(r.rating) || 0), 0);
            avgRating = sum / reviewData.reviews.length;
        }
        const avgEl = document.getElementById('statAverageRating');
        if (avgEl) avgEl.textContent = avgRating.toFixed(1);

        // Total customers
        let totalCustomers = 0;
        if (userData.success && Array.isArray(userData.users) && bookingData.success && Array.isArray(bookingData.bookings)) {
            const userIds = new Set(bookingData.bookings.map(b => parseInt(b.user_id)));
            totalCustomers = userData.users.filter(u => userIds.has(parseInt(u.id))).length;
        }
        const custEl = document.getElementById('statTotalCustomers');
        if (custEl) custEl.textContent = String(totalCustomers);
    }).catch(() => {});
}

function getLastSixMonths() {
    const months = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        const label = d.toLocaleString('en-US', { month: 'short' });
        months.push({ key, label });
    }
    return months;
}

function groupByMonth(bookingsArr) {
    const months = getLastSixMonths();
    const map = Object.fromEntries(months.map(m => [m.key, 0]));
    bookingsArr.forEach(b => {
        const d = new Date(b.date);
        if (isNaN(d)) return;
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        if (key in map) map[key] += 1;
    });
    return { labels: months.map(m => m.label), data: months.map(m => map[m.key]) };
}

function revenueByMonth(bookingsArr) {
    const months = getLastSixMonths();
    const map = Object.fromEntries(months.map(m => [m.key, 0]));
    bookingsArr.forEach(b => {
        const s = (b.status || '').toLowerCase();
        if (s !== 'confirmed' && s !== 'completed') return;
        const d = new Date(b.date);
        if (isNaN(d)) return;
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        let price = 0;
        if (b.price) {
            price = parseFloat(b.price.toString().replace(/[^0-9.]/g, '')) || 0;
        }
        if (key in map) map[key] += price;
    });
    return { labels: months.map(m => m.label), data: months.map(m => map[m.key]) };
}

function topItemsData(bookingsArr, topN = 7) {
    const counts = {};
    bookingsArr.forEach(b => {
        let name = b.service_type ? b.service_type : (b.offer ? b.offer : 'Unknown');
        if (name && name.includes(' - Rs')) name = name.split(' - Rs')[0];
        counts[name] = (counts[name] || 0) + 1;
    });
    const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, topN);
    return { labels: entries.map(e => e[0]), data: entries.map(e => e[1]) };
}

function weekdayData(bookingsArr) {
    const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const counts = Array(7).fill(0);
    bookingsArr.forEach(b => {
        const d = new Date(b.date);
        if (isNaN(d)) return;
        counts[d.getDay()] += 1;
    });
    return { labels: names, data: counts };
}

function renderChartBookingsMonthly(all) {
    const el = document.getElementById('chartBookingsMonthly');
    if (!el) return;
    const { labels, data } = groupByMonth(all);
    if (chartBookingsMonthly) {
        chartBookingsMonthly.data.labels = labels;
        chartBookingsMonthly.data.datasets[0].data = data;
        chartBookingsMonthly.update();
        return;
    }
    chartBookingsMonthly = new Chart(el.getContext('2d'), {
        type: 'bar',
        data: {
            labels,
            datasets: [{
                label: 'Bookings',
                data,
                backgroundColor: '#3b82f6'
            }]
        },
        options: {
            responsive: true,
            scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
            plugins: { legend: { display: false } }
        }
    });
}

function renderChartRevenueMonthly(all) {
    const el = document.getElementById('chartRevenueMonthly');
    if (!el) return;
    const { labels, data } = revenueByMonth(all);
    if (chartRevenueMonthly) {
        chartRevenueMonthly.data.labels = labels;
        chartRevenueMonthly.data.datasets[0].data = data;
        chartRevenueMonthly.update();
        return;
    }
    chartRevenueMonthly = new Chart(el.getContext('2d'), {
        type: 'line',
        data: {
            labels,
            datasets: [{
                label: 'Revenue (Rs)',
                data,
                borderColor: '#10b981',
                backgroundColor: 'rgba(16,185,129,0.15)',
                fill: true,
                tension: 0.35
            }]
        },
        options: {
            responsive: true,
            scales: { y: { beginAtZero: true } },
            plugins: { legend: { display: false } }
        }
    });
}

function renderChartTopItems(all) {
    const el = document.getElementById('chartTopItems');
    if (!el) return;
    const { labels, data } = topItemsData(all);
    if (chartTopItems) {
        chartTopItems.data.labels = labels;
        chartTopItems.data.datasets[0].data = data;
        chartTopItems.update();
        return;
    }
    chartTopItems = new Chart(el.getContext('2d'), {
        type: 'bar',
        data: {
            labels,
            datasets: [{
                label: 'Orders',
                data,
                backgroundColor: '#a855f7'
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            scales: { x: { beginAtZero: true, ticks: { precision: 0 } } },
            plugins: { legend: { display: false } }
        }
    });
}

function renderChartByWeekday(all) {
    const el = document.getElementById('chartByWeekday');
    if (!el) return;
    const { labels, data } = weekdayData(all);
    if (chartByWeekday) {
        chartByWeekday.data.labels = labels;
        chartByWeekday.data.datasets[0].data = data;
        chartByWeekday.update();
        return;
    }
    chartByWeekday = new Chart(el.getContext('2d'), {
        type: 'bar',
        data: {
            labels,
            datasets: [{
                label: 'Bookings',
                data,
                backgroundColor: '#f59e0b'
            }]
        },
        options: {
            responsive: true,
            scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
            plugins: { legend: { display: false } }
        }
    });
}


// 🔽 Finally, call loadBookings when page loads
window.addEventListener("DOMContentLoaded", () => {
    loadBookings("all");
});


function handleFilterBookings(e) {
    const filter = e.target.dataset.filter;

    // Update active tab
    document.querySelectorAll('.tab-btn').forEach(tab => {
        tab.classList.remove('active');
    });
    e.target.classList.add('active');

    loadBookings(filter);
}

function updateBookingStatus(bookingId, newStatus) {
    // Find the button that triggered this call
    let btnSelector = `button[onclick=\"updateBookingStatus(${bookingId}, '${newStatus}')\"]`;
    let btn = document.querySelector(btnSelector);
    let originalBtnContent = '';
    if (btn) {
        originalBtnContent = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = `<div class=\"loader\" style=\"width:32px;height:32px;min-width:32px;min-height:32px;display:inline-block;vertical-align:middle;\">
            <div class=\"bar1\"></div><div class=\"bar2\"></div><div class=\"bar3\"></div><div class=\"bar4\"></div><div class=\"bar5\"></div><div class=\"bar6\"></div><div class=\"bar7\"></div><div class=\"bar8\"></div><div class=\"bar9\"></div><div class=\"bar10\"></div><div class=\"bar11\"></div><div class=\"bar12\"></div>
        </div>`;
    }
    fetch(`../../Backend/Artist/booking_api.php?route=update_status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `id=${encodeURIComponent(bookingId)}&status=${encodeURIComponent(newStatus)}`
    })
        .then(res => res.json())
        .then(data => {
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = originalBtnContent;
            }
            if (data.success) {
                showNotification('Booking status updated!', 'success');
                loadBookings();
            } else {
                showNotification('Failed to update status', 'error');
            }
        })
        .catch(() => {
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = originalBtnContent;
            }
            showNotification('Error updating booking status', 'error');
        });
}

function contactCustomer(phone) {
    // Show custom modal with avatar, name, phone
    const modal = document.getElementById('contactCustomerModal');
    const body = document.getElementById('contactCustomerBody');
    // Try to get user info from last loaded users (from loadBookings)
    let customerName = '';
    let customerAvatar = '';
    let customerPhone = phone;
    // Use window.lastUsers if available (set in loadBookings)
    if (window.lastUsers && window.lastUsers.length) {
        let user = window.lastUsers.find(u => u.phone == phone);
        if (user) {
            customerName = user.name;
            customerAvatar = user.image_path ? '../../' + user.image_path : 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop';
        }
    }
    // Fallbacks
    if (modal && body) {
        body.innerHTML = `
            <p style='margin:0 0 16px 0;font-size:1rem;color:#555;'><i class='fas fa-phone' style='color:#6c63ff;margin-right:6px;'></i> <a href='tel:${customerPhone}' style='color:#6c63ff;text-decoration:none;font-weight:500;'>${customerPhone}</a></p>
            <button class='btn btn-primary' style='width:100%;margin-top:8px;' onclick="window.location.href='tel:${customerPhone}'"><i class='fas fa-phone-alt'></i> Call Now</button>
        `;
        modal.classList.add('active');
    }
}
function loadCustomers() {
    const customersTable = document.getElementById('customersTable');
    if (!customersTable) return;

    // Get the logged-in artist's ID
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) {
        customersTable.innerHTML = '<tr><td colspan="5">Artist not logged in</td></tr>';
        return;
    }

    // Show loading state
    customersTable.innerHTML = '<tr><td colspan="5">Loading customers...</td></tr>';

    console.log('Artist ID:', artistUser.id); // Debug log

    // Fetch bookings for this artist to get user_ids
    fetch(`../../Backend/Artist/booking_api.php?artist_id=${artistUser.id}`)
        .then(res => {
            console.log('Booking API Response Status:', res.status); // Debug log
            return res.json();
        })
        .then(bookingData => {
            console.log('Booking Data:', bookingData); // Debug log

            if (!bookingData.success || !Array.isArray(bookingData.bookings)) {
                console.log('No bookings found or API error:', bookingData);
                customersTable.innerHTML = '<tr><td colspan="5">No bookings found</td></tr>';
                return;
            }

            console.log('Number of bookings found:', bookingData.bookings.length); // Debug log

            // Extract unique user_ids from bookings (convert to integers)
            const userIds = [...new Set(bookingData.bookings.map(booking => parseInt(booking.user_id)))];
            console.log('Unique user IDs:', userIds); // Debug log

            if (userIds.length === 0) {
                customersTable.innerHTML = '<tr><td colspan="5">No customers found</td></tr>';
                return;
            }

            // Fetch all users
            fetch('../../Backend/Admin/user_api.php')
                .then(res => {
                    console.log('User API Response Status:', res.status); // Debug log
                    return res.json();
                })
                .then(userData => {
                    console.log('User Data:', userData); // Debug log

                    if (!userData.success || !Array.isArray(userData.users)) {
                        customersTable.innerHTML = '<tr><td colspan="5">Error loading user data</td></tr>';
                        return;
                    }

                    console.log('Number of users found:', userData.users.length); // Debug log

                    // Filter users who have bookings with this artist
                    const customers = userData.users
                        .filter(user => {
                            const hasBooking = userIds.includes(parseInt(user.id));
                            console.log(`User ${user.id} (${user.name}) has booking:`, hasBooking); // Debug log
                            return hasBooking;
                        })
                        .map(user => {
                            // Calculate customer statistics from bookings
                            const userBookings = bookingData.bookings.filter(booking =>
                                parseInt(booking.user_id) === parseInt(user.id)
                            );

                            console.log(`User ${user.id} bookings:`, userBookings.length); // Debug log

                            // Calculate total bookings
                            const totalBookings = userBookings.length;

                            // Find last visit (most recent booking date)
                            const lastVisit = userBookings.length > 0
                                ? userBookings.reduce((latest, booking) => {
                                    const bookingDate = new Date(booking.date);
                                    const latestDate = new Date(latest);
                                    return bookingDate > latestDate ? booking.date : latest;
                                }, userBookings[0].date)
                                : null;

                            // Calculate total spent
                            const totalSpent = userBookings.reduce((sum, booking) => {
                                const price = parseFloat(booking.price) || 0;
                                return sum + price;
                            }, 0);

                            // Set avatar image path
                            const avatar = user.image_path
                                ? `../../${user.image_path}`
                                : 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop';

                            return {
                                id: user.id,
                                name: user.name,
                                email: user.email,
                                phone: user.phone,
                                totalBookings: totalBookings,
                                lastVisit: lastVisit,
                                totalSpent: totalSpent,
                                avatar: avatar
                            };
                        });

                    console.log('Final customers array:', customers); // Debug log

                    // Sort customers by total bookings (descending)
                    customers.sort((a, b) => b.totalBookings - a.totalBookings);

                    // Update global customers array for search functionality
                    window.customers = customers;

                    // Render customers table
                    if (customers.length === 0) {
                        customersTable.innerHTML = '<tr><td colspan="5">No customers found for this artist</td></tr>';
                        return;
                    }

                    customersTable.innerHTML = customers.map(customer => `
                        <tr>
                            <td>
                                <div class="customer-info">
                                    <img src="${customer.avatar}" alt="${customer.name}" class="customer-avatar" onerror="this.src='https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'">
                                    <div>
                                        <strong>${customer.name}</strong><br>
                                        <small>${customer.email}</small>
                                    </div>
                                </div>
                            </td>
                            <td>${customer.phone}</td>
                            <td>${customer.totalBookings}</td>
                            <td>${customer.lastVisit ? formatDate(customer.lastVisit) : 'No visits'}</td>
                            <td>
                                <button class="btn btn-sm btn-primary" onclick="viewCustomerDetails(${customer.id})">View</button>
                            </td>
                        </tr>
                    `).join('');
                })
                .catch(error => {
                    console.error('Error fetching users:', error);
                    customersTable.innerHTML = '<tr><td colspan="5">Error loading customers</td></tr>';
                });
        })
        .catch(error => {
            console.error('Error fetching bookings:', error);
            customersTable.innerHTML = '<tr><td colspan="5">Error loading bookings</td></tr>';
        });
}

// ====== CUSTOMER REPORT (charts + stats) ======
function loadCustomerReport(startDate, endDate) {
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) return;
    Promise.all([
        fetch(`../../Backend/Artist/booking_api.php?artist_id=${artistUser.id}`).then(r => r.json()),
        fetch(`../../Backend/Admin/user_api.php`).then(r => r.json())
    ]).then(([bookingData, userData]) => {
        if (!bookingData.success || !Array.isArray(bookingData.bookings)) return;
        const allBookings = bookingData.bookings;
        const users = (userData.success && Array.isArray(userData.users)) ? userData.users : [];

        // Build total booking counts per user (overall)
        const totalCounts = {};
        allBookings.forEach(b => {
            const uid = parseInt(b.user_id);
            if (isNaN(uid)) return;
            totalCounts[uid] = (totalCounts[uid] || 0) + 1;
        });

        // Filter bookings by date range for charts and total customers
        let bookings = allBookings;
        if (startDate && endDate) {
            bookings = allBookings.filter(b => {
                const d = new Date(b.date);
                if (isNaN(d)) return false;
                return d >= startDate && d <= endDate;
            });
        }

        // Unique customers in the filtered set
        const uniqueUserIds = Array.from(new Set(bookings.map(b => parseInt(b.user_id)))).filter(id => !isNaN(id));
        const totalCustomers = uniqueUserIds.length;

        // New customers = those whose total booking count == 1 (first time)
        let newCustomers = 0;
        let returningCustomers = 0;
        uniqueUserIds.forEach(uid => {
            const cnt = totalCounts[uid] || 0;
            if (cnt <= 1) newCustomers++; else returningCustomers++;
        });

        const returningPct = totalCustomers > 0 ? Math.round((returningCustomers / totalCustomers) * 100) : 0;

        const elTotal = document.getElementById('customerReportTotal');
        const elNew = document.getElementById('customerReportNew');
        const elReturning = document.getElementById('customerReportReturning');
        if (elTotal) elTotal.textContent = String(totalCustomers);
        if (elNew) elNew.textContent = String(newCustomers);
        if (elReturning) elReturning.textContent = `${returningPct}%`;

        // Charts
        renderCustomerByMonthChart(bookings);
        renderCustomerNewReturningPie(totalCustomers, newCustomers, returningCustomers);
        renderCustomerTopSpenders(bookings, users);
    }).catch((err) => { console.error('Error loading customer report', err); });
}

function renderCustomerByMonthChart(bookingsArr) {
    const el = document.getElementById('customerByMonth');
    if (!el) return;
    // count unique customers per month
    const months = getLastSixMonths();
    const map = Object.fromEntries(months.map(m => [m.key, new Set()]));
    bookingsArr.forEach(b => {
        const d = new Date(b.date);
        if (isNaN(d)) return;
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        if (map[key]) map[key].add(parseInt(b.user_id));
    });
    const labels = months.map(m => m.label);
    const data = months.map(m => map[m.key].size);
    if (customerByMonthChart) {
        customerByMonthChart.data.labels = labels;
        customerByMonthChart.data.datasets[0].data = data;
        customerByMonthChart.update();
        return;
    }
    customerByMonthChart = new Chart(el.getContext('2d'), {
        type: 'bar',
        data: { labels, datasets: [{ label: 'Unique Customers', data, backgroundColor: '#0ea5e9' }] },
        options: { responsive: true, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }, plugins: { legend: { display: false } } }
    });
}

function renderCustomerNewReturningPie(total, newly, returning) {
    const el = document.getElementById('customerNewReturningPie');
    if (!el) return;
    const labels = ['New', 'Returning'];
    const data = [newly, returning];
    if (customerNewReturningPieChart) {
        customerNewReturningPieChart.data.labels = labels;
        customerNewReturningPieChart.data.datasets[0].data = data;
        customerNewReturningPieChart.update();
        return;
    }
    customerNewReturningPieChart = new Chart(el.getContext('2d'), {
        type: 'pie',
        data: { labels, datasets: [{ data, backgroundColor: ['#22c55e', '#a855f7'] }] },
        options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
    });
}

function renderCustomerTopSpenders(bookingsArr, users) {
    const el = document.getElementById('customerTopSpenders');
    if (!el) return;
    const spend = {};
    bookingsArr.forEach(b => {
        const s = (b.status || '').toLowerCase();
        if (s !== 'confirmed' && s !== 'completed') return;
        const uid = parseInt(b.user_id);
        const price = b.price ? parseFloat(b.price.toString().replace(/[^0-9.]/g, '')) || 0 : 0;
        spend[uid] = (spend[uid] || 0) + price;
    });
    const top = Object.entries(spend).sort((a,b)=>b[1]-a[1]).slice(0,7);
    const labels = top.map(([uid]) => {
        const u = users.find(x => parseInt(x.id) === parseInt(uid));
        return u ? (u.name || `ID ${uid}`) : `ID ${uid}`;
    });
    const data = top.map(([,amt]) => amt);
    if (customerTopSpendersChart) {
        customerTopSpendersChart.data.labels = labels;
        customerTopSpendersChart.data.datasets[0].data = data;
        customerTopSpendersChart.update();
        return;
    }
    customerTopSpendersChart = new Chart(el.getContext('2d'), {
        type: 'bar',
        data: { labels, datasets: [{ label: 'Total Spent (Rs)', data, backgroundColor: '#f59e0b' }] },
        options: { indexAxis: 'y', responsive: true, scales: { x: { beginAtZero: true } }, plugins: { legend: { display: false } } }
    });
}

// ====== PERFORMANCE REPORT ======
function loadPerformanceReport(startDate, endDate) {
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) return;
    Promise.all([
        fetch(`../../Backend/Artist/booking_api.php?artist_id=${artistUser.id}`).then(r => r.json()),
        fetch(`../../Backend/Artist/review_api.php?route=get_by_artist_id&artist_id=${artistUser.id}`).then(r => r.json())
    ]).then(([bookingData, reviewData]) => {
        if (!bookingData.success || !Array.isArray(bookingData.bookings)) return;
        let bookings = bookingData.bookings;
        let reviews = (reviewData.success && Array.isArray(reviewData.reviews)) ? reviewData.reviews : [];

        // Filter bookings/reviews by date range if provided
        if (startDate && endDate) {
            bookings = bookings.filter(b => {
                const d = new Date(b.date);
                if (isNaN(d)) return false;
                return d >= startDate && d <= endDate;
            });
            reviews = reviews.filter(r => {
                const d = new Date(r.created_at || r.date || r.timestamp || null);
                if (!d || isNaN(d)) return false;
                return d >= startDate && d <= endDate;
            });
        }

        // Completion rate = completed / (confirmed + completed)
        const confirmed = bookings.filter(b => (b.status||'').toLowerCase()==='confirmed').length;
        const completed = bookings.filter(b => (b.status||'').toLowerCase()==='completed').length;
        const completionRate = (confirmed + completed) > 0 ? Math.round((completed/(confirmed+completed))*100) : 0;
        const confirmToComplete = confirmed > 0 ? Math.round((completed/confirmed)*100) : (completed>0?100:0);
        const perfCR = document.getElementById('perfCompletionRate');
        const perfCC = document.getElementById('perfConfirmToComplete');
        if (perfCR) perfCR.textContent = `${completionRate}%`;
        if (perfCC) perfCC.textContent = `${confirmToComplete}%`;

        // Average rating
        let avgRating = 0;
        if (reviews.length) {
            const sum = reviews.reduce((s, r) => s + (parseFloat(r.rating) || 0), 0);
            avgRating = sum / reviews.length;
        }
        const perfAvg = document.getElementById('perfAverageRating');
        if (perfAvg) perfAvg.textContent = `${avgRating.toFixed(1)}/5`;

        // Monthly completion trend (last 6 months) - send filtered bookings
        renderPerfCompletionRateMonthly(bookings);
        // Monthly rating trend - send filtered reviews
        renderPerfRatingTrendMonthly(reviews);
    }).catch((err) => { console.error('Error loading performance report', err); });
}

function renderPerfCompletionRateMonthly(bookingsArr) {
    const el = document.getElementById('perfCompletionRateMonthly');
    if (!el) return;
    const months = getLastSixMonths();
    const confirmedMap = Object.fromEntries(months.map(m => [m.key, 0]));
    const completedMap = Object.fromEntries(months.map(m => [m.key, 0]));
    bookingsArr.forEach(b => {
        const d = new Date(b.date);
        if (isNaN(d)) return;
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        const s = (b.status||'').toLowerCase();
        if (s === 'confirmed') confirmedMap[key] += 1;
        else if (s === 'completed') completedMap[key] += 1;
    });
    const labels = months.map(m => m.label);
    const data = months.map(m => {
        const c = confirmedMap[m.key];
        const d = completedMap[m.key];
        return (c + d) > 0 ? Math.round((d/(c+d))*100) : 0;
    });
    if (perfCompletionRateMonthlyChart) {
        perfCompletionRateMonthlyChart.data.labels = labels;
        perfCompletionRateMonthlyChart.data.datasets[0].data = data;
        perfCompletionRateMonthlyChart.update();
        return;
    }
    perfCompletionRateMonthlyChart = new Chart(el.getContext('2d'), {
        type: 'line',
        data: { labels, datasets: [{ label: 'Completion %', data, borderColor: '#22c55e', backgroundColor: 'rgba(34,197,94,0.15)', fill: true, tension: 0.35 }] },
        options: { responsive: true, scales: { y: { beginAtZero: true, max: 100 } }, plugins: { legend: { display: false } } }
    });
}

function renderPerfRatingTrendMonthly(reviewsArr) {
    const el = document.getElementById('perfRatingTrendMonthly');
    if (!el) return;
    const months = getLastSixMonths();
    const sumMap = Object.fromEntries(months.map(m => [m.key, 0]));
    const countMap = Object.fromEntries(months.map(m => [m.key, 0]));
    reviewsArr.forEach(r => {
        const d = new Date(r.created_at || r.date || r.timestamp || Date.now());
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        if (key in sumMap) {
            sumMap[key] += (parseFloat(r.rating) || 0);
            countMap[key] += 1;
        }
    });
    const labels = months.map(m => m.label);
    const data = months.map(m => countMap[m.key] > 0 ? (sumMap[m.key] / countMap[m.key]) : 0);
    if (perfRatingTrendMonthlyChart) {
        perfRatingTrendMonthlyChart.data.labels = labels;
        perfRatingTrendMonthlyChart.data.datasets[0].data = data;
        perfRatingTrendMonthlyChart.update();
        return;
    }
    perfRatingTrendMonthlyChart = new Chart(el.getContext('2d'), {
        type: 'line',
        data: { labels, datasets: [{ label: 'Avg Rating', data, borderColor: '#6366f1', backgroundColor: 'rgba(99,102,241,0.15)', fill: true, tension: 0.35 }] },
        options: { responsive: true, scales: { y: { beginAtZero: true, max: 5 } }, plugins: { legend: { display: false } } }
    });
}

// Updated customer search function to work with dynamic data
function handleCustomerSearch(e) {
    const searchTerm = e.target.value.toLowerCase();
    const customersTable = document.getElementById('customersTable');
    if (!customersTable || !window.customers) return;

    const filteredCustomers = window.customers.filter(customer =>
        customer.name.toLowerCase().includes(searchTerm) ||
        customer.email.toLowerCase().includes(searchTerm) ||
        customer.phone.includes(searchTerm)
    );

    customersTable.innerHTML = filteredCustomers.map(customer => `
        <tr>
            <td>
                <div class="customer-info">
                    <img src="${customer.avatar}" alt="${customer.name}" class="customer-avatar" onerror="this.src='https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'">
                    <div>
                        <strong>${customer.name}</strong><br>
                        <small>${customer.email}</small>
                    </div>
                </div>
            </td>
            <td>${customer.phone}</td>
            <td>${customer.totalBookings}</td>
            <td>${customer.lastVisit ? formatDate(customer.lastVisit) : 'No visits'}</td>
            <td>
                <button class="btn btn-sm btn-primary" onclick="viewCustomerDetails(${customer.id})">View</button>
            </td>
        </tr>
    `).join('');
}

function viewCustomerDetails(customerId) {
    const customer = window.customers ? window.customers.find(c => c.id == customerId) : null;
    if (!customer) {
        showNotification('Customer details not found', 'error');
        return;
    }

    // Fetch bookings by email
    fetch(`../../Backend/Artist/booking_api.php?route=get_by_email&email=${encodeURIComponent(customer.email)}`)
        .then(res => res.json())
        .then(data => {
            if (!data.success || !Array.isArray(data.bookings)) {
                showNotification('No bookings found for this customer', 'info');
                return;
            }

            let totalConfirmed = 0, totalCompleted = 0, totalCancelled = 0, totalCancelledByCustomer = 0;
            let totalSpent = 0;

            data.bookings.forEach(b => {
                const status = (b.status || '').toLowerCase();
                if (status === 'confirmed') {
                    totalConfirmed++;
                    totalSpent += b.price ? parseFloat(b.price) : 0;
                } else if (status === 'completed') {
                    totalCompleted++;
                    totalSpent += b.price ? parseFloat(b.price) : 0;
                } else if (status === 'cancelled') {
                    totalCancelled++;
                } else if (status === 'cancelled by customer') {
                    totalCancelledByCustomer++;
                }
            });

            const modal = document.getElementById('viewCustomerModal');
            const body = document.getElementById('viewCustomerBody');
            if (modal && body) {
                body.innerHTML = `
                    <img src='${customer.avatar || "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg"}' alt='Avatar'>
                    <h4>${customer.name}</h4>
                    <p><i class='fas fa-envelope'></i> ${customer.email}</p>
                    <p><i class='fas fa-phone'></i> ${customer.phone}</p>
                    <div class='customer-meta'>
                        <p><strong>Total Confirmed:</strong> ${totalConfirmed}</p>
                        <p><strong>Total Completed:</strong> ${totalCompleted}</p>
                        <p><strong>Total Cancelled:</strong> ${totalCancelled}</p>
                        <p><strong>Total Cancelled by Customer:</strong> ${totalCancelledByCustomer}</p>
                        <p><strong>Total Spent:</strong> Rs${totalSpent.toFixed(2)}</p>
                        <p><strong>Last Visit:</strong> ${customer.lastVisit ? formatDate(customer.lastVisit) : 'No visits'}</p>
                    </div>
                `;
                modal.classList.add('active');
            }
        })
        .catch(() => {
            showNotification('Error fetching bookings for customer', 'error');
        });
}


// Reviews Functions
function loadReviews() {
    const reviewsList = document.getElementById('reviewsList');
    if (!reviewsList) return;
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) {
        reviewsList.innerHTML = '<div class="empty-state">No reviews found.</div>';
        return;
    }
    fetch(`../../Backend/Artist/review_api.php?route=get_by_artist_id&artist_id=${artistUser.id}`)
        .then(res => res.json())
        .then(data => {
            if (data.success && Array.isArray(data.reviews)) {
                if (data.reviews.length === 0) {
                    reviewsList.innerHTML = '<div class="empty-state">No reviews found.</div>';
                    return;
                }
                reviewsList.innerHTML = data.reviews.map(review => {
                    // Use backend fields: id, customerName, rating, review, created_at, avatar
                    return `
                        <div class="review-card">
                            <div class="review-header">
                                <img src="${review.avatar && review.avatar !== '' ? review.avatar : 'https://via.placeholder.com/100'}" alt="${review.customerName || ''}" class="reviewer-avatar">
                                <div class="reviewer-info">
                                    <h5>${review.customerName || ''}</h5>
                                    <div class="stars">
                                        ${generateStars(review.rating)}
                                    </div>
                                    <div class="review-date">${formatDate(review.created_at)}</div>
                                </div>
                            </div>
                            <p class="review-text">${review.review}</p>
                        </div>
                    `;
                }).join('');
            } else {
                reviewsList.innerHTML = '<div class="empty-state">No reviews found.</div>';
            }
        })
        .catch(() => {
            reviewsList.innerHTML = '<div class="empty-state">Error loading reviews.</div>';
        });
}

function generateStars(rating) {
    let stars = '';
    for (let i = 1; i <= 5; i++) {
        if (i <= rating) {
            stars += '<i class="fas fa-star"></i>';
        } else {
            stars += '<i class="far fa-star"></i>';
        }
    }
    return stars;
}

// Profile Functions
function handleProfileUpdate(e) {
    e.preventDefault();
    const artistUser = JSON.parse(localStorage.getItem('artistUser'));
    if (!artistUser || !artistUser.id) return;
    const formData = new FormData();
    formData.append('id', artistUser.id);
    formData.append('name', document.getElementById('fullName').value);
    formData.append('phone', document.getElementById('phone').value);
    formData.append('location', document.getElementById('location').value);
    formData.append('experience', parseInt(document.getElementById('experience').value));
    formData.append('bio', document.getElementById('bio').value);
    formData.append('specialty', document.getElementById('specialties').value);
    formData.append('email', artistUser.email || '');
    // Add profile image if selected
    const profileImageInput = document.getElementById('profileImage');
    if (profileImageInput && profileImageInput.files.length > 0) {
        formData.append('profile_image', profileImageInput.files[0]);
        console.log('Profile image selected:', profileImageInput.files[0].name);
    } else {
        console.log('No profile image selected');
    }
    // Log all form data being sent
    for (let pair of formData.entries()) {
        console.log('FormData:', pair[0], pair[1]);
    }
    fetch('../../Backend/Admin/artist_api.php', {
        method: 'POST',
        body: formData
    })
        .then(res => {
            console.log('Backend response status:', res.status);
            return res.json();
        })
        .then(data => {
            console.log('Backend response data:', data);
            if (data.success) {
                showNotification('Profile updated successfully!', 'success');
                autoFillProfile();
                // Optionally show image preview
                if (data.profile_image) {
                    const preview = document.getElementById('profileImagePreview');
                    preview.innerHTML = `<img src='../../${data.profile_image}' style='max-width:120px;border-radius:8px;'>`;
                }
            } else {
                let errorMsg = 'Failed to update profile.';
                if (data.upload_error || data.image_status) {
                    errorMsg += `\nImage status: ${data.image_status || 'unknown'}\nUpload error: ${data.upload_error || 'none'}`;
                }
                showNotification(errorMsg, 'error');
                console.error('Profile update error:', data);
            }
        })
        .catch((err) => {
            console.log('Fetch error:', err);
            showNotification('Failed to update profile.', 'error');
        });
}

// Report Functions
// Report Functions
// Note: duplicate/simple alerting generateReports removed. The main `generateReports()`
// implementation earlier in the file handles date defaults and dispatches to each report loader.

// Modal Functions
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('active');
}

// Utility Functions
function formatDate(dateString) {
    const date = new Date(dateString);
    const options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    };
    return date.toLocaleDateString('en-US', options);
}

// / Show specific report subsection
function showReportSection(reportType) {
    // Ensure the reports section is active
    const reportsSection = document.getElementById('reports');
    if (reportsSection) {
        // Hide all main sections first
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });
        // Show reports section
        reportsSection.classList.add('active');
    }

    // Hide all report cards
    document.querySelectorAll('.report-card').forEach(card => {
        card.style.display = 'none';
    });

    // Show the selected report card
    const targetReport = document.getElementById(reportType + '-report');
    if (targetReport) {
        targetReport.style.display = 'block';
    } else {
        console.error(`Report not found: ${reportType}`);
    }

    // Update page title
    const pageTitle = document.getElementById('pageTitle');
    if (pageTitle) {
        const reportTitles = {
            'sales': 'Sales Report',
            'customer': 'Customer Report',
            'inventory': 'Inventory Report',
            'performance': 'Performance Report'
        };
        pageTitle.textContent = reportTitles[reportType] || 'Reports';
    }

    // Load data for specific report
    if (reportType === 'sales') {
        loadSalesReport();
    } else if (reportType === 'customer') {
        loadCustomerReport();
    } else if (reportType === 'performance') {
        loadPerformanceReport();
    } else if (reportType === 'bookings') {
        loadBookingsReport();
    }
}

// Toggle reports submenu

// Toggle reports submenu
function toggleReports(event) {
    event.preventDefault();
    const submenu = document.getElementById('reports-submenu');
    if (submenu) {
        submenu.style.display = submenu.style.display === 'flex' ? 'none' : 'flex';
    }
}

function previousMonth() {
    // Calendar navigation functionality would go here
    console.log('Previous month clicked');
}

function nextMonth() {
    // Calendar navigation functionality would go here
    console.log('Next month clicked');
}

// Close modals when clicking outside
document.addEventListener('click', function (e) {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
    }
});

// Notification handling
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;

    // Style the notification
    Object.assign(notification.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '1rem 1.5rem',
        borderRadius: '8px',
        color: 'white',
        background: type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6',
        zIndex: '9999',
        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
        transform: 'translateX(100%)',
        transition: 'transform 0.3s ease'
    });

    document.body.appendChild(notification);

    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);

    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}


// reports navigation links

// Toggle reports submenu
// function toggleReports(event) {
//     event.preventDefault();
//     const submenu = document.getElementById("reports-submenu");
//     submenu.style.display = submenu.style.display === "flex" ? "none" : "flex";
// }

// Handle submenu click safely
// Updated handleNavigation function
function handleNavigation(event) {
    event.preventDefault();

    const element = event.currentTarget;
    const sectionName = element.dataset.section;

    if (!sectionName) {
        console.error("No section data found");
        return;
    }

    // Check if this is a report subsection
    const reportSections = ['sales', 'customer', 'inventory', 'performance'];

    if (reportSections.includes(sectionName)) {
        // Handle report subsection - navigate to reports section first
        showSection('reports');
        // Then show the specific report
        showReportSection(sectionName);
    } else {
        // Handle main section
        showSection(sectionName);
    }

    // Update active nav item
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    element.classList.add('active');
}

// Show the selected report
// function showSection(sectionId) {
//     if (!sectionId || typeof sectionId !== "string") {
//         console.error("Invalid sectionId passed to showSection:", sectionId);
//         return;
//     }

//     // Hide all reports
//     document.querySelectorAll(".report-card").forEach(card => card.classList.remove("active"));

//     // Show the selected report
//     const section = document.getElementById(sectionId + "-report");
//     if (section) section.classList.add("active");
//     else console.error("Report not found:", sectionId);
// }

// // Show Sales report by default on page load
// window.onload = () => {
//     showSection("sales");
// };

