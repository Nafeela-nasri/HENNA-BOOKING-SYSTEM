// Admin Panel JavaScript - Clean Version
class AdminPanel {
    deleteNotification(id) {
        if (!id) return;
        if (!confirm('Are you sure you want to delete this notification?')) return;
        fetch('../../Backend/Admin/notification_api.php?id=' + encodeURIComponent(id), {
            method: 'DELETE'
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showSuccess('Notification deleted successfully.');
                    // Refresh notifications
                    this.fetchNotifications();
                } else {
                    alert('Failed to delete notification: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(() => {
                alert('Failed to delete notification.');
            });
    }
    // ===== Report Overview Summary Methods =====
    renderSalesReportSummary(bookings) {
        const el = document.getElementById('salesReportSummary');
        if (!el || !bookings || !Array.isArray(bookings)) return;
        let totalRevenue = 0, totalOrders = bookings.length, topService = '', serviceCount = {}, totalValue = 0;
        bookings.forEach(b => {
            totalRevenue += Number(b.price || 0);
            totalValue += Number(b.price || 0);
            if (b.service_type) {
                serviceCount[b.service_type] = (serviceCount[b.service_type] || 0) + 1;
            } else if (b.offer) {
                serviceCount[b.offer] = (serviceCount[b.offer] || 0) + 1;
            }
        });
        let avgOrderValue = totalOrders ? (totalValue / totalOrders) : 0;
        topService = Object.entries(serviceCount).sort((a, b) => b[1] - a[1])[0]?.[0] || '-';
        el.innerHTML = `
            <div class="quick-stats">
                <div class="quick-stat"><span class="label">Total Revenue</span><span class="value">Rs ${totalRevenue.toLocaleString()}</span></div>
                <div class="quick-stat"><span class="label">Total Orders</span><span class="value">${totalOrders}</span></div>
                <div class="quick-stat"><span class="label">Avg Order Value</span><span class="value">Rs ${avgOrderValue.toFixed(2)}</span></div>
                <div class="quick-stat"><span class="label">Top Service/Offer</span><span class="value">${topService}</span></div>
            </div>
        `;
    }

    renderCustomerReportSummary(bookings, users) {
        const el = document.getElementById('customerReportSummary');
        if (!el || !bookings || !users) return;
        let totalCustomers = users.length;
        let newCustomers = 0, returningCustomers = 0, topSpender = '', spendMap = {};
        let userBookings = {};
        bookings.forEach(b => {
            userBookings[b.user_id] = (userBookings[b.user_id] || 0) + 1;
            spendMap[b.user_id] = (spendMap[b.user_id] || 0) + Number(b.price || 0);
        });
        users.forEach(u => {
            if (userBookings[u.id] === 1) newCustomers++;
            else if (userBookings[u.id] > 1) returningCustomers++;
        });
        let topSpenderId = Object.entries(spendMap).sort((a, b) => b[1] - a[1])[0]?.[0];
        let topSpenderName = users.find(u => u.id == topSpenderId)?.name || '-';
        el.innerHTML = `
            <div class="quick-stats">
                <div class="quick-stat"><span class="label">Total Customers</span><span class="value">${totalCustomers}</span></div>
                <div class="quick-stat"><span class="label">New Customers</span><span class="value">${newCustomers}</span></div>
                <div class="quick-stat"><span class="label">Returning Customers</span><span class="value">${returningCustomers}</span></div>
                <div class="quick-stat"><span class="label">Top Spender</span><span class="value">${topSpenderName}</span></div>
            </div>
        `;
    }

    renderBookingReportSummary(bookings) {
        const el = document.getElementById('bookingReportSummary');
        if (!el || !bookings) return;
        let totalBookings = bookings.length, totalValue = 0, weekdayCount = Array(7).fill(0);
        bookings.forEach(b => {
            totalValue += Number(b.price || 0);
            let date = new Date(b.date);
            let wd = date.getDay();
            weekdayCount[wd]++;
        });
        let avgValue = totalBookings ? (totalValue / totalBookings) : 0;
        let mostPopularDayIdx = weekdayCount.indexOf(Math.max(...weekdayCount));
        let days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        let mostPopularDay = days[mostPopularDayIdx] || '-';
        el.innerHTML = `
            <div class="quick-stats">
                <div class="quick-stat"><span class="label">Total Bookings</span><span class="value">${totalBookings}</span></div>
                <div class="quick-stat"><span class="label">Avg Value</span><span class="value">Rs ${avgValue.toFixed(2)}</span></div>
                <div class="quick-stat"><span class="label">Most Popular Day</span><span class="value">${mostPopularDay}</span></div>
            </div>
        `;
    }

    renderPerformanceReportSummary(bookings, artists, reviews) {
        const el = document.getElementById('performanceReportSummary');
        if (!el || !bookings || !artists || !reviews) return;
        let revenueByArtist = {}, completedByArtist = {}, ratingSum = {}, ratingCount = {};
        bookings.forEach(b => {
            revenueByArtist[b.artist_id] = (revenueByArtist[b.artist_id] || 0) + Number(b.price || 0);
            if (b.status === 'completed') completedByArtist[b.artist_id] = (completedByArtist[b.artist_id] || 0) + 1;
        });
        reviews.forEach(r => {
            ratingSum[r.artist_id] = (ratingSum[r.artist_id] || 0) + Number(r.rating || 0);
            ratingCount[r.artist_id] = (ratingCount[r.artist_id] || 0) + 1;
        });
        let topArtistId = Object.entries(revenueByArtist).sort((a, b) => b[1] - a[1])[0]?.[0];
        let topArtistName = artists.find(a => a.id == topArtistId)?.name || '-';
        let totalCompleted = Object.values(completedByArtist).reduce((a, b) => a + b, 0);
        let totalBookings = bookings.length;
        let avgCompletionRate = totalBookings ? (totalCompleted / totalBookings * 100) : 0;
        let allRatings = Object.values(ratingSum).reduce((a, b) => a + b, 0);
        let allRatingCount = Object.values(ratingCount).reduce((a, b) => a + b, 0);
        let avgRating = allRatingCount ? (allRatings / allRatingCount) : 0;
        el.innerHTML = `
            <div class="quick-stats">
                <div class="quick-stat"><span class="label">Top Artist</span><span class="value">${topArtistName}</span></div>
                <div class="quick-stat"><span class="label">Avg Completion Rate</span><span class="value">${avgCompletionRate.toFixed(1)}%</span></div>
                <div class="quick-stat"><span class="label">Avg Rating</span><span class="value">${avgRating.toFixed(2)}</span></div>
            </div>
        `;
    }
    // ===== Dashboard dynamic stats and charts =====
    loadDashboardStatsAndCharts() {
        Promise.all([
            fetch('../../Backend/Admin/user_api.php').then(r => r.json()),
            fetch('../../Backend/Admin/artist_api.php').then(r => r.json()),
            fetch('../../Backend/Artist/booking_api.php').then(r => r.json()),
            fetch('../../Backend/Artist/review_api.php').then(r => r.json())
        ]).then(([userData, artistData, bookingData, reviewData]) => {
            const users = (userData.success && Array.isArray(userData.users)) ? userData.users : [];
            const artists = (artistData.success && Array.isArray(artistData.artists)) ? artistData.artists : [];
            const bookings = (bookingData.success && Array.isArray(bookingData.bookings)) ? bookingData.bookings : [];
            const reviews = (reviewData.success && Array.isArray(reviewData.reviews)) ? reviewData.reviews : [];

            // Top stats
            const totalUsers = users.length;
            const activeArtists = artists.filter(a => String(a.status || '').toLowerCase() !== 'inactive').length;
            const totalBookings = bookings.length;
            let revenue = 0;
            bookings.forEach(b => {
                const s = (b.status || '').toLowerCase();
                if (s === 'confirmed' || s === 'completed') {
                    revenue += (parseFloat(String(b.price).replace(/[^0-9.]/g, '')) || 0);
                }
            });
            const newUsersToday = users.filter(u => u.created_at && new Date(u.created_at).toDateString() === new Date().toDateString()).length;
            const pendingBookings = bookings.filter(b => (b.status || '').toLowerCase() === 'pending').length;
            const avgRating = reviews.length ? (reviews.reduce((s, r) => s + (parseFloat(r.rating) || 0), 0) / reviews.length) : 0;

            const setText = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
            setText('adminStatTotalUsers', String(totalUsers));
            setText('adminStatActiveArtists', String(activeArtists));
            setText('adminStatTotalBookings', String(totalBookings));
            setText('adminStatRevenue', 'Rs' + revenue.toLocaleString());
            setText('adminStatNewUsersToday', String(newUsersToday));
            setText('adminStatPendingBookings', String(pendingBookings));
            setText('adminStatAvgRating', avgRating.toFixed(1));

            // Charts
            this.renderAdminUserGrowthChart(users);
            this.renderAdminRevenueMonthlyChart(bookings);
            this.renderAdminBookingsMonthlyChart(bookings);
            this.renderAdminArtistPerformanceChart(bookings, artists, reviews);

            // Dashboard overview charts
            this.renderDashBookStatus(bookings);
            this.renderDashRevenueWeekday(bookings);
            this.renderDashTopArtistsRevenue(bookings, artists);
            this.renderDashTopItems(bookings);
        }).catch(() => { });
    }

    renderAdminUserGrowthChart(users) {
        const el = document.getElementById('adminUserGrowthChart');
        if (!el) return;
        // If users not supplied, fetch them from backend (fallback) so old behavior still works
        if (!users || !Array.isArray(users)) {
            // fetch and re-call this method with the data
            fetch('../../Backend/Admin/user_api.php')
                .then(r => r.json())
                .then(data => {
                    const fetched = (data && data.success && Array.isArray(data.users)) ? data.users : [];
                    this.renderAdminUserGrowthChart(fetched);
                })
                .catch(err => {
                    console.error('Failed to fetch users for user growth chart', err);
                });
            return;
        }
        const last6 = this.getLastSixMonths();
        const counts = Object.fromEntries(last6.map(m => [m.key, 0]));
        users.forEach(u => {
            const d = new Date(u.created_at || u.createdAt || u.joined_at || Date.now());
            const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
            if (counts[key] !== undefined) counts[key] += 1;
        });
        const labels = last6.map(m => m.label);
        const data = last6.map(m => counts[m.key]);
        if (!this._userChart) {
            this._userChart = new Chart(el.getContext('2d'), {
                type: 'bar',
                data: { labels, datasets: [{ label: 'New Users', data, backgroundColor: '#3b82f6' }] },
                options: { responsive: true, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }, plugins: { legend: { display: false } } }
            });
        } else {
            this._userChart.data.labels = labels;
            this._userChart.data.datasets[0].data = data;
            this._userChart.update();
        }
    }

    renderAdminRevenueMonthlyChart(bookings) {
        const el = document.getElementById('adminRevenueMonthlyChart');
        if (!el) return;
        const last6 = this.getLastSixMonths();
        const sums = Object.fromEntries(last6.map(m => [m.key, 0]));
        bookings.forEach(b => {
            const s = (b.status || '').toLowerCase();
            if (s !== 'confirmed' && s !== 'completed') return;
            const d = new Date(b.date);
            const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
            const price = b.price ? parseFloat(String(b.price).replace(/[^0-9.]/g, '')) || 0 : 0;
            if (!isNaN(d) && sums[key] !== undefined) sums[key] += price;
        });
        const labels = last6.map(m => m.label);
        const data = last6.map(m => sums[m.key]);
        if (!this._revChart) {
            this._revChart = new Chart(el.getContext('2d'), {
                type: 'line',
                data: { labels, datasets: [{ label: 'Revenue (Rs)', data, borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.15)', fill: true, tension: 0.35 }] },
                options: { responsive: true, scales: { y: { beginAtZero: true } }, plugins: { legend: { display: false } } }
            });
        } else {
            this._revChart.data.labels = labels;
            this._revChart.data.datasets[0].data = data;
            this._revChart.update();
        }
    }

    renderAdminBookingsMonthlyChart(bookings) {
        const el = document.getElementById('adminBookingsMonthlyChart');
        if (!el) return;
        const last6 = this.getLastSixMonths();
        const counts = Object.fromEntries(last6.map(m => [m.key, 0]));
        bookings.forEach(b => {
            const d = new Date(b.date);
            const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
            if (!isNaN(d) && counts[key] !== undefined) counts[key] += 1;
        });
        const labels = last6.map(m => m.label);
        const data = last6.map(m => counts[m.key]);
        if (!this._bookChart) {
            this._bookChart = new Chart(el.getContext('2d'), {
                type: 'bar',
                data: { labels, datasets: [{ label: 'Bookings', data, backgroundColor: '#a855f7' }] },
                options: { responsive: true, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }, plugins: { legend: { display: false } } }
            });
        } else {
            this._bookChart.data.labels = labels;
            this._bookChart.data.datasets[0].data = data;
            this._bookChart.update();
        }
    }

    renderAdminArtistPerformanceChart(bookings, artists, reviews) {
        const el = document.getElementById('adminArtistPerformanceChart');
        if (!el) return;
        // Compute top artists by revenue and completion
        const revenueByArtist = {};
        const completedByArtist = {};
        const confirmedByArtist = {};
        bookings.forEach(b => {
            const aid = b.artist_id;
            const s = (b.status || '').toLowerCase();
            if (!revenueByArtist[aid]) revenueByArtist[aid] = 0;
            if (!completedByArtist[aid]) completedByArtist[aid] = 0;
            if (!confirmedByArtist[aid]) confirmedByArtist[aid] = 0;
            if (s === 'confirmed' || s === 'completed') {
                revenueByArtist[aid] += (parseFloat(String(b.price).replace(/[^0-9.]/g, '')) || 0);
            }
            if (s === 'completed') completedByArtist[aid] += 1;
            if (s === 'confirmed') confirmedByArtist[aid] += 1;
        });
        // Average rating by artist from reviews
        const ratingSum = {}, ratingCount = {};
        reviews.forEach(r => {
            const aid = r.artist_id;
            ratingSum[aid] = (ratingSum[aid] || 0) + (parseFloat(r.rating) || 0);
            ratingCount[aid] = (ratingCount[aid] || 0) + 1;
        });
        const perf = Object.keys(revenueByArtist).map(aid => {
            const name = (artists.find(a => a.id == aid)?.name) || `Artist #${aid}`;
            const rev = revenueByArtist[aid] || 0;
            const comp = completedByArtist[aid] || 0;
            const conf = confirmedByArtist[aid] || 0;
            const compRate = (conf + comp) > 0 ? Math.round((comp / (conf + comp)) * 100) : 0;
            const avgR = (ratingCount[aid] > 0) ? (ratingSum[aid] / ratingCount[aid]) : 0;
            return { name, rev, compRate, avgR };
        }).sort((a, b) => b.rev - a.rev).slice(0, 7);
        const labels = perf.map(p => p.name);
        const revenueData = perf.map(p => p.rev);
        const compRateData = perf.map(p => p.compRate);
        const avgRatingData = perf.map(p => p.avgR);
        if (!this._artistPerfChart) {
            this._artistPerfChart = new Chart(el.getContext('2d'), {
                type: 'bar',
                data: {
                    labels,
                    datasets: [
                        { label: 'Revenue (Rs)', data: revenueData, backgroundColor: '#f59e0b', yAxisID: 'y' },
                        { label: 'Completion %', data: compRateData, type: 'line', borderColor: '#22c55e', backgroundColor: 'rgba(34,197,94,0.15)', yAxisID: 'y1', tension: 0.35 },
                        { label: 'Avg Rating', data: avgRatingData, type: 'line', borderColor: '#3b82f6', backgroundColor: 'rgba(59,130,246,0.15)', yAxisID: 'y2', tension: 0.35 }
                    ]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: { beginAtZero: true, position: 'left' },
                        y1: { beginAtZero: true, position: 'right', suggestedMax: 100, grid: { drawOnChartArea: false } },
                        y2: { beginAtZero: true, position: 'right', suggestedMax: 5, grid: { drawOnChartArea: false } }
                    }
                }
            });
        } else {
            this._artistPerfChart.data.labels = labels;
            this._artistPerfChart.data.datasets[0].data = revenueData;
            this._artistPerfChart.data.datasets[1].data = compRateData;
            this._artistPerfChart.data.datasets[2].data = avgRatingData;
            this._artistPerfChart.update();
        }
    }

    getLastSixMonths() {
        const months = [];
        const now = new Date();
        for (let i = 5; i >= 0; i--) {
            const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
            const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
            const label = d.toLocaleString('en-US', { month: 'short' });
            months.push({ key, label });
        }
        return months;
    }

    // ===== Dashboard overview charts =====
    renderDashBookStatus(bookings) {
        const el = document.getElementById('dashBookStatus'); if (!el) return;
        const sMap = { pending: 0, confirmed: 0, completed: 0, cancelled: 0, cancelledByCustomer: 0 };
        bookings.forEach(b => { const s = (b.status || '').toLowerCase(); if (s === 'pending') sMap.pending++; else if (s === 'confirmed') sMap.confirmed++; else if (s === 'completed') sMap.completed++; else if (s === 'cancelled') sMap.cancelled++; else if (s === 'cancelled by customer') sMap.cancelledByCustomer++; });
        const labels = ['Pending', 'Confirmed', 'Completed', 'Cancelled', 'Cancelled by Customer'];
        const data = [sMap.pending, sMap.confirmed, sMap.completed, sMap.cancelled, sMap.cancelledByCustomer];
        if (!this._dashBookStatus) {
            this._dashBookStatus = new Chart(el.getContext('2d'), { type: 'pie', data: { labels, datasets: [{ data, backgroundColor: ['#f59e0b', '#3b82f6', '#10b981', '#ef4444', '#a855f7'] }] }, options: { responsive: true, plugins: { legend: { position: 'bottom' } } } });
        } else { this._dashBookStatus.data.labels = labels; this._dashBookStatus.data.datasets[0].data = data; this._dashBookStatus.update(); }
    }
    renderDashRevenueWeekday(bookings) {
        const el = document.getElementById('dashRevenueWeekday'); if (!el) return;
        const labels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']; const sums = Array(7).fill(0);
        bookings.forEach(b => { const s = (b.status || '').toLowerCase(); if (s !== 'confirmed' && s !== 'completed') return; const d = new Date(b.date); if (isNaN(d)) return; sums[d.getDay()] += (parseFloat(String(b.price).replace(/[^0-9.]/g, '')) || 0); });
        if (!this._dashRevWeek) { this._dashRevWeek = new Chart(el.getContext('2d'), { type: 'bar', data: { labels, datasets: [{ label: 'Revenue (Rs)', data: sums, backgroundColor: '#22c55e' }] }, options: { responsive: true, scales: { y: { beginAtZero: true } }, plugins: { legend: { display: false } } } }); } else { this._dashRevWeek.data.datasets[0].data = sums; this._dashRevWeek.update(); }
    }
    renderDashTopArtistsRevenue(bookings, artists) {
        const el = document.getElementById('dashTopArtistsRevenue'); if (!el) return;
        const revBy = {}; bookings.forEach(b => { const s = (b.status || '').toLowerCase(); if (s !== 'confirmed' && s !== 'completed') return; const aid = b.artist_id; revBy[aid] = (revBy[aid] || 0) + (parseFloat(String(b.price).replace(/[^0-9.]/g, '')) || 0); });
        const top = Object.entries(revBy).sort((a, b) => b[1] - a[1]).slice(0, 7);
        const labels = top.map(([aid]) => { const a = artists.find(x => x.id == aid); return a ? (a.name || `Artist #${aid}`) : `Artist #${aid}`; });
        const data = top.map(([, v]) => v);
        if (!this._dashTopArtists) { this._dashTopArtists = new Chart(el.getContext('2d'), { type: 'bar', data: { labels, datasets: [{ label: 'Revenue (Rs)', data, backgroundColor: '#f59e0b' }] }, options: { indexAxis: 'y', responsive: true, scales: { x: { beginAtZero: true } }, plugins: { legend: { display: false } } } }); } else { this._dashTopArtists.data.labels = labels; this._dashTopArtists.data.datasets[0].data = data; this._dashTopArtists.update(); }
    }
    renderDashTopItems(bookings) {
        const el = document.getElementById('dashTopItems'); if (!el) return;
        const counts = {}; bookings.forEach(b => { let n = b.service_type ? b.service_type : (b.offer || 'Unknown'); if (n.includes(' - Rs')) n = n.split(' - Rs')[0]; counts[n] = (counts[n] || 0) + 1; });
        const top = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 8);
        const labels = top.map(t => t[0]); const data = top.map(t => t[1]);
        if (!this._dashTopItems) { this._dashTopItems = new Chart(el.getContext('2d'), { type: 'bar', data: { labels, datasets: [{ label: 'Orders', data, backgroundColor: '#6366f1' }] }, options: { indexAxis: 'y', responsive: true, scales: { x: { beginAtZero: true, ticks: { precision: 0 } } }, plugins: { legend: { display: false } } } }); } else { this._dashTopItems.data.labels = labels; this._dashTopItems.data.datasets[0].data = data; this._dashTopItems.update(); }
    }
    fetchNotifications() {
        // Fetch all notifications from backend
        fetch('../../Backend/Admin/notification_api.php')
            .then(res => res.json())
            .then(data => {
                if (data.success && Array.isArray(data.notifications)) {
                    this.notifications = data.notifications;
                    this.populateNotifications();
                } else {
                    this.notifications = [];
                    this.populateNotifications();
                }
            })
            .catch(() => {
                this.notifications = [];
                this.populateNotifications();
            });
    }
    // Fetch all bookings, users, and artists from backend
    loadBookings() {
        const bookingsTable = document.getElementById('bookingsTable');
        if (!bookingsTable) return;
        let tbody = bookingsTable.querySelector('tbody');
        if (!tbody) return;
        tbody.innerHTML = '<tr><td colspan="8">Loading...</td></tr>';
        Promise.all([
            fetch('../../Backend/Artist/booking_api.php').then(res => res.json()),
            fetch('../../Backend/Admin/user_api.php').then(res => res.json()),
            fetch('../../Backend/Admin/artist_api.php').then(res => res.json())
        ]).then(([bookingsData, usersData, artistsData]) => {
            if (bookingsData.success && Array.isArray(bookingsData.bookings)) {
                this.bookings = bookingsData.bookings;
                this.usersMap = {};
                this.artistsMap = {};
                if (usersData.success && Array.isArray(usersData.users)) {
                    usersData.users.forEach(u => { this.usersMap[u.id] = u.name; });
                }
                if (artistsData.success && Array.isArray(artistsData.artists)) {
                    artistsData.artists.forEach(a => { this.artistsMap[a.id] = a.name; });
                }
                this.populateBookingsTable();
            } else {
                tbody.innerHTML = '<tr><td colspan="8">No bookings found</td></tr>';
            }
        }).catch(() => {
            tbody.innerHTML = '<tr><td colspan="8">Error loading bookings</td></tr>';
        });
    }
    constructor() {
        this.currentPage = 'dashboard';
        this.isLoggedIn = false;
        this.users = [];
        this.artists = [];
        this.bookings = [];
        this.coupons = [];
        this.supportTickets = [];
        this.notifications = [];
        this.editingUserId = undefined;
        this.editingArtistId = undefined;

        this.init();
        this.loadDummyData();
        this.fetchNotifications(); // Call fetchNotifications in the constructor
        // Check localStorage for login state
        if (localStorage.getItem('adminLoggedIn') === 'true') {
            this.isLoggedIn = true;
            const loginModal = document.getElementById('loginModal');
            const adminPanel = document.getElementById('adminPanel');
            if (loginModal) loginModal.classList.remove('active');
            if (adminPanel) adminPanel.classList.add('active');
            this.showPage('dashboard');
            // Load dynamic dashboard data
            this.loadDashboardStatsAndCharts();
            // Start realtime polling for live updates
            this.startRealtimePolling();
        }
    }

    init() {
        // Log selected date when clicking or changing 'Valid From' and 'Valid Until'
        const offerValidFromInput = document.getElementById('offerValidFrom');
        if (offerValidFromInput) {
            offerValidFromInput.addEventListener('change', function () {
                console.log('Offer Valid From date selected:', offerValidFromInput.value);
            });
        }
        const offerValidUntilInput = document.getElementById('offerValidUntil');
        if (offerValidUntilInput) {
            offerValidUntilInput.addEventListener('change', function () {
                console.log('Offer Valid Until date selected:', offerValidUntilInput.value);
            });
        }
        // Offer form submission: POST to backend
        const offerForm = document.getElementById('offerForm');
        if (offerForm) {
            offerForm.addEventListener('submit', function (e) {
                e.preventDefault();
                // Collect form data
                const name = document.getElementById('offerName').value;
                const description = document.getElementById('offerDescription').value;
                const artist_id = parseInt(document.getElementById('offerArtist').value);
                const serviceCheckboxes = document.querySelectorAll('#servicesSelection input[type="checkbox"]:checked');
                const service_ids = Array.from(serviceCheckboxes).map(cb => parseInt(cb.value));
                const original_price = parseFloat(document.getElementById('originalPrice').value) || 0;
                const discount_percentage = parseFloat(document.getElementById('discountPercentage').value) || 0;
                const offer_price = parseFloat(document.getElementById('offerPrice').value) || 0;
                const discount_amount = parseFloat(document.getElementById('discountAmount').value) || 0;
                const offerValidFromInput = document.getElementById('offerValidFrom');
                const offerValidUntilInput = document.getElementById('offerValidUntil');
                let valid_from = offerValidFromInput ? offerValidFromInput.value : '';
                let valid_until = offerValidUntilInput ? offerValidUntilInput.value : '';
                // Log both for debugging
                console.log('Selected valid_from:', valid_from);
                console.log('Selected valid_until:', valid_until);
                // Prevent submission if either is empty
                if (!valid_from) {
                    alert('Please select a Valid From date.');
                    return;
                }
                if (!valid_until) {
                    alert('Please select a Valid Until date.');
                    return;
                }
                const status = document.getElementById('offerStatus').value;
                // Build payload
                const payload = {
                    name,
                    description,
                    artist_id,
                    service_ids,
                    original_price,
                    discount_percentage,
                    offer_price,
                    discount_amount,
                    valid_from,
                    valid_until,
                    status
                };
                console.log('Offer payload:', payload);
                fetch('../../Backend/Admin/offers_api.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            alert('Offer package created successfully!');
                            offerForm.reset();
                            document.getElementById('servicesSelection').innerHTML = '';
                            closeModal('offerModal');
                        } else {
                            alert('Error creating offer: ' + (data.error || 'Unknown error'));
                        }
                    })
                    .catch(() => {
                        alert('Error connecting to server.');
                    });
            });
        }
        // --- Offer Modal Discount Calculation ---
        function updateOfferDiscountCalculation() {
            const servicesDiv = document.getElementById('servicesSelection');
            const checked = servicesDiv ? Array.from(servicesDiv.querySelectorAll('input[type="checkbox"]:checked')) : [];
            let originalPrice = 0;
            checked.forEach(cb => {
                originalPrice += parseFloat(cb.getAttribute('data-price')) || 0;
            });
            const originalPriceInput = document.getElementById('originalPrice');
            if (originalPriceInput) originalPriceInput.value = originalPrice;
            const discountPercentageInput = document.getElementById('discountPercentage');
            const offerPriceInput = document.getElementById('offerPrice');
            const discountAmountInput = document.getElementById('discountAmount');
            let discountPercent = discountPercentageInput ? parseFloat(discountPercentageInput.value) : 0;
            if (isNaN(discountPercent) || discountPercent < 0) discountPercent = 0;
            let discountAmount = (discountPercent / 100) * originalPrice;
            let offerPrice = originalPrice - discountAmount;
            if (offerPriceInput) offerPriceInput.value = offerPrice > 0 ? offerPrice.toFixed(2) : 0;
            if (discountAmountInput) discountAmountInput.value = discountAmount > 0 ? discountAmount.toFixed(2) : 0;
        }
        // Listen for discount % changes
        const discountPercentageInput = document.getElementById('discountPercentage');
        if (discountPercentageInput) {
            discountPercentageInput.addEventListener('input', updateOfferDiscountCalculation);
        }
        // Listen for service selection changes
        const servicesDiv = document.getElementById('servicesSelection');
        if (servicesDiv) {
            servicesDiv.addEventListener('change', updateOfferDiscountCalculation);
        }
        // Event listeners
        const loginForm = document.getElementById('loginForm');
        const logoutBtn = document.getElementById('logoutBtn');
        const menuToggle = document.getElementById('menuToggle');

        if (loginForm) loginForm.addEventListener('submit', this.handleLogin.bind(this));
        if (logoutBtn) logoutBtn.addEventListener('click', this.handleLogout.bind(this));
        if (menuToggle) menuToggle.addEventListener('click', this.toggleSidebar.bind(this));

        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = e.target.closest('.nav-link').dataset.page;
                this.showPage(page);
                // Toggle submenu if reports link
                const li = e.target.closest('li');
                if (page === 'reports' && li && li.classList.contains('has-submenu')) {
                    li.classList.toggle('open');
                }
            });
        });
        // Submenu navigation for reports
        document.querySelectorAll('.nav-sublink').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = e.target.closest('.nav-sublink').dataset.page;
                this.showPage(page);
                this.loadReportPage(page);
            });
        });

        // Form submissions
        const userForm = document.getElementById('userForm');
        const artistForm = document.getElementById('artistForm');
        const couponForm = document.getElementById('couponForm');
        const notificationForm = document.getElementById('notificationForm');

        if (userForm) {
            userForm.addEventListener('submit', (e) => {
                if (this.editingUserId) {
                    this.handleEditUser(e);
                } else {
                    this.handleAddUser(e);
                }
            });
        }
        // Dynamic service selection for offer modal
        const offerArtistDropdown = document.getElementById('offerArtist');
        if (offerArtistDropdown) {
            offerArtistDropdown.addEventListener('change', function () {
                const artistId = this.value;
                const servicesDiv = document.getElementById('servicesSelection');
                if (artistId) {
                    fetch(`../../Backend/Artist/service_api.php?artist_id=${artistId}`)
                        .then(res => res.json())
                        .then(data => {
                            servicesDiv.innerHTML = '';
                            if (data.success && Array.isArray(data.services)) {
                                data.services.forEach((service, idx) => {
                                    const serviceId = `service${idx + 1}`;
                                    const item = document.createElement('div');
                                    item.className = 'service-item';
                                    item.innerHTML = `
                                            <input type="checkbox" id="${serviceId}" value="${service.id}" data-price="${service.price}">
                                            <label for="${serviceId}">${service.name} - Rs${service.price}</label>
                                        `;
                                    servicesDiv.appendChild(item);
                                });
                                // Add event listeners for auto-calculation
                                updateOfferPriceCalculation();
                                servicesDiv.querySelectorAll('input[type="checkbox"]').forEach(cb => {
                                    cb.addEventListener('change', updateOfferPriceCalculation);
                                });
                            } else {
                                servicesDiv.innerHTML = '<p>No services found for this artist.</p>';
                                updateOfferPriceCalculation();
                            }
                        })
                        .catch(() => {
                            servicesDiv.innerHTML = '<p>Error loading services.</p>';
                            updateOfferPriceCalculation();
                        });
                } else {
                    servicesDiv.innerHTML = '';
                    updateOfferPriceCalculation();
                }
            });
        }
        // Auto-calculation for offer modal
        function updateOfferPriceCalculation() {
            const servicesDiv = document.getElementById('servicesSelection');
            const checked = servicesDiv ? Array.from(servicesDiv.querySelectorAll('input[type="checkbox"]:checked')) : [];
            let total = 0;
            checked.forEach(cb => {
                total += parseFloat(cb.getAttribute('data-price')) || 0;
            });
            const originalPriceInput = document.getElementById('originalPrice');
            if (originalPriceInput) originalPriceInput.value = total;
            // Discount calculations
            const offerPriceInput = document.getElementById('offerPrice');
            const discountAmountInput = document.getElementById('discountAmount');
            const discountPercentageInput = document.getElementById('discountPercentage');
            let offerPrice = offerPriceInput ? parseFloat(offerPriceInput.value) : 0;
            let discountAmount = total - offerPrice;
            let discountPercent = total > 0 ? ((discountAmount / total) * 100) : 0;
            if (discountAmountInput) discountAmountInput.value = discountAmount > 0 ? discountAmount : 0;
            if (discountPercentageInput) discountPercentageInput.value = discountPercent > 0 ? discountPercent.toFixed(2) : 0;
        }
        // Listen for offer price changes
        const offerPriceInput = document.getElementById('offerPrice');
        if (offerPriceInput) {
            offerPriceInput.addEventListener('input', updateOfferPriceCalculation);
        }
        // Remove duplicate artistForm event listener to prevent double submit
        if (couponForm) couponForm.addEventListener('submit', this.handleCreateCoupon.bind(this));
        if (notificationForm) notificationForm.addEventListener('submit', this.handleSendNotification.bind(this));

        // Tab functionality
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchTab(e.target.dataset.tab);
            });
        });

        // Filter functionality
        const filters = ['bookingStatus', 'contentStatus', 'supportStatus'];
        filters.forEach(filterId => {
            const element = document.getElementById(filterId);
            if (element) {
                element.addEventListener('change', () => this.applyFilters());
            }
        });

        // Set current date for reports
        this.setDefaultDates();
        // Listen for report date range changes and apply filter
        const startDateEl = document.getElementById('startDate');
        const endDateEl = document.getElementById('endDate');
        if (startDateEl && endDateEl) {
            const handler = () => this.applyReportDateFilter();
            startDateEl.addEventListener('change', handler);
            endDateEl.addEventListener('change', handler);
            // initial apply so reports area is populated according to defaults
            handler();
        }
    }

    handleLogin(e) {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        // Dummy authentication
        if (username === 'admin' && password === 'password') {
            this.isLoggedIn = true;
            localStorage.setItem('adminLoggedIn', 'true');
            const loginModal = document.getElementById('loginModal');
            const adminPanel = document.getElementById('adminPanel');

            if (loginModal) loginModal.classList.remove('active');
            if (adminPanel) adminPanel.classList.add('active');

            this.showPage('dashboard');
            // Start realtime polling when admin logs in
            this.startRealtimePolling();
        } else {
            alert('Invalid credentials! Use admin/password');
        }
    }

    handleLogout() {
        this.isLoggedIn = false;
        const adminPanel = document.getElementById('adminPanel');
        const loginModal = document.getElementById('loginModal');
        localStorage.removeItem('adminLoggedIn');
        if (adminPanel) adminPanel.classList.remove('active');
        if (loginModal) loginModal.classList.add('active');
        // Stop realtime polling when admin logs out
        this.stopRealtimePolling();
    }

    // Start a lightweight realtime polling loop (1s) to refresh data silently
    startRealtimePolling() {
        if (this._realtimeIntervalId) return; // already running
        // Do an immediate tick and then every 1s
        this.realtimePollTick();
        this._realtimeIntervalId = setInterval(() => this.realtimePollTick(), 1000);
    }

    stopRealtimePolling() {
        if (this._realtimeIntervalId) {
            clearInterval(this._realtimeIntervalId);
            this._realtimeIntervalId = null;
        }
    }

    // The polling tick fetches multiple endpoints in parallel, updates internal state,
    // and refreshes only the currently visible page. If a modal is open or an edit
    // session is active, skip DOM updates to avoid clobbering user input.
    realtimePollTick() {
        // Prevent overlapping ticks
        if (this._realtimeInProgress) return;
        this._realtimeInProgress = true;

        const modalOpen = !!document.querySelector('.modal.active');
        if (modalOpen || this.editingUserId || this.editingArtistId) {
            // Refresh internal caches quietly but skip DOM updates
            Promise.all([
                fetch('../../Backend/Admin/user_api.php').then(r => r.json()).catch(() => null),
                fetch('../../Backend/Admin/artist_api.php').then(r => r.json()).catch(() => null),
                fetch('../../Backend/Artist/booking_api.php').then(r => r.json()).catch(() => null),
                fetch('../../Backend/Admin/offers_api.php').then(r => r.json()).catch(() => null),
                fetch('../../Backend/Admin/notification_api.php').then(r => r.json()).catch(() => null),
                fetch('../../Backend/Artist/review_api.php').then(r => r.json()).catch(() => null)
            ]).finally(() => { this._realtimeInProgress = false; });
            return;
        }

        // Determine which endpoints are highest priority based on current page
        const page = String(this.currentPage || '');
        const priorityFetches = [];
        const backgroundFetches = [];

        function safeFetch(url) { return fetch(url).then(r => r.json()).catch(() => null); }

        if (page === 'dashboard') {
            priorityFetches.push(safeFetch('../../Backend/Admin/user_api.php'));
            priorityFetches.push(safeFetch('../../Backend/Admin/artist_api.php'));
            priorityFetches.push(safeFetch('../../Backend/Artist/booking_api.php'));
            priorityFetches.push(safeFetch('../../Backend/Artist/review_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/offers_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/notification_api.php'));
        } else if (page === 'users') {
            priorityFetches.push(safeFetch('../../Backend/Admin/user_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/artist_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Artist/booking_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/offers_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/notification_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Artist/review_api.php'));
        } else if (page === 'artists') {
            priorityFetches.push(safeFetch('../../Backend/Admin/artist_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/user_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Artist/booking_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/offers_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/notification_api.php'));
        } else if (page === 'bookings') {
            priorityFetches.push(safeFetch('../../Backend/Artist/booking_api.php'));
            priorityFetches.push(safeFetch('../../Backend/Admin/user_api.php'));
            priorityFetches.push(safeFetch('../../Backend/Admin/artist_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/offers_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/notification_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Artist/review_api.php'));
        } else if (page === 'offers') {
            priorityFetches.push(safeFetch('../../Backend/Admin/offers_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/user_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/artist_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Artist/booking_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/notification_api.php'));
        } else if (page === 'notifications') {
            priorityFetches.push(safeFetch('../../Backend/Admin/notification_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/user_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/artist_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Artist/booking_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/offers_api.php'));
        } else if (page.startsWith('report-')) {
            // Reports generally need bookings + users + artists + reviews
            priorityFetches.push(safeFetch('../../Backend/Artist/booking_api.php'));
            priorityFetches.push(safeFetch('../../Backend/Admin/user_api.php'));
            priorityFetches.push(safeFetch('../../Backend/Admin/artist_api.php'));
            priorityFetches.push(safeFetch('../../Backend/Artist/review_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/offers_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/notification_api.php'));
        } else {
            // Default: fetch notifications + bookings as low priority
            backgroundFetches.push(safeFetch('../../Backend/Admin/notification_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Artist/booking_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/user_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/artist_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Admin/offers_api.php'));
            backgroundFetches.push(safeFetch('../../Backend/Artist/review_api.php'));
        }

        // Run priority fetches first and update DOM quickly
        Promise.all(priorityFetches).then((results) => {
            try {
                // Map results onto internal state safely
                results.forEach(res => {
                    if (!res) return;
                    if (res.users) this.users = Array.isArray(res.users) ? res.users : this.users;
                    if (res.artists) this.artists = Array.isArray(res.artists) ? res.artists : this.artists;
                    if (res.bookings) this.bookings = Array.isArray(res.bookings) ? res.bookings : this.bookings;
                    if (res.offers) this._offers = Array.isArray(res.offers) ? res.offers : this._offers;
                    if (res.notifications) this.notifications = Array.isArray(res.notifications) ? res.notifications : this.notifications;
                    if (res.reviews) this._reviews = Array.isArray(res.reviews) ? res.reviews : this._reviews;
                });

                // Rebuild lookup maps
                this.usersMap = {};
                this.artistsMap = {};
                (this.users || []).forEach(u => { this.usersMap[u.id] = u.name; });
                (this.artists || []).forEach(a => { this.artistsMap[a.id] = a.name; });

                // Update visible page immediately
                switch (page) {
                    case 'dashboard':
                        this.loadDashboardStatsAndCharts();
                        break;
                    case 'users':
                        this.populateUsersTable();
                        break;
                    case 'artists':
                        this.populateArtistsTable();
                        break;
                    case 'bookings':
                        this.populateBookingsTable();
                        break;
                    case 'offers':
                        this.fetchAndDisplayOffers();
                        break;
                    case 'notifications':
                        this.populateNotifications();
                        break;
                    default:
                        if (page.startsWith('report-')) this.loadReportPage(page);
                        break;
                }
            } finally {
                // allow background fetches to proceed, but don't block UI
                setTimeout(() => {
                    Promise.all(backgroundFetches).then(bgResults => {
                        try {
                            bgResults.forEach(res => {
                                if (!res) return;
                                if (res.users) this.users = Array.isArray(res.users) ? res.users : this.users;
                                if (res.artists) this.artists = Array.isArray(res.artists) ? res.artists : this.artists;
                                if (res.bookings) this.bookings = Array.isArray(res.bookings) ? res.bookings : this.bookings;
                                if (res.offers) this._offers = Array.isArray(res.offers) ? res.offers : this._offers;
                                if (res.notifications) this.notifications = Array.isArray(res.notifications) ? res.notifications : this.notifications;
                                if (res.reviews) this._reviews = Array.isArray(res.reviews) ? res.reviews : this._reviews;
                            });
                            // Rebuild lookup maps after background update
                            this.usersMap = {};
                            this.artistsMap = {};
                            (this.users || []).forEach(u => { this.usersMap[u.id] = u.name; });
                            (this.artists || []).forEach(a => { this.artistsMap[a.id] = a.name; });
                        } catch (e) {
                            // ignore
                        }
                    }).finally(() => { this._realtimeInProgress = false; });
                }, 150); // small delay to allow priority render to finish
            }
        }).catch(() => { this._realtimeInProgress = false; });
    }

    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        if (sidebar) sidebar.classList.toggle('active');
    }

    showPage(page) {
        // Hide all pages
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));

        // Show selected page
        const pageElement = document.getElementById(page);
        const navLink = document.querySelector(`[data-page="${page}"]`);

        if (pageElement) pageElement.classList.add('active');
        if (navLink) navLink.classList.add('active');

        this.currentPage = page;

        // Load page-specific data
        this.loadPageData(page);
        if (page === 'dashboard') {
            this.loadDashboardStatsAndCharts();
        }
        // Populate offer artist dropdown when offers page is shown
        if (page === 'offers') {
            this.populateOfferArtistDropdown();
        }
        if (page.startsWith('report-')) {
            this.loadReportPage(page);
        }
    }
    // Populate artist dropdown in offer modal
    populateOfferArtistDropdown() {
        const dropdown = document.getElementById('offerArtist');
        if (!dropdown) return;
        // Clear existing options
        dropdown.innerHTML = '<option value="">Select Artist</option>';
        // Fetch artists from backend
        fetch('../../Backend/Admin/artist_api.php')
            .then(res => res.json())
            .then(data => {
                if (data.success && Array.isArray(data.artists)) {
                    data.artists.forEach(artist => {
                        const option = document.createElement('option');
                        option.value = artist.id;
                        option.textContent = artist.name + (artist.specialty ? ' (' + artist.specialty + ')' : '');
                        dropdown.appendChild(option);
                    });
                }
            })
            .catch(err => {
                // Optionally show error
            });
    }

    loadPageData(page) {
        switch (page) {
            case 'users':
                this.populateUsersTable();
                break;
            case 'artists':
                this.populateArtistsTable();
                break;
            case 'bookings':
                this.loadBookings();
                break;
            case 'coupons':
                this.populateCouponsTable();
                break;
            case 'support':
                this.populateSupportTable();
                break;
            case 'content':
                this.populateContentGrid();
                break;
            case 'notifications':
                this.populateNotifications();
                break;
            case 'offers':
                this.fetchAndDisplayOffers();
                break;
        }
    }

    // ...existing code...
    // Fetch all offers and display in table
    fetchAndDisplayOffers() {
        const offersTable = document.getElementById('offersTable');
        if (!offersTable) return;
        // Clear table body
        let tbody = offersTable.querySelector('tbody');
        if (!tbody) {
            tbody = document.createElement('tbody');
            offersTable.appendChild(tbody);
        }
        tbody.innerHTML = '<tr><td colspan="8">Loading...</td></tr>';
        fetch('../../Backend/Admin/offers_api.php')
            .then(res => res.json())
            .then(data => {
                if (data.success && Array.isArray(data.offers)) {
                    if (data.offers.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="8">No offers found.</td></tr>';
                        return;
                    }
                    tbody.innerHTML = '';
                    data.offers.forEach(offer => {
                        const tr = document.createElement('tr');
                        tr.innerHTML = `
                            <td>${offer.name}</td>
                            <td>${offer.service_ids}</td>
                            <td>${offer.original_price}</td>
                            <td>${offer.offer_price}</td>
                            <td>${offer.discount_percentage}</td>
                            <td>${offer.valid_from}</td>
                            <td>${offer.valid_until}</td>
                            <td>${offer.status}</td>
                        `;
                        tbody.appendChild(tr);
                    });
                } else {
                    tbody.innerHTML = '<tr><td colspan="8">Error loading offers.</td></tr>';
                }
            })
            .catch(() => {
                tbody.innerHTML = '<tr><td colspan="8">Error connecting to server.</td></tr>';
            });
    }

    loadDummyData() {
        // Load dummy users
        this.users = [];

        // Load dummy artists
        this.artists = [];

        // Load dummy bookings
        this.bookings = [
            { id: 'B001', customer: 'John Doe', artist: 'Emma Thompson', eventType: 'Wedding', date: '2024-12-25', amount: 500, status: 'confirmed' },
            { id: 'B002', customer: 'Jane Smith', artist: 'David Miller', eventType: 'Birthday Party', date: '2024-12-20', amount: 350, status: 'pending' },
            { id: 'B003', customer: 'Mike Johnson', artist: 'Lisa Garcia', eventType: 'Corporate Event', date: '2024-12-30', amount: 750, status: 'completed' },
            { id: 'B004', customer: 'Sarah Wilson', artist: 'Tom Brown', eventType: 'Anniversary', date: '2024-12-28', amount: 400, status: 'cancelled' },
        ];

        // Load dummy coupons
        this.coupons = [];

        // Load dummy support tickets
        this.supportTickets = [];

        // No longer needed: notifications are fetched from backend
    }

    populateUsersTable() {
        const tbody = document.querySelector('#usersTable tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        this.users.forEach(user => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${user.id}</td>
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td>${user.role}</td>
                <td><span class="status-badge status-${user.status}">${user.status}</span></td>
                <td class="action-buttons">
                    <button class="btn btn-small btn-secondary" onclick="adminPanel.editUser(${user.id})">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn btn-small btn-error" onclick="adminPanel.deleteUser(${user.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    populateArtistsTable() {
        const tbody = document.querySelector('#artistsTable tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        this.artists.forEach(artist => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${artist.id}</td>
                <td>${artist.name}</td>
                <td><span class="status-badge">${artist.specialty}</span></td>
                <td>${artist.experience} years</td>
                <td class="action-buttons">
                    <button class="btn btn-small btn-primary" onclick="adminPanel.editArtist(${artist.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-small btn-error" onclick="adminPanel.deleteArtist(${artist.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    populateBookingsTable() {
        const tbody = document.querySelector('#bookingsTable tbody');
        if (!tbody) return;
        tbody.innerHTML = '';
        if (!this.bookings.length) {
            tbody.innerHTML = '<tr><td colspan="8">No bookings found</td></tr>';
            return;
        }
        this.bookings.forEach(booking => {
            const customerName = this.usersMap && this.usersMap[booking.user_id] ? this.usersMap[booking.user_id] : `User #${booking.user_id}`;
            const artistName = this.artistsMap && this.artistsMap[booking.artist_id] ? this.artistsMap[booking.artist_id] : `Artist #${booking.artist_id}`;
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${booking.id}</td>
                <td>${customerName}</td>
                <td>${artistName}</td>
                <td>${booking.select_type}</td>
                <td>${booking.date}</td>
                <td>Rs${parseFloat(booking.price).toFixed(2)}</td>
                <td><span class="status-badge status-${booking.status}">${booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}</span></td>
                <td class="action-buttons">
                    <button class="btn btn-small btn-primary" onclick="adminPanel.viewBookingDetails('${booking.id}')"><i class="fas fa-eye"></i></button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    populateCouponsTable() {
        const tbody = document.querySelector('#couponsTable tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        this.coupons.forEach(coupon => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><strong>${coupon.code}</strong></td>
                <td>${coupon.type === 'percentage' ? coupon.discount + '%' : '$' + coupon.discount}</td>
                <td><span class="status-badge">${coupon.type}</span></td>
                <td>${coupon.validUntil}</td>
                <td>${coupon.usageLimit}</td>
                <td>${coupon.used}</td>
                <td><span class="status-badge status-${coupon.status}">${coupon.status}</span></td>
                <td class="action-buttons">
                    <button class="btn btn-small btn-primary" onclick="adminPanel.editCoupon('${coupon.code}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-small btn-error" onclick="adminPanel.deleteCoupon('${coupon.code}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    populateSupportTable() {
        const tbody = document.querySelector('#supportTable tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        this.supportTickets.forEach(ticket => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${ticket.id}</td>
                <td>${ticket.customer}</td>
                <td>${ticket.subject}</td>
                <td><span class="status-badge status-${ticket.priority}">${ticket.priority}</span></td>
                <td><span class="status-badge status-${ticket.status}">${ticket.status}</span></td>
                <td>${ticket.created}</td>
                <td class="action-buttons">
                    <button class="btn btn-small btn-primary" onclick="adminPanel.viewTicket('${ticket.id}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-small btn-success" onclick="adminPanel.resolveTicket('${ticket.id}')">
                        <i class="fas fa-check"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    populateContentGrid() {
        const grid = document.querySelector('.content-grid');
        if (!grid) return;

        grid.innerHTML = '';

        // Dummy content for review
        const content = [
            { id: 1, type: 'image', title: 'Wedding Portfolio', artist: 'Emma Thompson', status: 'pending' },
            { id: 2, type: 'video', title: 'Makeup Tutorial', artist: 'David Miller', status: 'approved' },
            { id: 3, type: 'image', title: 'Hair Styling Gallery', artist: 'Lisa Garcia', status: 'rejected' },
            { id: 4, type: 'portfolio', title: 'Music Samples', artist: 'Tom Brown', status: 'pending' },
        ];

        content.forEach(item => {
            const card = document.createElement('div');
            card.className = 'dashboard-card';
            card.innerHTML = `
                <h4>${item.title}</h4>
                <p>By: ${item.artist}</p>
                <p>Type: <span class="status-badge">${item.type}</span></p>
                <p>Status: <span class="status-badge status-${item.status}">${item.status}</span></p>
                <div class="action-buttons mt-3">
                    <button class="btn btn-small btn-primary" onclick="adminPanel.reviewContent(${item.id})">
                        <i class="fas fa-eye"></i> Review
                    </button>
                    <button class="btn btn-small btn-success" onclick="adminPanel.approveContent(${item.id})">
                        <i class="fas fa-check"></i> Approve
                    </button>
                    <button class="btn btn-small btn-error" onclick="adminPanel.rejectContent(${item.id})">
                        <i class="fas fa-times"></i> Reject
                    </button>
                </div>
            `;
            grid.appendChild(card);
        });
    }

    populateNotifications() {
        const container = document.getElementById('notificationContent');
        if (!container) return;
        container.innerHTML = '';
        if (!this.notifications.length) {
            container.innerHTML = '<div style="padding:2rem;text-align:center;color:#888;">No notifications found.</div>';
            return;
        }
        this.notifications.forEach(notification => {
            const item = document.createElement('div');
            item.className = 'activity-item mb-3';
            item.innerHTML = `
                <i class="fas fa-bell"></i>
                <div style="flex: 1;">
                    <strong>${notification.title}</strong>
                    <p>${notification.message}</p>
                    <small>Audience: ${notification.target_audience} | Status: ${notification.status} | Sent: ${notification.created_at ? notification.created_at.split(' ')[0] : ''}</small>
                </div>
                <div class="action-buttons">

                </div>
            `;
            container.appendChild(item);
        });
    }

    handleAddUser(e) {
        e.preventDefault();
        const name = document.getElementById('userName').value;
        const email = document.getElementById('userEmail').value;
        const role = document.getElementById('userRole').value;
        const phone = document.getElementById('userPhone').value;
        const passwordInput = document.getElementById('userPassword');
        const password = passwordInput ? passwordInput.value : '';
        fetch('../../Backend/Admin/user_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, role, phone, password })
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showSuccess('User added successfully!');
                    this.closeModal('userModal');
                    this.loadUsers();
                    this.resetUserForm();
                } else {
                    alert('Error: ' + (data.error || 'Failed to add user'));
                }
            });
    }
    handleEditUser(e) {
        e.preventDefault();
        const id = this.editingUserId;
        const name = document.getElementById('userName').value;
        const email = document.getElementById('userEmail').value;
        const role = document.getElementById('userRole').value;
        const phone = document.getElementById('userPhone').value;
        const passwordInput = document.getElementById('userPassword');
        let body = { id, name, email, role, phone };
        if (passwordInput && passwordInput.value) {
            body.password = passwordInput.value;
        }
        fetch('../../Backend/Admin/user_api.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showSuccess('User updated successfully!');
                    this.closeModal('userModal');
                    this.loadUsers();
                    this.editingUserId = undefined;
                    this.resetUserForm();
                } else {
                    alert('Error: ' + (data.error || 'Failed to update user'));
                }
            });
    }
    loadUsers() {
        fetch('../../Backend/Admin/user_api.php')
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.users = data.users;
                    this.populateUsersTable();
                }
            });
    }

    handleAddArtist(e) {
        e.preventDefault();
        const artistForm = document.getElementById('artistForm');
        const name = document.getElementById('artistName').value;
        const email = document.getElementById('artistEmail').value;
        const password = document.getElementById('artistPassword').value;
        const specialty = document.getElementById('artistSpecialty').value;
        const experience = parseInt(document.getElementById('artistExperience').value) || 0;
        const phone = document.getElementById('artistPhone').value;
        const location = document.getElementById('artistLocation').value;
        const bio = document.getElementById('artistBio').value;
        fetch('../../Backend/Admin/artist_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password, specialty, experience, phone, location, bio })
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showSuccess('Artist added successfully!');
                    this.closeModal('artistModal');
                    if (artistForm) artistForm.reset();
                    this.editingArtistId = undefined;
                    this.loadArtists();
                } else {
                    alert('Error: ' + (data.error || 'Failed to add artist'));
                }
            });
    }
    handleEditArtist(e) {
        e.preventDefault();
        const artistForm = document.getElementById('artistForm');
        const id = this.editingArtistId;
        const name = document.getElementById('artistName').value;
        const email = document.getElementById('artistEmail').value;
        const specialty = document.getElementById('artistSpecialty').value;
        const experience = parseInt(document.getElementById('artistExperience').value) || 0;
        const phone = document.getElementById('artistPhone').value;
        const location = document.getElementById('artistLocation').value;
        const bio = document.getElementById('artistBio').value;
        fetch('../../Backend/Admin/artist_api.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, name, email, specialty, experience, phone, location, bio })
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showSuccess('Artist updated successfully!');
                    this.closeModal('artistModal');
                    if (artistForm) artistForm.reset();
                    this.editingArtistId = undefined;
                    this.loadArtists();
                } else {
                    alert('Error: ' + (data.error || 'Failed to update artist'));
                }
            });
    }
    loadArtists() {
        fetch('../../Backend/Admin/artist_api.php')
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.artists = data.artists;
                    this.populateArtistsTable();
                }
            });
    }

    handleCreateCoupon(e) {
        e.preventDefault();
        const couponData = {
            code: document.getElementById('couponCode').value,
            discount: parseFloat(document.getElementById('discountValue').value),
            type: document.getElementById('discountType').value,
            validUntil: document.getElementById('validUntil').value,
            usageLimit: parseInt(document.getElementById('usageLimit').value),
            minimumAmount: parseFloat(document.getElementById('minimumAmount')?.value) || 0,
            description: document.getElementById('couponDescription')?.value || '',
            used: 0,
            status: 'active'
        };

        this.coupons.push(couponData);
        this.populateCouponsTable();
        this.closeModal('couponModal');
        e.target.reset();
        this.showSuccess('Coupon created successfully!');
    }

    handleSendNotification(e) {
        e.preventDefault();
        const target_audience = document.getElementById('notificationTarget').value;
        const title = document.getElementById('notificationTitle').value;
        const message = document.getElementById('notificationMessage').value;
        let user_id = '';
        let artist_id = '';
        // Handle specific-customer and specific-artist selection
        if (target_audience === 'specific-customer') {
            const checked = document.querySelectorAll('#specificSelectionBox input[name="customers[]"]:checked');
            user_id = Array.from(checked).map(cb => cb.value).join(',');
        } else if (target_audience === 'specific-artist') {
            const checked = document.querySelectorAll('#specificSelectionBox input[name="artists[]"]:checked');
            artist_id = Array.from(checked).map(cb => cb.value).join(',');
        }
        const payload = { target_audience, user_id, artist_id, title, message };
        fetch('../../Backend/Admin/notification_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.fetchNotifications();
                    this.closeModal('notificationModal');
                    e.target.reset();
                    this.showSuccess('Notification sent successfully!');
                } else {
                    alert('Error sending notification: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(() => {
                alert('Error connecting to server.');
            });
    }

    // Action methods
    editUser(id) {
        const user = this.users.find(u => u.id == id);
        if (!user) return;
        document.getElementById('userName').value = user.name;
        document.getElementById('userEmail').value = user.email;
        document.getElementById('userRole').value = user.role;
        document.getElementById('userPhone').value = user.phone;
        this.editingUserId = id;
        this.openModal('userModal');
        const modalHeader = document.querySelector('#userModal .modal-header h3');
        const submitBtn = document.querySelector('#userModal .btn-primary');
        if (modalHeader) modalHeader.innerHTML = '<i class="fas fa-edit"></i> Edit User';
        if (submitBtn) submitBtn.textContent = 'Update User';
        // Hide password input on edit
        const passwordGroup = document.getElementById('userPassword')?.parentElement;
        if (passwordGroup) passwordGroup.style.display = 'none';
    }

    deleteUser(id) {
        if (!confirm('Are you sure you want to delete this user?')) return;
        fetch('../../Backend/Admin/user_api.php', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showSuccess('User deleted successfully!');
                    this.loadUsers();
                } else {
                    alert('Error: ' + (data.error || 'Failed to delete user'));
                }
            });
    }

    editArtist(id) {
        const artist = this.artists.find(a => a.id == id);
        if (!artist) return;

        // Populate form fields with artist data
        document.getElementById('artistName').value = artist.name;
        document.getElementById('artistEmail').value = artist.email;
        document.getElementById('artistSpecialty').value = artist.specialty;
        document.getElementById('artistExperience').value = artist.experience;
        document.getElementById('artistPhone').value = artist.phone || '';
        document.getElementById('artistLocation').value = artist.location || '';
        document.getElementById('artistBio').value = artist.bio || '';

        // Hide password field when editing
        const passwordGroup = document.getElementById('artistPassword')?.parentElement;
        if (passwordGroup) passwordGroup.style.display = 'none';

        // Set editing mode
        this.editingArtistId = id;
        this.openModal('artistModal');

        // Update modal header and button text
        const modalHeader = document.querySelector('#artistModal .modal-header h3');
        const submitBtn = document.querySelector('#artistModal .btn-primary');
        if (modalHeader) modalHeader.innerHTML = '<i class="fas fa-edit"></i> Edit Artist';
        if (submitBtn) submitBtn.textContent = 'Update Artist';
    }

    deleteArtist(id) {
        if (!confirm('Are you sure you want to delete this artist?')) return;

        fetch('../../Backend/Admin/artist_api.php', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showSuccess('Artist deleted successfully!');
                    this.loadArtists();
                } else {
                    alert('Error: ' + (data.error || 'Failed to delete artist'));
                }
            })
            .catch(err => {
                alert('Error connecting to server: ' + err.message);
            });
    }

    approveArtist(id) {
        const artist = this.artists.find(a => a.id === id);
        if (artist && artist.status === 'pending') {
            artist.status = 'active';
            this.populateArtistsTable();
            this.showSuccess('Artist approved successfully!');
        }
    }

    viewBookingDetails(id) {
        const booking = this.bookings.find(b => b.id == id);
        if (!booking) return;
        const customerName = this.usersMap && this.usersMap[booking.user_id] ? this.usersMap[booking.user_id] : `User #${booking.user_id}`;
        const artistName = this.artistsMap && this.artistsMap[booking.artist_id] ? this.artistsMap[booking.artist_id] : `Artist #${booking.artist_id}`;
        // Populate modal content
        const modalContent = document.getElementById('bookingDetailsContent');
        if (modalContent) {
            modalContent.innerHTML = `
                <div class="details-grid">
                    <div><strong>Booking ID:</strong> ${booking.id}</div>
                    <div><strong>Customer:</strong> ${customerName}</div>
                    <div><strong>Artist:</strong> ${artistName}</div>
                    <div><strong>Event Type:</strong> ${booking.select_type}</div>
                    <div><strong>Date:</strong> ${booking.date}</div>
                    <div><strong>Time:</strong> ${booking.time}</div>
                    <div><strong>Client Address:</strong> ${booking.client_address}</div>
                    <div><strong>Description:</strong> ${booking.description || ''}</div>
                    <div><strong>Service Type:</strong> ${booking.service_type || '-'}</div>
                    <div><strong>Offer:</strong> ${booking.offer || '-'}</div>
                    <div><strong>Price:</strong> Rs${parseFloat(booking.price).toFixed(2)}</div>
                    <div><strong>Status:</strong> ${booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}</div>
                </div>
            `;
        }
        this.openModal('bookingDetailsModal');
    }

    editCoupon(code) {
        const coupon = this.coupons.find(c => c.code === code);
        if (coupon) {
            alert(`Edit coupon: ${coupon.code}`);
        }
    }

    deleteCoupon(code) {
        if (confirm('Are you sure you want to delete this coupon?')) {
            this.coupons = this.coupons.filter(c => c.code !== code);
            this.populateCouponsTable();
            this.showSuccess('Coupon deleted successfully!');
        }
    }

    viewTicket(id) {
        const ticket = this.supportTickets.find(t => t.id === id);
        if (ticket) {
            alert(`Ticket Details:\nID: ${ticket.id}\nCustomer: ${ticket.customer}\nSubject: ${ticket.subject}\nPriority: ${ticket.priority}\nStatus: ${ticket.status}\nCreated: ${ticket.created}`);
        }
    }

    resolveTicket(id) {
        const ticket = this.supportTickets.find(t => t.id === id);
        if (ticket) {
            ticket.status = 'resolved';
            this.populateSupportTable();
            this.showSuccess('Ticket resolved successfully!');
        }
    }

    reviewContent(id) {
        alert(`Review content ID: ${id}`);
    }

    approveContent(id) {
        this.showSuccess('Content approved successfully!');
    }

    rejectContent(id) {
        this.showSuccess('Content rejected successfully!');
    }

    deleteNotification(id) {
        if (confirm('Are you sure you want to delete this notification?')) {
            this.notifications = this.notifications.filter(n => n.id !== id);
            this.populateNotifications();
            this.showSuccess('Notification deleted successfully!');
        }
    }

    generateCouponCode() {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let code = '';
        for (let i = 0; i < 8; i++) {
            code += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        const codeField = document.getElementById('couponCode');
        if (codeField) codeField.value = code;
    }

    generateReport() {
        const startDate = document.getElementById('startDate')?.value;
        const endDate = document.getElementById('endDate')?.value;

        if (!startDate || !endDate) {
            alert('Please select both start and end dates');
            return;
        }

        // Simulate report generation
        this.showSuccess(`Report generated for ${startDate} to ${endDate}`);

        // Update chart placeholders with dummy data message
        const charts = ['userChart', 'revenueChart', 'bookingChart', 'performanceChart'];
        charts.forEach(chartId => {
            const element = document.getElementById(chartId);
            if (element && element.parentElement) {
                element.parentElement.innerHTML = `<p style="text-align: center; color: var(--text-secondary);">Report data for ${startDate} to ${endDate}<br>Chart visualization would appear here</p>`;
            }
        });
    }

    setDefaultDates() {
        const today = new Date();
        const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, today.getDate());

        const startDateEl = document.getElementById('startDate');
        const endDateEl = document.getElementById('endDate');

        if (startDateEl) startDateEl.value = lastMonth.toISOString().split('T')[0];
        if (endDateEl) endDateEl.value = today.toISOString().split('T')[0];
    }

    switchTab(tab) {
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        const tabBtn = document.querySelector(`[data-tab="${tab}"]`);
        if (tabBtn) tabBtn.classList.add('active');
    }

    applyFilters() {
        // Filter functionality placeholder
        console.log('Applying filters...');
    }

    // Modal methods
    openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) modal.classList.add('active');
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) modal.classList.remove('active');
    }

    // Reset form methods
    resetUserForm() {
        document.getElementById('userForm').reset();
        this.editingUserId = undefined;
        const modalHeader = document.querySelector('#userModal .modal-header h3');
        const submitBtn = document.querySelector('#userModal .btn-primary');
        if (modalHeader) modalHeader.innerHTML = '<i class="fas fa-user-plus"></i> Add User';
        if (submitBtn) submitBtn.textContent = 'Add User';
        // Show password input on add
        const passwordGroup = document.getElementById('userPassword')?.parentElement;
        if (passwordGroup) passwordGroup.style.display = '';
    }

    // Utility methods
    showSuccess(message) {
        const toast = document.createElement('div');
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--success-color, #28a745);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: var(--border-radius, 8px);
            box-shadow: var(--shadow-lg, 0 10px 25px rgba(0,0,0,0.15));
            z-index: 1001;
            animation: slideInRight 0.3s ease-out;
            font-family: inherit;
        `;
        toast.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;

        document.body.appendChild(toast);

        setTimeout(() => {
            toast.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => {
                if (document.body.contains(toast)) {
                    document.body.removeChild(toast);
                }
            }, 300);
        }, 3000);
    }

    // ===== Reports Pages Rendering =====
    loadReportPage(page) {
        Promise.all([
            fetch('../../Backend/Admin/user_api.php').then(r => r.json()),
            fetch('../../Backend/Admin/artist_api.php').then(r => r.json()),
            fetch('../../Backend/Artist/booking_api.php').then(r => r.json()),
            fetch('../../Backend/Artist/review_api.php').then(r => r.json())
        ]).then(([userData, artistData, bookingData, reviewData]) => {
            const users = (userData.success && Array.isArray(userData.users)) ? userData.users : [];
            const artists = (artistData.success && Array.isArray(artistData.artists)) ? artistData.artists : [];
            let bookings = (bookingData.success && Array.isArray(bookingData.bookings)) ? bookingData.bookings : [];
            let reviews = (reviewData.success && Array.isArray(reviewData.reviews)) ? reviewData.reviews : [];

            // If a date range is selected, filter datasets to that inclusive range
            const startVal = document.getElementById('startDate')?.value;
            const endVal = document.getElementById('endDate')?.value;
            if (startVal && endVal) {
                const start = new Date(startVal);
                const end = new Date(endVal);
                // include whole end day
                end.setHours(23, 59, 59, 999);
                const parseDate = (obj, fields) => {
                    for (const f of fields) {
                        if (!obj) continue;
                        const v = obj[f];
                        if (!v) continue;
                        const d = new Date(v);
                        if (!isNaN(d)) return d;
                    }
                    return null;
                };
                bookings = bookings.filter(b => {
                    const d = parseDate(b, ['date', 'booking_date', 'created_at', 'createdAt']);
                    return d && d >= start && d <= end;
                });
                reviews = reviews.filter(r => {
                    const d = parseDate(r, ['created_at', 'date', 'reviewed_at', 'createdAt']);
                    return d && d >= start && d <= end;
                });
                // For user-centric reports, some functions (like user growth) rely on user created dates.
                // We will filter users where created_at/joined_at/createdAt falls within the range when needed in renderers.
            }
            if (page === 'report-sales') this.renderReportSales(bookings);
            if (page === 'report-customers') this.renderReportCustomers(bookings, users);
            if (page === 'report-bookings') this.renderReportBookings(bookings);
            if (page === 'report-performance') this.renderReportPerformance(bookings, artists, reviews);
        }).catch(() => { });
    }

    // Fetch latest datasets and render main small reports area charts using selected date range
    applyReportDateFilter() {
        const startVal = document.getElementById('startDate')?.value;
        const endVal = document.getElementById('endDate')?.value;
        // If dates are not both present, fall back to loading dashboard stats unfiltered
        if (!startVal || !endVal) return;

        Promise.all([
            fetch('../../Backend/Admin/user_api.php').then(r => r.json()).catch(() => null),
            fetch('../../Backend/Admin/artist_api.php').then(r => r.json()).catch(() => null),
            fetch('../../Backend/Artist/booking_api.php').then(r => r.json()).catch(() => null),
            fetch('../../Backend/Artist/review_api.php').then(r => r.json()).catch(() => null)
        ]).then(([userData, artistData, bookingData, reviewData]) => {
            const users = (userData && userData.success && Array.isArray(userData.users)) ? userData.users : [];
            const artists = (artistData && artistData.success && Array.isArray(artistData.artists)) ? artistData.artists : [];
            const bookings = (bookingData && bookingData.success && Array.isArray(bookingData.bookings)) ? bookingData.bookings : [];
            const reviews = (reviewData && reviewData.success && Array.isArray(reviewData.reviews)) ? reviewData.reviews : [];

            const start = new Date(startVal);
            const end = new Date(endVal);
            end.setHours(23, 59, 59, 999);

            const parseDate = (obj, fields) => {
                for (const f of fields) {
                    if (!obj) continue;
                    const v = obj[f];
                    if (!v) continue;
                    const d = new Date(v);
                    if (!isNaN(d)) return d;
                }
                return null;
            };

            const filteredBookings = bookings.filter(b => {
                const d = parseDate(b, ['date', 'booking_date', 'created_at', 'createdAt']);
                return d && d >= start && d <= end;
            });

            const filteredUsers = users.filter(u => {
                const d = parseDate(u, ['created_at', 'createdAt', 'joined_at']);
                return d && d >= start && d <= end;
            });

            const filteredReviews = reviews.filter(r => {
                const d = parseDate(r, ['created_at', 'date', 'reviewed_at', 'createdAt']);
                return d && d >= start && d <= end;
            });

            // Render small overview charts in the reports page
            this.renderAdminUserGrowthChart(filteredUsers);
            this.renderAdminRevenueMonthlyChart(filteredBookings);
            this.renderAdminBookingsMonthlyChart(filteredBookings);
            this.renderAdminArtistPerformanceChart(filteredBookings, artists, filteredReviews);
        }).catch(() => { /* ignore errors silently */ });
    }

    renderReportSales(bookings) {
        // Revenue monthly
        this.renderAdminRevenueMonthlyChart(bookings);
        // Revenue by weekday
        const weekdayEl = document.getElementById('adSalesRevenueWeekday');
        if (weekdayEl) {
            const labels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            const sums = Array(7).fill(0);
            bookings.forEach(b => { const s = (b.status || '').toLowerCase(); if (s !== 'confirmed' && s !== 'completed') return; const d = new Date(b.date); if (isNaN(d)) return; const idx = d.getDay(); const price = parseFloat(String(b.price).replace(/[^0-9.]/g, '')) || 0; sums[idx] += price; });
            this._salesWeekday = this._salesWeekday || new Chart(weekdayEl.getContext('2d'), { type: 'bar', data: { labels, datasets: [{ label: 'Revenue (Rs)', data: sums, backgroundColor: '#22c55e' }] }, options: { responsive: true, scales: { y: { beginAtZero: true } }, plugins: { legend: { display: false } } } });
            if (this._salesWeekday) { this._salesWeekday.data.labels = labels; this._salesWeekday.data.datasets[0].data = sums; this._salesWeekday.update(); }
        }
        // Top Items
        const topItemsEl = document.getElementById('adSalesTopItems');
        if (topItemsEl) {
            const counts = {};
            bookings.forEach(b => { let n = b.service_type ? b.service_type : (b.offer || 'Unknown'); if (n.includes(' - Rs')) n = n.split(' - Rs')[0]; counts[n] = (counts[n] || 0) + 1; });
            const top = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 8);
            const labels = top.map(t => t[0]); const data = top.map(t => t[1]);
            this._salesTop = this._salesTop || new Chart(topItemsEl.getContext('2d'), { type: 'bar', data: { labels, datasets: [{ label: 'Orders', data, backgroundColor: '#6366f1' }] }, options: { indexAxis: 'y', responsive: true, scales: { x: { beginAtZero: true, ticks: { precision: 0 } } }, plugins: { legend: { display: false } } } });
            if (this._salesTop) { this._salesTop.data.labels = labels; this._salesTop.data.datasets[0].data = data; this._salesTop.update(); }
        }
        // Status pie
        const statusEl = document.getElementById('adSalesStatusPie');
        if (statusEl) {
            const statuses = { pending: 0, confirmed: 0, completed: 0, cancelled: 0, cancelledByCustomer: 0 };
            bookings.forEach(b => { const s = (b.status || '').toLowerCase(); if (s === 'pending') statuses.pending++; else if (s === 'confirmed') statuses.confirmed++; else if (s === 'completed') statuses.completed++; else if (s === 'cancelled') statuses.cancelled++; else if (s === 'cancelled by customer') statuses.cancelledByCustomer++; });
            const labels = ['Pending', 'Confirmed', 'Completed', 'Cancelled', 'Cancelled by Customer'];
            const data = [statuses.pending, statuses.confirmed, statuses.completed, statuses.cancelled, statuses.cancelledByCustomer];
            this._salesPie = this._salesPie || new Chart(statusEl.getContext('2d'), { type: 'pie', data: { labels, datasets: [{ data, backgroundColor: ['#f59e0b', '#3b82f6', '#10b981', '#ef4444', '#a855f7'] }] }, options: { responsive: true, plugins: { legend: { position: 'bottom' } } } });
            if (this._salesPie) { this._salesPie.data.labels = labels; this._salesPie.data.datasets[0].data = data; this._salesPie.update(); }
        }
        // Overview summary
        this.renderSalesReportSummary(bookings);
    }

    renderReportCustomers(bookings, users) {
        // New vs Returning
        const firstSeen = new Map();
        bookings.forEach(b => { const uid = parseInt(b.user_id); const d = new Date(b.date); if (isNaN(d)) return; if (!firstSeen.has(uid) || d < firstSeen.get(uid)) firstSeen.set(uid, d); });
        const now = new Date(); const d30 = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 30);
        const total = new Set(bookings.map(b => parseInt(b.user_id))).size;
        const newCount = Array.from(firstSeen.values()).filter(d => d >= d30).length;
        const retCount = Math.max(0, total - newCount);
        const pieEl = document.getElementById('adCustNewReturning');
        if (pieEl) { this._custPie = this._custPie || new Chart(pieEl.getContext('2d'), { type: 'pie', data: { labels: ['New', 'Returning'], datasets: [{ data: [newCount, retCount], backgroundColor: ['#22c55e', '#a855f7'] }] }, options: { responsive: true, plugins: { legend: { position: 'bottom' } } } }); if (this._custPie) { this._custPie.data.datasets[0].data = [newCount, retCount]; this._custPie.update(); } }
        // Unique customers by month
        const months = this.getLastSixMonths(); const map = Object.fromEntries(months.map(m => [m.key, new Set()]));
        bookings.forEach(b => { const d = new Date(b.date); const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; if (map[key]) map[key].add(parseInt(b.user_id)); });
        const cmEl = document.getElementById('adCustByMonth'); if (cmEl) { const labels = months.map(m => m.label); const data = months.map(m => map[m.key].size); this._custMonth = this._custMonth || new Chart(cmEl.getContext('2d'), { type: 'bar', data: { labels, datasets: [{ label: 'Unique Customers', data, backgroundColor: '#0ea5e9' }] }, options: { responsive: true, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }, plugins: { legend: { display: false } } } }); if (this._custMonth) { this._custMonth.data.labels = labels; this._custMonth.data.datasets[0].data = data; this._custMonth.update(); } }
        // Top spenders
        const spend = {}; bookings.forEach(b => { const s = (b.status || '').toLowerCase(); if (s !== 'confirmed' && s !== 'completed') return; const uid = parseInt(b.user_id); const price = parseFloat(String(b.price).replace(/[^0-9.]/g, '')) || 0; spend[uid] = (spend[uid] || 0) + price; });
        const top = Object.entries(spend).sort((a, b) => b[1] - a[1]).slice(0, 7);
        const tsEl = document.getElementById('adCustTopSpenders'); if (tsEl) { const labels = top.map(([uid]) => { const u = users.find(x => parseInt(x.id) === parseInt(uid)); return u ? (u.name || `ID ${uid}`) : `ID ${uid}` }); const data = top.map(([, v]) => v); this._custTop = this._custTop || new Chart(tsEl.getContext('2d'), { type: 'bar', data: { labels, datasets: [{ label: 'Total Spent (Rs)', data, backgroundColor: '#f59e0b' }] }, options: { indexAxis: 'y', responsive: true, scales: { x: { beginAtZero: true } }, plugins: { legend: { display: false } } } }); if (this._custTop) { this._custTop.data.labels = labels; this._custTop.data.datasets[0].data = data; this._custTop.update(); } }
        // Bookings per customer
        const bpc = {}; bookings.forEach(b => { const uid = parseInt(b.user_id); bpc[uid] = (bpc[uid] || 0) + 1; });
        const bpcTop = Object.entries(bpc).sort((a, b) => b[1] - a[1]).slice(0, 7);
        const bpcEl = document.getElementById('adCustBookingsPerCustomer'); if (bpcEl) { const labels = bpcTop.map(([uid]) => { const u = users.find(x => parseInt(x.id) === parseInt(uid)); return u ? (u.name || `ID ${uid}`) : `ID ${uid}` }); const data = bpcTop.map(([, v]) => v); this._custBpc = this._custBpc || new Chart(bpcEl.getContext('2d'), { type: 'bar', data: { labels, datasets: [{ label: 'Bookings', data, backgroundColor: '#3b82f6' }] }, options: { indexAxis: 'y', responsive: true, scales: { x: { beginAtZero: true, ticks: { precision: 0 } } }, plugins: { legend: { display: false } } } }); if (this._custBpc) { this._custBpc.data.labels = labels; this._custBpc.data.datasets[0].data = data; this._custBpc.update(); } }
        // Overview summary
        this.renderCustomerReportSummary(bookings, users);
    }

    renderReportBookings(bookings) {
        // Monthly bookings
        const bmEl = document.getElementById('adBookMonthly'); if (bmEl) { this.renderAdminBookingsMonthlyChart(bookings); }
        // By status
        const bsEl = document.getElementById('adBookStatus'); if (bsEl) { const sMap = { pending: 0, confirmed: 0, completed: 0, cancelled: 0, cancelledByCustomer: 0 }; bookings.forEach(b => { const s = (b.status || '').toLowerCase(); if (s === 'pending') sMap.pending++; else if (s === 'confirmed') sMap.confirmed++; else if (s === 'completed') sMap.completed++; else if (s === 'cancelled') sMap.cancelled++; else if (s === 'cancelled by customer') sMap.cancelledByCustomer++; }); const labels = ['Pending', 'Confirmed', 'Completed', 'Cancelled', 'Cancelled by Customer']; const data = [sMap.pending, sMap.confirmed, sMap.completed, sMap.cancelled, sMap.cancelledByCustomer]; this._bookStatus = this._bookStatus || new Chart(bsEl.getContext('2d'), { type: 'pie', data: { labels, datasets: [{ data, backgroundColor: ['#f59e0b', '#3b82f6', '#10b981', '#ef4444', '#a855f7'] }] }, options: { responsive: true, plugins: { legend: { position: 'bottom' } } } }); if (this._bookStatus) { this._bookStatus.data.labels = labels; this._bookStatus.data.datasets[0].data = data; this._bookStatus.update(); } }
        // By weekday
        const bwEl = document.getElementById('adBookWeekday'); if (bwEl) { const labels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']; const cnt = Array(7).fill(0); bookings.forEach(b => { const d = new Date(b.date); if (isNaN(d)) return; cnt[d.getDay()] += 1; }); this._bookWeek = this._bookWeek || new Chart(bwEl.getContext('2d'), { type: 'bar', data: { labels, datasets: [{ label: 'Bookings', data: cnt, backgroundColor: '#0ea5e9' }] }, options: { responsive: true, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }, plugins: { legend: { display: false } } } }); if (this._bookWeek) { this._bookWeek.data.datasets[0].data = cnt; this._bookWeek.update(); } }
        // Average Order Value
        const aovEl = document.getElementById('adBookAOV'); if (aovEl) { const last6 = this.getLastSixMonths(); const sum = Object.fromEntries(last6.map(m => [m.key, 0])); const count = Object.fromEntries(last6.map(m => [m.key, 0])); bookings.forEach(b => { const s = (b.status || '').toLowerCase(); if (s !== 'confirmed' && s !== 'completed') return; const d = new Date(b.date); const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; const p = parseFloat(String(b.price).replace(/[^0-9.]/g, '')) || 0; if (sum[key] !== undefined) { sum[key] += p; count[key] += 1; } }); const labels = last6.map(m => m.label); const data = last6.map(m => count[m.key] > 0 ? Math.round(sum[m.key] / count[m.key]) : 0); this._bookAov = this._bookAov || new Chart(aovEl.getContext('2d'), { type: 'line', data: { labels, datasets: [{ label: 'Avg Order Value (Rs)', data, borderColor: '#6366f1', backgroundColor: 'rgba(99,102,241,0.15)', fill: true, tension: 0.35 }] }, options: { responsive: true, scales: { y: { beginAtZero: true } }, plugins: { legend: { display: false } } } }); if (this._bookAov) { this._bookAov.data.labels = labels; this._bookAov.data.datasets[0].data = data; this._bookAov.update(); } }
        // Overview summary
        this.renderBookingReportSummary(bookings);
    }

    renderReportPerformance(bookings, artists, reviews) {
        // Completion by artist
        const compEl = document.getElementById('adPerfCompletionByArtist'); if (compEl) { const map = {}; bookings.forEach(b => { const aid = b.artist_id; map[aid] = map[aid] || { conf: 0, comp: 0 }; const s = (b.status || '').toLowerCase(); if (s === 'confirmed') map[aid].conf++; else if (s === 'completed') map[aid].comp++; }); const items = Object.keys(map).map(aid => { const a = map[aid]; const rate = (a.conf + a.comp) > 0 ? Math.round((a.comp / (a.conf + a.comp)) * 100) : 0; return { name: (artists.find(x => x.id == aid)?.name) || `Artist #${aid}`, rate }; }).sort((a, b) => b.rate - a.rate).slice(0, 10); const labels = items.map(i => i.name); const data = items.map(i => i.rate); this._perfComp = this._perfComp || new Chart(compEl.getContext('2d'), { type: 'bar', data: { labels, datasets: [{ label: 'Completion %', data, backgroundColor: '#22c55e' }] }, options: { responsive: true, scales: { y: { beginAtZero: true, max: 100 } }, plugins: { legend: { display: false } } } }); if (this._perfComp) { this._perfComp.data.labels = labels; this._perfComp.data.datasets[0].data = data; this._perfComp.update(); } }
        // Rating by artist
        const rateEl = document.getElementById('adPerfRatingByArtist'); if (rateEl) { const sum = {}, cnt = {}; reviews.forEach(r => { sum[r.artist_id] = (sum[r.artist_id] || 0) + (parseFloat(r.rating) || 0); cnt[r.artist_id] = (cnt[r.artist_id] || 0) + 1; }); const items = Object.keys(sum).map(aid => ({ name: (artists.find(x => x.id == aid)?.name) || `Artist #${aid}`, rating: cnt[aid] > 0 ? (sum[aid] / cnt[aid]) : 0 })).sort((a, b) => b.rating - a.rating).slice(0, 10); const labels = items.map(i => i.name); const data = items.map(i => i.rating.toFixed(2)); this._perfRate = this._perfRate || new Chart(rateEl.getContext('2d'), { type: 'bar', data: { labels, datasets: [{ label: 'Avg Rating', data, backgroundColor: '#3b82f6' }] }, options: { responsive: true, scales: { y: { beginAtZero: true, max: 5 } }, plugins: { legend: { display: false } } } }); if (this._perfRate) { this._perfRate.data.labels = labels; this._perfRate.data.datasets[0].data = data; this._perfRate.update(); } }
        // Revenue by artist
        const revEl = document.getElementById('adPerfRevenueByArtist'); if (revEl) { const sum = {}; bookings.forEach(b => { const s = (b.status || '').toLowerCase(); if (s !== 'confirmed' && s !== 'completed') return; const aid = b.artist_id; const p = parseFloat(String(b.price).replace(/[^0-9.]/g, '')) || 0; sum[aid] = (sum[aid] || 0) + p; }); const items = Object.keys(sum).map(aid => ({ name: (artists.find(x => x.id == aid)?.name) || `Artist #${aid}`, revenue: sum[aid] })).sort((a, b) => b.revenue - a.revenue).slice(0, 10); const labels = items.map(i => i.name); const data = items.map(i => i.revenue); this._perfRev = this._perfRev || new Chart(revEl.getContext('2d'), { type: 'bar', data: { labels, datasets: [{ label: 'Revenue (Rs)', data, backgroundColor: '#f59e0b' }] }, options: { indexAxis: 'y', responsive: true, scales: { x: { beginAtZero: true } }, plugins: { legend: { display: false } } } }); if (this._perfRev) { this._perfRev.data.labels = labels; this._perfRev.data.datasets[0].data = data; this._perfRev.update(); } }
        // Composite (reuse existing method for top artists)
        const compoEl = document.getElementById('adPerfComposite'); if (compoEl) { this.renderAdminArtistPerformanceChart(bookings, artists, reviews); }
        // Overview summary
        this.renderPerformanceReportSummary(bookings, artists, reviews);
    }

    // PDF download for any report page
    downloadAdminReportPDF(pageId) {
        const container = document.getElementById(pageId);
        if (!container) return;
        setTimeout(async () => {
            const canvas = await html2canvas(container, { scale: 2, useCORS: true });
            const img = canvas.toDataURL('image/png');
            const { jsPDF } = window.jspdf;
            const pdf = new jsPDF('p', 'mm', 'a4');
            const pageWidth = pdf.internal.pageSize.getWidth();
            const imgWidth = pageWidth - 20;
            const imgHeight = canvas.height * imgWidth / canvas.width;
            pdf.addImage(img, 'PNG', 10, 10, imgWidth, imgHeight);
            pdf.save(pageId + '.pdf');
        }, 200);
    }
}


// Global functions for onclick handlers
function openModal(modalId) {
    if (window.adminPanel) {
        window.adminPanel.openModal(modalId);
    }
}

function closeModal(modalId) {
    if (window.adminPanel) {
        window.adminPanel.closeModal(modalId);
    }
}

function generateCouponCode() {
    if (window.adminPanel) {
        window.adminPanel.generateCouponCode();
    }
}

function generateReport() {
    if (window.adminPanel) {
        window.adminPanel.generateReport();
    }
}

function downloadAdminReportPDF(pageId) {
    if (window.adminPanel) {
        window.adminPanel.downloadAdminReportPDF(pageId);
    }
}

function openArtistModal() {
    if (window.adminPanel) {
        window.adminPanel.resetArtistForm();
        window.adminPanel.openModal('artistModal');
    }
}

// Initialize admin panel
document.addEventListener('DOMContentLoaded', () => {
    adminPanel = new AdminPanel();
    window.adminPanel = adminPanel;
    adminPanel.loadUsers();
    adminPanel.loadArtists();
    adminPanel.populateOfferArtistDropdown();
    
    // Artist form: handle add/edit based on editingArtistId
    const artistForm = document.getElementById('artistForm');
    if (artistForm) {
        artistForm.addEventListener('submit', function(e) {
            if (adminPanel.editingArtistId) {
                adminPanel.handleEditArtist(e);
            } else {
                adminPanel.handleAddArtist(e);
            }
        });
    }
})

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { 
            transform: translateX(100%); 
            opacity: 0; 
        }
        to { 
            transform: translateX(0); 
            opacity: 1; 
        }
    }

    @keyframes slideOutRight {
        from { 
            transform: translateX(0); 
            opacity: 1; 
        }
        to { 
            transform: translateX(100%); 
            opacity: 0; 
        }
    }
`;

// Only add styles if they don't already exist
if (!document.querySelector('#admin-panel-animations')) {
    style.id = 'admin-panel-animations';
    document.head.appendChild(style);
}